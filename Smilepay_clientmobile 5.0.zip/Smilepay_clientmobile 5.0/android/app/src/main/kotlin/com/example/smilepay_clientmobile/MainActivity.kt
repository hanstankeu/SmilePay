package com.example.smilepay_clientmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
