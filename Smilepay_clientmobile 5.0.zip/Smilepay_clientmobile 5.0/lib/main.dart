import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/UserCard.dart';
import 'package:smilepay/services/authentication/RegistrationServices.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/splash_screen.dart';
import 'package:smilepay/view/user/view/profile/completeInformations.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:smilepay/view/user/view/authentication/signin.dart';

void main() async {
  runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: SplashScreen(),
      )
  );

  /*NationalCard nation = new NationalCard("1234", "4321", DateTime.now(), DateTime.now(), "attachement", DateTime.now(), DateTime.now(), new UserAccount.name("idPerson"));

 UserCard patrick = new UserCard("ngayon","patrick", "patrick", "instituts@intjean", "ngayonpatrick@gmail.com", "690374298", "MALE", "Douala", "MORAL_PERSON", DateTime.now(),nation);
  await registration(patrick);*/

}