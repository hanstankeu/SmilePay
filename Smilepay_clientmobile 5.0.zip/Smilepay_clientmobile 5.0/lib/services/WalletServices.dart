import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/WalletExterne.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

//Create wallet service
Future<http.Response> createwalletExterne(WalletExterne walletExterne, String token) async{
  String url = Path.url + 'walletExterne/create' ;
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(walletExterne.toJson()),
  );
  return response;
}

//find wallet by user
Future<List<WalletExterne>> fetchwalletExterne(String idPersonne,String token) async{
  String url = Path.url + 'walletExterne/findByUser/' + idPersonne;
  final response = await http.get('$url',
      headers:{
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      }
  );
  if (response.statusCode == 200){
    List jsonData = json.decode(response.body);
    return jsonData.map((e)=> WalletExterne.fromJson(e)).toList();
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}

//update wallet
Future<http.Response> updatewalletEXterne(String idWalletExterne, WalletExterne walletExterne, String token) async{
  String url = Path.url + 'walletExterne/update/' + idWalletExterne;
  final response = await http.put(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(walletExterne.toJson()),
  );
  return response;
}


Future<http.Response> deletewalletExterne (String idWalletExterne, String token) async {
  String url = Path.url + 'walletExterne/delete/' + idWalletExterne;
  final response = await http.delete(url,
    headers: <String, String>{
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  return response;
}