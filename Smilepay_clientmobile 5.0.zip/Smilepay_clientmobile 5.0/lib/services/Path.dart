class Path{
  static String domain = 'http://192.168.43.81:8085/'; //192.168.100.80 http://localhost:8085/api ///192.168.43.34 ///192.168.43.81
  static String url = domain + 'api/';

}