import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Operator.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> createoperator(Operator operator, String token) async{
  String url = Path.url + 'operator/create';
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(operator.toJson()),
  );
  return response;
}