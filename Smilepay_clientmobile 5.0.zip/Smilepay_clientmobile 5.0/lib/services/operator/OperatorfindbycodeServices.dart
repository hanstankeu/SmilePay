import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/Transaction.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<Operator> fetchoperatorbyoperatorcode(String operatorCode, String token) async{
  String url = Path.url + 'transaction/findAllCode/' + operatorCode;
  final response = await http.get('$url',
      headers:{
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      }
  );
  if (response.statusCode == 200){
    Operator jsonData = json.decode(response.body);
    return jsonData ;
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}