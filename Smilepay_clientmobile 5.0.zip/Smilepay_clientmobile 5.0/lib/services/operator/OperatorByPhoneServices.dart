import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/services/Path.dart';

Future<Operator> fetchOperatorByPhone(String phone,String token) async{
  String url = Path.url + 'operator/findByPhone/' + phone;
  final response = await http.get('$url',
      headers:{
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      }
  );
  if (response.statusCode == 200){
    var jsonData = Operator.fromJson( json.decode(response.body));
    return jsonData;
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}