import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Operator.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<List<Operator>> fetchalloperators(String token) async{
  String url = Path.url + 'operator/findAll';
  final response = await http.get('$url',
    headers:<String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  if (response.statusCode == 200){
    List jsonData = json.decode(response.body);
    return jsonData.map((e)=> Operator.fromJson(e)).toList();
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}