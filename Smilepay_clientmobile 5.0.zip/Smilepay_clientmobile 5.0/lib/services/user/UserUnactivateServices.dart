import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/services/Path.dart';

Future<http.Response> unactivateuser (String idPerson, String token) async {
  String url = Path.url + 'user/deleteById/' + idPerson;
  final response = await http.delete(url,
    headers: <String, String>{
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  return response;
}