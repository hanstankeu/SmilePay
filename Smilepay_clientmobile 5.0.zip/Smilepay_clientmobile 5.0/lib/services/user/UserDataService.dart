import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/admin/src/widget/sidebar_menu..dart';
import 'package:smilepay/view/user/view/dashboard.dart';

class UserData{
  static Future <String> getToken() async{
    return await HomePage.storage.read(key: "token");
  }

  static Future <String> getId() async{
    return await HomePage.storage.read(key: "id");
  }

  static Future <String> getPhone() async{
    return await HomePage.storage.read(key: "phone");
}

  static Future <String> getNomPrenom() async{
    return await HomePage.storage.read(key: "noms");
  }

  static Future <String> getSurname() async{
    return await HomePage.storage.read(key: "surname");
  }

  static Future <String> getEmail() async{
    return await HomePage.storage.read(key: "email");
  }

  static Future <String> getUsername() async{
    return await HomePage.storage.read(key: "username");
  }

  static Future <String> getType() async{
    return await HomePage.storage.read(key: "type");
  }

  static Future <String> getBalance() async{
    return await HomePage.storage.read(key: "balance");
  }
}

class AdminData{
  static Future <String> getAdminToken() async{
    return await MainPage.storage.read(key: "token");
  }

  static Future<String> getAdminId() async{
    return await MainPage.storage.read(key: "id");
  }
  static Future <String> getAdminNomPrenom() async{
    return await SideBarMenu.storage.read(key: "noms");
  }

  static Future <String> getAdminEmail() async{
    return await SideBarMenu.storage.read(key: "email");
  }

  static Future <String> getAdminUsername() async{
    return await MainPage.storage.read(key: "username");
  }

  static Future <String> getAdminType() async{
    return await MainPage.storage.read(key: "type");
  }

  static Future <String> getAdminBalance() async{
    return await SideBarMenu.storage.read(key: "balance");
  }
}