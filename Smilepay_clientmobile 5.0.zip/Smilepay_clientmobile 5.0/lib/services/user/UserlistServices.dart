import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/UserAccount.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

 Future<List<UserAccount>>fetchalluser(String token) async{
  String url = Path.url + 'user/findAll';
  final response = await http.get('$url',
    headers:<String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  if (response.statusCode == 200){
    List jsonData = json.decode(response.body);
    return jsonData.map((e)=> UserAccount.fromJson(e)).toList();
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}

Future<UserAccount>fetchOneuser(String idPerson, String token) async{
  String url = Path.url + 'user/findOne/' + idPerson;
  final response = await http.get('$url',
      headers: <String, String>{
        'Content-type' : 'application/json; charset=UTF-8',
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      }
  );
  if (response.statusCode == 200){
    var jsonData = UserAccount.fromJson( json.decode(response.body));
    print(response.body);
    print(jsonData.idPerson);
    return jsonData;
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' + response.body);
  }
}