import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/UserCard.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> registration (UserCard userCard) async{
  String url = Path.url + 'auth/create';
  final response = await http.post(url,
      headers: <String, String>{
        'Content-type' : 'application/json; charset=UTF-8',
      },
      body: json.encode(UserCard.toJson(userCard)),
  );
  return response;
}