import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/LoginRequest.dart';
import 'package:smilepay/model/Validercode.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> authentication (LoginRequest loginRequest) async {
  String url = Path.url + 'auth/signin';
  final response = await http.post(
      url,
      headers: <String, String>{
        'Content-type' : 'application/json; charset=UTF-8',
      },
      body: json.encode(LoginRequest.converttoJson(loginRequest))
  );
  print(response.statusCode);
  return response;
}


Future<http.Response> validercodeUser (Validercode validercode) async {
  String url = Path.url + 'auth/validercode';
  final response = await http.post(
      url,
      headers: <String, String>{
        'Content-type' : 'application/json; charset=UTF-8',
      },
      body: json.encode(Validercode.converttoJson(validercode))
  );
  print(response.statusCode);
  return response;
}