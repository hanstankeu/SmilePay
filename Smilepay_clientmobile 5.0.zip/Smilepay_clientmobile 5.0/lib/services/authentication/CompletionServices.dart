import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:smilepay/model/UserCard.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/services/Path.dart';
import 'package:smilepay/services/user/UserDataService.dart';

Future<http.Response> complete (UserCard userCard, String idAccount, String token) async{
  String url = Path.url + 'user/update/' + idAccount;
  final response = await http.put(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token,
    },
    body: json.encode(UserCard.toJson(userCard)),
  );
  print(response.statusCode);
  return response;
}


Future<http.Response> completusertrans (UserCard userCard, String idAccount, String token) async{
  String url = Path.url + 'user/updatetrans/' + idAccount;
  final response = await http.put(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token,
    },
    body: json.encode(UserCard.toJson(userCard)),
  );
  print(response.statusCode);
  return response;
}