import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/services/Path.dart';

Future<http.Response> logout (String idPerson, String token) async {
  String url = Path.url + 'user/logout/' + idPerson;
  final response = await http.post(url,
      headers: <String, String>{
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      },
      body: {'idPerson' : idPerson},
  );
  return response;

}