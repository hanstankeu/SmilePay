import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/NationalCard.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<NationalCard> fetchnationalcardbymail(String mail, String token) async {
  String url = Path.url + 'card/findCard/' + mail;
  final response = await http.get('$url',
      headers: <String, String>{
        'Content-type' : 'application/json; charset=UTF-8',
        HttpHeaders.authorizationHeader : 'Bearer ' + token
      }
  );
  if (response.statusCode == 200){

    var jsonData = NationalCard.fromJson( json.decode(response.body));
    print(response.body);
    return jsonData;
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' + response.body);
  }
}
