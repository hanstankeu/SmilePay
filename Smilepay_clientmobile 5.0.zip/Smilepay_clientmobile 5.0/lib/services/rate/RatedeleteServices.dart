import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/services/Path.dart';

Future<http.Response> deleterate (String idRate, String token) async {
  String url = Path.url + 'rate/delete/' + idRate;
  final response = await http.delete(url,
    headers: <String, String>{
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  return response;
}