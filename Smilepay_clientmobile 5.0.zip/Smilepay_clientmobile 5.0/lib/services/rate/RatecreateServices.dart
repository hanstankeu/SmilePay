import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Rate.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> createrate(Rate rate, String token) async{
  String url = Path.url + 'rate/create';
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(rate.toJson()),
  );
  return response;
}