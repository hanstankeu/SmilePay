import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/Rate.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> updaterate(String idRate, Rate rate, String token) async{
  String url = Path.url + 'rate/update/' + idRate;
  final response = await http.put(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(rate.toJson()),
  );
  return response;
}