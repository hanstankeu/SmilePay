import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Message.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> sendmessage (Message message, String token) async{
  String url = Path.url + 'message/sendEmail';
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(Message.toJson(message)),
  );
  return response;
}