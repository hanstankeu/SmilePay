import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Transaction.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<List<Transaction>> fetchalltransactionsbyuser(String idPerson, String token) async{
  String url = Path.url + 'transaction/findAllUser/' + idPerson;
  final response = await http.get('$url',
    headers:{
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
  );
  print(response.statusCode);
  if (response.statusCode == 200){
    List jsonData = json.decode(response.body);
    print(jsonData);
    return jsonData.map((e)=> Transaction.fromJson(e)).toList();
  }
  else{
    throw Exception(response.statusCode.toString() + ' ' +response.body);
  }
}