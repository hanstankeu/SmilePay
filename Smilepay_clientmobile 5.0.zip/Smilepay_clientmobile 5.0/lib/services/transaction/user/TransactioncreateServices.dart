import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:smilepay/model/Transaction.dart';
import 'dart:convert';
import 'package:smilepay/services/Path.dart';

Future<http.Response> transactionWEWE (Transaction transaction, String token) async{
  String url = Path.url + "transaction/WE-WE" ;
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(Transaction.toJson(transaction)),
  );
  print(response.body);
  return response;
}

Future<http.Response> transactionWEWI (Transaction transaction, String idAccount, String token) async{
  String url = Path.url + 'transaction/WE-WI/' + idAccount;
  final response = await http.post(url,
    headers:<String, String>{
    'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(Transaction.toJson(transaction)),
  );
  return response;
}

Future<http.Response> transactionWIWE (Transaction transaction, String idAccount, String token) async{
  String url = Path.url + 'transaction/WI-WE/' + idAccount;
  final response = await http.post(url,
    headers: <String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(Transaction.toJson(transaction)),
  );
  return response;
}

Future<http.Response> transactionWIWI (Transaction transaction, String token) async{
  String url = Path.url + 'transaction/WI-WI';
  final response = await http.post(url,
    headers:<String, String>{
      'Content-type' : 'application/json; charset=UTF-8',
      HttpHeaders.authorizationHeader : 'Bearer ' + token
    },
    body: json.encode(Transaction.toJson(transaction)),
  );
  return response;
}