

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserTypeServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';

class LowerBlocks1 extends StatefulWidget {
  @override
  _LowerBlocksState createState() => _LowerBlocksState();
}

class _LowerBlocksState extends State<LowerBlocks1> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Row(
            //crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Card(
                shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
                borderOnForeground: true,
                child: Container(
                  height: 100,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      SizedBox(height: 15,),
                      Text('Transfert'),
                      SizedBox(height: 10,),
                      FutureBuilder<String>(
                          future: UserData.getToken(),
                          builder: (context, token){
                            if(token.hasData){
                              return FutureBuilder<String>(
                                  future: UserData.getId(),
                                  builder: (context, idPerson){
                                    if(idPerson.hasData){
                                      return Expanded(
                                        child: FutureBuilder<List<Transaction>>(
                                            future: fetchalltransactionsbyuserbytype(idPerson.data, 'IW - IW', token.data),
                                            builder: (context, snapshot){
                                              if(snapshot.hasData){
                                                /*DateTime earlier = DateTime.now().subtract(Duration(days: 30));
                                                List<Transaction> transactions = snapshot.data.where((transaction) =>
                                                transaction.dateCreation == earlier).toList();*/
                                                int sum = 0;
                                                int i = snapshot.data.length;
                                                for(Transaction j in snapshot.data){
                                                  if(i>0){
                                                    sum = sum + j.amount;
                                                    i--;
                                                  }
                                                }

                                                return Text('${sum}' + ' FCFA',
                                                  textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                      fontWeight: FontWeight.bold, color: Colors.green),overflow: TextOverflow.ellipsis,);
                                              }
                                              else{
                                                return Text('0 CFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                    fontWeight: FontWeight.bold, color: Colors.green),overflow: TextOverflow.ellipsis,);
                                              }
                                            }),
                                      );
                                    }
                                    else{
                                      return Center(child: Text('Pardon Connectez Vous.'),);
                                    }
                                  });
                            }
                            else{
                              return Center(child: Text('Session expirée'),);
                            }
                          })
                    ],
                  ),
                ),
              ),
              Card(
                shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
                borderOnForeground: true,
                child: Container(
                  height: 100,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: 15,),
                      Text('Paiement'),
                      SizedBox(height: 10,),
                      FutureBuilder<String>(
                          future: UserData.getToken(),
                          builder: (context, token){
                            if(token.hasData){
                              return FutureBuilder<String>(
                                  future: UserData.getId(),
                                  builder: (context, idPerson){
                                    if(idPerson.hasData){
                                      return Expanded(
                                        child: FutureBuilder<List<Transaction>>(
                                            future: fetchalltransactionsbyuserbytype(idPerson.data, 'EW - EW', token.data),
                                            builder: (context, snapshot){
                                              if(snapshot.hasData){
                                                /*DateTime earlier = DateTime.now().subtract(Duration(days: 30));
                                                List<Transaction> transactions = snapshot.data.where((transaction) =>
                                                transaction.dateCreation == earlier).toList();*/
                                                int sum = 0;
                                                int i = snapshot.data.length;
                                                for(Transaction j in snapshot.data){
                                                  if(i>0){
                                                    sum = sum + j.amount;
                                                    i--;
                                                  }
                                                }

                                                return Text('${sum}' + ' FCFA',
                                                  textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                      fontWeight: FontWeight.bold, color: Colors.red),overflow: TextOverflow.ellipsis,);
                                              }
                                              else{
                                                return Text('0 CFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                    fontWeight: FontWeight.bold, color: Colors.red),overflow: TextOverflow.ellipsis,);
                                              }
                                            }),
                                      );
                                    }
                                    else{
                                      return Center(child: Text('Pardon Connectez Vous.'),);
                                    }
                                  });
                            }
                            else{
                              return Center(child: Text('Session expirée'),);
                            }
                          })
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Card(
                shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
                borderOnForeground: true,
                child: Container(
                  height: 100,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: 15,),
                      Text('Dépot'),
                      SizedBox(height: 10,),
                      FutureBuilder<String>(
                          future: UserData.getToken(),
                          builder: (context, token){
                            if(token.hasData){
                              return FutureBuilder<String>(
                                  future: UserData.getId(),
                                  builder: (context, idPerson){
                                    if(idPerson.hasData){
                                      return Expanded(
                                        child: FutureBuilder<List<Transaction>>(
                                            future: fetchalltransactionsbyuserbytype(idPerson.data, 'EW - IW', token.data),
                                            builder: (context, snapshot){
                                              if(snapshot.hasData){
                                                /*DateTime earlier = DateTime.now().subtract(Duration(days: 30));
                                                List<Transaction> transactions = snapshot.data.where((transaction) =>
                                                transaction.dateCreation == earlier).toList();*/
                                                int sum = 0;
                                                int i = snapshot.data.length;
                                                for(Transaction j in snapshot.data){
                                                  if(i>0){
                                                    sum = sum + j.amount;
                                                    i--;
                                                  }
                                                }

                                                return Text('${sum}' + ' FCFA',
                                                  textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                      fontWeight: FontWeight.bold, color: Colors.blue),overflow: TextOverflow.ellipsis,);
                                              }
                                              else{
                                                return Text('0 CFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                    fontWeight: FontWeight.bold, color: Colors.blue),overflow: TextOverflow.ellipsis,);
                                              }
                                            }),
                                      );
                                    }
                                    else{
                                      return Center(child: Text('Pardon Connectez Vous.'),);
                                    }
                                  });
                            }
                            else{
                              return Center(child: Text('Session expirée'),);
                            }
                          })
                    ],
                  ),

                ),
              ),
              Card(
                shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
                borderOnForeground: true,
                child: Container(
                  height: 100,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: 15,),
                      Text('Retrait'),
                      SizedBox(height: 10,),
                      FutureBuilder<String>(
                          future: UserData.getToken(),
                          builder: (context, token){
                            if(token.hasData){
                              return FutureBuilder<String>(
                                  future: UserData.getId(),
                                  builder: (context, idPerson){
                                    if(idPerson.hasData){
                                      return Expanded(
                                        child: FutureBuilder<List<Transaction>>(
                                            future: fetchalltransactionsbyuserbytype(idPerson.data, 'IW - EW', token.data),
                                            builder: (context, snapshot){
                                              if(snapshot.hasData){

                                                int sum = 0;
                                                int i = snapshot.data.length;
                                                for(Transaction j in snapshot.data){
                                                  if(i>0){
                                                    sum = sum + j.amount;
                                                    i--;
                                                  }
                                                }

                                                return Text('${sum}' + ' FCFA',
                                                  textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                      fontWeight: FontWeight.bold, color: Colors.yellow),overflow: TextOverflow.ellipsis,);
                                              }
                                              else{
                                                return Text('0 CFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 20,
                                                    fontWeight: FontWeight.bold, color: Colors.yellow),overflow: TextOverflow.ellipsis,);
                                              }
                                            }),
                                      );
                                    }
                                    else{
                                      return Center(child: Text('Pardon Connectez Vous.'),);
                                    }
                                  });
                            }
                            else{
                              return Center(child: Text('Session expirée'),);
                            }
                          })
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),

    );
  }
}
