import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/Wallet.dart';
import 'package:smilepay/services/WalletfindByIdPerson.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/user/UserfindOneServices.dart';
import 'package:smilepay/viewFR/user/view/Friends.dart';
import 'package:smilepay/view/admin/src/view/Operator.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletExToWalletEX.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletExToWalletIn.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletInToWalletEx.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletInToWalletIn.dart';


class UpperBlock1 extends StatefulWidget {
  static var storage = FlutterSecureStorage();
  @override
  _UpperBlockState createState() => _UpperBlockState();
}

class _UpperBlockState extends State<UpperBlock1> {
  var token = UserData.getToken();
  var type = UserData.getType();
  var balance = UserData.getBalance();
  var username = UserData.getUsername();
  var idPerson = UserData.getId().toString();
  @override
  Widget build(BuildContext context) {
    return Card(
      shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(20)
            )
        ),
        margin: EdgeInsets.symmetric(vertical: 20, horizontal: 0),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Container(
                        child: Row(
                          children: <Widget>[
                            Text('Bienvenu ', style: TextStyle( fontStyle: FontStyle.italic),),
                            FutureBuilder<String>(
                                future: UserData.getToken(),
                                builder: (context, token){
                                  if (token.hasData){
                                    return FutureBuilder<String>(
                                        future: HomePage1.storage.read(key: 'id'),
                                        builder: (context, idPerson){
                                          if(idPerson.hasData){
                                            return FutureBuilder<Wallet>(
                                                future: fetchonewalletbyid(idPerson.data, token.data),
                                                builder: (context, wallet){
                                                  if(wallet.hasData){
                                                    return Text(wallet.data.balance.toString(), style: TextStyle( fontStyle: FontStyle.italic, fontWeight: FontWeight.bold),);
                                                  }
                                                  else{
                                                    return Text('', style: TextStyle( fontStyle: FontStyle.italic, fontWeight: FontWeight.bold),);
                                                  }
                                                }
                                            );
                                          }
                                          else{
                                            return Center(child: CircularProgressIndicator(),);
                                          }
                                        }
                                    );
                                  }
                                  else{
                                    return Center(child: Text("Votre session a expiré. Svp reconnectez-vous"),);
                                  }
                                }
                            )
                      ],
                    )),
                    SizedBox(height: 5,),
                    Container(child: Text('Balance', style: TextStyle( fontStyle: FontStyle.italic),)),
                    SizedBox(height: 5,),
                    FutureBuilder(
                      future: balance,
                      builder: (context, snapshot){
                        if(snapshot.hasData){

                          return Text('${snapshot.data}' + ' FCFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 13,
                              fontWeight: FontWeight.bold, color: Colors.black),overflow: TextOverflow.ellipsis,);
                        }
                        else{
                          return Text('0 FCFA', textAlign: TextAlign.start,style: TextStyle(fontSize: 13,
                              fontWeight: FontWeight.bold, color: Colors.black),overflow: TextOverflow.ellipsis,);
                        }
                      },
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10)),color: Colors.grey[300]),
                      child: IconButton(icon: Icon(Icons.people), color: Colors.yellow[300],
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => Friends1()));
                          }),
                    ),
                    Text('Amis'),
                  ],
                )
              ],
            ),
            Divider(thickness: 1, height: 20, indent: 20, endIndent: 20,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),color: Colors.red),
                        child: IconButton(icon: Icon(Icons.compare_arrows),
                            color: Colors.white,
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=> SendWEWE1()));
                            }
                            )
                    ),
                    SizedBox(height: 10,),
                    Text('Paiement'),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),color: Colors.blue),
                        child: IconButton(icon: Icon(Icons.arrow_downward),
                            color: Colors.white,
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=> SendWEWI1()));
                            })
                    ),
                    SizedBox(height: 10,),
                    Text('Dépot'),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)), color: Colors.yellow),
                        child: IconButton(icon: Icon(Icons.arrow_upward),
                            color: Colors.white,
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=> SendWIWE1()));
                            }
                            )
                    ),
                    SizedBox(height: 10,),
                    Text('Retrait'),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)), color: Colors.green),
                        child: IconButton(icon: Icon(Icons.compare_arrows),
                            color: Colors.white,
                            onPressed: () async {
                              await UserData.getId().then((idPerson) async {
                                await UserData.getToken().then((token) async {
                                  await Navigator.push(context, MaterialPageRoute(builder: (context) => SendWIWI1()));
                                });
                              });
                            })
                    ),
                    SizedBox(height: 10,),
                    Text('Transfert'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20,)
          ],
        ),
      ),
    );
  }
}