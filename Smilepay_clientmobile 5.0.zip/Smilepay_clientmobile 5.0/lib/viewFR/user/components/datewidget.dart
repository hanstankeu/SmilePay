import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';

class MyDatePicker extends StatefulWidget {
  @override
  _MyDatePickerState createState() => _MyDatePickerState();
}

class _MyDatePickerState extends State<MyDatePicker> {

  DateTime date = DateTime.now();

  Widget _buildDatePicker(BuildContext context){
    return GestureDetector(
      onTap: (){
        showCupertinoModalPopup<void>(
            context: context,
            builder: (context){
              return BottomPicker(
                child: CupertinoDatePicker(
                  backgroundColor: CupertinoColors.systemBackground.resolveFrom(context),
                    mode: CupertinoDatePickerMode.date,
                    initialDateTime: date,
                    onDateTimeChanged: (newDateTime){
                      setState(() {
                        return date = newDateTime;
                      });
                    },
                    ),
              );
            },
        );
      },
      child: Menu(children: [
        Text(DateFormat.yMMMMd().format(date),
        style: TextStyle(
          color: CupertinoColors.inactiveGray,
        ),)
      ]),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

class BottomPicker extends StatelessWidget {
  const BottomPicker({
    Key key,
    @required this.child,
  }): assert(child != null),
      super(key: key);

  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 216,
      padding: const EdgeInsets.only(top: 6),
      color: CupertinoColors.systemBackground.resolveFrom(context),
      child: DefaultTextStyle(
          style: TextStyle(
            color: CupertinoColors.label.resolveFrom(context),
            fontSize: 22,
          ),
          child: GestureDetector(
            onTap: (){},
            child: SafeArea(
              top: false,
              child: child,
            ),
          )
      ),
    );
  }
}

class Menu extends StatelessWidget {
  const Menu({
    Key key,
    @required this.children,
  }) : assert(children != null),
       super(key : key);

  final List<Widget> children;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: const Border(
          top: BorderSide(
            color: CupertinoColors.systemYellow,
            width: 0,
          ),
          bottom: BorderSide(
            color: CupertinoColors.systemYellow,
            width: 0,
          ),
        ),
      ),
      height: 44,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: children,
      ),
    );
  }
}


