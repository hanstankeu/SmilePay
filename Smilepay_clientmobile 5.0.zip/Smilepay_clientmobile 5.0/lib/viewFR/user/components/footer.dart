import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smilepay/viewFR/user/view/RateUserlist.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/view/transaction/TransactionlistByUser.dart';
import 'package:smilepay/viewFR/user/view/walletExterne/Walletlist.dart';

class Footer1 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      height: 65,
      width: 400,
      child: new Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          //Home
          Column(
            children: <Widget>[
              Container(
                  child: IconButton(icon: Icon(Icons.home),
                      color: Colors.yellow,
                      onPressed: () async {
                       Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage1()),
                        );

                      })
              ),
              Text('Accueil', style: TextStyle(color: Colors.yellow),),
            ],
          ),
          //Pages
          Column(
            children: <Widget>[
              Container(
                  child: IconButton(icon: Icon(Icons.pages), color: Colors.yellow,
                      onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => RateUserlist1()));
                      })
              ),
              Text('Taux', style: TextStyle(color: Colors.yellow),),
            ],
          ),
          //Wallets
          Column(
            children: <Widget>[
              Container(
                  child: IconButton(
                      icon: Icon(Icons.account_balance_wallet),
                      color: Colors.yellow,
                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => WalletUserlist1()));
                      })
              ),
              Text('Wallets', style: TextStyle(color: Colors.yellow),),
            ],
          ),
          //Settings
          Column(
            children: <Widget>[
              Container(
                  child: IconButton(icon: Icon(Icons.compare_arrows),
                      color: Colors.yellow, padding: EdgeInsets.all(10), onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByUser1()));
                      })
              ),
              Text('Transactions', style: TextStyle(color: Colors.yellow),),
            ],
          ),
        ],
      ),
    );
  }
}