import 'package:smilepay/viewFR/user/view/contacts/app-contact.class.dart';
import 'package:smilepay/viewFR/user/view/contacts/components/contacts-list.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletExToWalletEX.dart';
import 'package:smilepay/viewFR/user/view/transaction/WalletInToWalletIn.dart';


/* void maine() => runApp(Contact());*/

class Contacte1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      title: 'Mes Contacts',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
      ),
      home: MyHomePage(title: 'Mes Contacts'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<AppContact1> contacts = [];
  List<AppContact1> contactsFiltered = [];
  Map<String, Color> contactsColorMap = new Map();
  TextEditingController searchController = new TextEditingController();
  bool contactsLoaded = false;

  @override
  void initState() {
    super.initState();
    getPermissions();
  }
  getPermissions() async {
    if (await Permission.contacts.request().isGranted) {
      getAllContacts();
      searchController.addListener(() {
        filterContacts();
      });
    }
  }

  String flattenPhoneNumber(String phoneStr) {
    return phoneStr.replaceAllMapped(RegExp(r'^(\+)|\D'), (Match m) {
      return m[0] == "+" ? "+" : "";
    });
  }

  getAllContacts() async {
    List colors = [
      Colors.green,
      Colors.indigo,
      Colors.yellow,
      Colors.orange
    ];
    int colorIndex = 0;
    List<AppContact1> _contacts = (await ContactsService.getContacts()).map((contact) {
      Color baseColor = colors[colorIndex];
      colorIndex++;
      if (colorIndex == colors.length) {
        colorIndex = 0;
      }
      return new AppContact1(info: contact, color: baseColor);
    }).toList();
    setState(() {
      contacts = _contacts;
      contactsLoaded = true;
    });
  }

  filterContacts() {
    List<AppContact1> _contacts = [];
    _contacts.addAll(contacts);
    if (searchController.text.isNotEmpty) {
      _contacts.retainWhere((contact) {
        String searchTerm = searchController.text.toLowerCase();
        String searchTermFlatten = flattenPhoneNumber(searchTerm);
        String contactName = contact.info.displayName.toLowerCase();
        bool nameMatches = contactName.contains(searchTerm);
        if (nameMatches == true) {
          return true;
        }

        if (searchTermFlatten.isEmpty) {
          return false;
        }

        var phone = contact.info.phones.firstWhere((phn) {
          String phnFlattened = flattenPhoneNumber(phn.value);
          return phnFlattened.contains(searchTermFlatten);
        }, orElse: () => null);

        return phone != null;
      });
    }
    setState(() {
      contactsFiltered = _contacts;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isSearching = searchController.text.isNotEmpty;
    bool listItemsExist = (
        (isSearching == true && contactsFiltered.length > 0) ||
        (isSearching != true && contacts.length > 0)
    );
    return Scaffold(
     appBar: AppBar(
        title: Text('Mes Contacts', textAlign: TextAlign.center,),
        centerTitle: true,
       leading: IconButton(
         onPressed: () {
           Navigator.push(context, MaterialPageRoute(builder: (context) => SendWEWE1()));
         },
         icon: Icon(Icons.arrow_back),
         color: Colors.black,
       ),
       actions: <Widget>[
         IconButton(
           icon: Icon(
             Icons.refresh,
             color: Colors.black,
           ),
           onPressed: () {
             Navigator.push(context, MaterialPageRoute(builder: (context) => Contacte1()));
           },
         )
       ],
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        backgroundColor: Theme.of(context).primaryColorDark,
        onPressed: () async{
          try{
           Contact contact = await ContactsService.openContactForm();
               if (context != null){
                 getAllContacts();
               }

          }on FormOperationException catch(e){
            switch(e.errorCode){
              case FormOperationErrorCode.FORM_OPERATION_CANCELED:
              case FormOperationErrorCode.FORM_COULD_NOT_BE_OPEN:
              case FormOperationErrorCode.FORM_OPERATION_UNKNOWN_ERROR:
                print(e.toString());
            }
          }
        },
      ),

      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: <Widget>[
/*            Align(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: IconButton(
                  icon: Icon(Icons.refresh),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Contactes()));
                  },
                ),
              ),
              alignment: Alignment.topRight,
            ),*/
            Container(

              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  labelText: 'Recherche',
                  border: new OutlineInputBorder(
                    borderSide: new BorderSide(
                      color: Theme.of(context).primaryColor
                    )
                  ),
                  prefixIcon: Icon(
                    Icons.search,
                    color: Theme.of(context).primaryColor
                  )
                ),
              ),
            ),
            contactsLoaded == true ?  // if the contacts have not been loaded yet
              listItemsExist == true ?  // if we have contacts to show
              ContactsList1(
                reloadContacts: (){
                  getAllContacts();
                },
                contacts: isSearching == true ? contactsFiltered : contacts,
              ) : Container(
                padding: EdgeInsets.only(top: 40),
                child: Text(
                  isSearching ?'Pas de resultat pour cette Recherche' : 'Aucun contacts existe',
                  style: TextStyle(color: Colors.grey, fontSize: 20),
                )
              ) :
            Container(  // still loading contacts
              padding: EdgeInsets.only(top: 40),
              child: Center(
                child: CircularProgressIndicator(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
