import 'package:smilepay/viewFR/user/view/contacts/app-contact.class.dart';
import 'package:smilepay/viewFR/user/view/contacts/components/contact-avatar.dart';
import 'package:smilepay/viewFR/user/view/contacts/pages/contact-details.dart';
import 'package:flutter/material.dart';


class ContactsList1 extends StatelessWidget {
  final List<AppContact1> contacts;
   Function() reloadContacts;
  ContactsList1({Key key, this.contacts, this.reloadContacts}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          AppContact1 contact = contacts[index];

          return ListTile(
            onTap: (){
              Navigator.of(context).push(MaterialPageRoute(
              builder:(BuildContext context) => ContactDetails1(
                contact,
                onContactDelete:(AppContact1 _contact){
                  reloadContacts();
                  Navigator.of(context).pop();
                },
                onContactUpdate:(AppContact1 _contact){
                  reloadContacts();
                },
              )
              ));
            },
              title: Text(contact.info.displayName),
              subtitle: Text(
                  contact.info.phones.length > 0 ? contact.info.phones.elementAt(0).value : ''
              ),
              leading: ContactAvatar1(contact, 36)
          );
        },
      ),
    );
  }
}
