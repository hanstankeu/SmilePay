import 'package:smilepay/viewFR/user/view/contacts/app-contact.class.dart';
import 'package:smilepay/viewFR/user/view/contacts/utils/get-color-gradient.dart';
import 'package:flutter/material.dart';

class ContactAvatar1 extends StatelessWidget {
  ContactAvatar1(this.contact, this.size);
  final AppContact1 contact;
  final double size;
  @override
  Widget build(BuildContext context) {
    return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
            shape: BoxShape.circle, gradient: getColorGradient(contact.color)),
        child: (contact.info.avatar != null && contact.info.avatar.length > 0)
            ? CircleAvatar(
                backgroundImage: MemoryImage(contact.info.avatar),
              )
            : CircleAvatar(
                child: Text(contact.info.initials(),
                    style: TextStyle(color: Colors.white)),
                backgroundColor: Colors.transparent));
  }
}
