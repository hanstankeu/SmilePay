import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';

class AppContact1 {
  final Color color;
  Contact info;

  AppContact1({Key key, this.color, this.info});
}