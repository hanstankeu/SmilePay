import 'dart:convert';
import 'dart:io' as Io;
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_password_strength/flutter_password_strength.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/model/UserCard.dart';
import 'package:smilepay/services/authentication/RegistrationServices.dart';
import 'package:smilepay/view/user/view/authentication/signin.dart';
import 'package:smilepay/viewFR/user/view/authentication/signin.dart';
import 'package:image_picker/image_picker.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/viewFR/user/view/transaction/custom_alert_dialog.dart';

//date bottom picker
class BottomPicker extends StatelessWidget {
  const BottomPicker({
    Key key,
    @required this.child,
  }): assert(child != null),
        super(key: key);

  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 216,
      padding: const EdgeInsets.only(top: 6),
      color: Color(0xFFFFFDEF),
      child: DefaultTextStyle(
          style: TextStyle(
            color: CupertinoColors.label.resolveFrom(context),
            fontSize: 22,
          ),
          child: GestureDetector(
            onTap: (){},
            child: SafeArea(
              top: false,
              child: child,
            ),
          )
      ),
    );
  }
}
//date picker menu
class Menu extends StatelessWidget {
  const Menu({
    Key key,
    @required this.children,
  }) : assert(children != null),
        super(key : key);

  final List<Widget> children;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: const Border(
          top: BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
          bottom: BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
      ),
      height: 44,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: children,
      ),
    );
  }
}

class SignUp1 extends StatefulWidget {
  const SignUp1({
    Key key,
    @required Size media,
  })  : _media = media,
        super(key: key);

  final Size _media;

  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp1> {
  final _formKey = GlobalKey<FormState>();

  DateTime date = DateTime.now();
  final _picker = ImagePicker();
  PickedFile imageFile;
  String path;
  dynamic _pickImageError;
  //attachment gallery open
  openGalley(BuildContext context) async {
    try{
      var picture = await _picker.getImage(source: ImageSource.gallery);
      setState(() {
        imageFile = picture;
        final bytes = Io.File(File(imageFile.path).readAsStringSync()).readAsBytesSync();
        _attachment = Base64Encoder().convert(bytes);
        path = _attachment.toString();

      });
    }catch (e) {
      setState(() {
        _pickImageError = e;
        print(e);
      });
    }
      Navigator.of(context).pop;
  }
  //attachment camera open
  openCamera(BuildContext context) async {
    var picture = await _picker.getImage(source: ImageSource.camera);
    setState((){
      imageFile = picture;
      final bytes = Io.File(File(imageFile.path).readAsStringSync()).readAsBytesSync();
      _attachment = Base64Encoder().convert(bytes);
      path = _attachment.toString();
    });
    Navigator.of(context).pop;
  }
  //image picker dialog box
  Future<void> showChoiceDialog(BuildContext context){
    return showDialog(context: context, builder: (BuildContext context){
      return CupertinoAlertDialog(
        title: Text('Faite Votre Choix'),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Padding(padding: EdgeInsets.all(8)),
              GestureDetector(
                child: Text('Gallerie'),
                onTap: (){
                  openGalley(context);
                },
              ),
              Padding(padding: EdgeInsets.all(6)),
              GestureDetector(
                child: Text('Camera'),
                onTap: (){
                  openCamera(context);
                },
              )
            ],
          ),
        ),
      );
    });
  }

  List<DropdownMenuItem> types = [
    DropdownMenuItem(child: Text('Moral'), value: 'MORAL_PERSON',),
    DropdownMenuItem(child: Text('Physical'), value: 'PHYSICAL_PERSON',),
  ];

  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password est Requis'),
    MinLengthValidator(8, errorText: 'Password doit Contenir au moins 8 charactères'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])', errorText: 'password doit avoir au moin un charactère special')
  ]);

  final codeSecretValidator = MultiValidator([
    RequiredValidator(errorText: 'CodeSecret est requis'),
    MinLengthValidator(4, errorText: 'CodeSecret doit contenir au moins 4 characters'),
    PatternValidator(r'1234567890', errorText: 'CodeSecret doit avoir au moin un charactère special')
  ]);

  final emailValidator = MultiValidator([
    RequiredValidator(errorText: 'Email est requis'),
    EmailValidator(errorText: 'Entrez une Email valide')
  ]);

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone est requis'),
    MinLengthValidator(9, errorText: 'Telephone doit Contenir au moins 9 characters'),
    MaxLengthValidator(9, errorText: 'Telephone doit Contenir au moins 9 characters')
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'Ce Champs est requis'),
  ]);

  //UserCard params
  String _name = '';
  String _surname = '';
  String _username = '';
  String _password = '';
  String _codeSecret ='';
  String _email = '';
  String _phone = '';
  String _address = '';
  DateTime _birthday;
  String _sexe = null ;
  String _type = null ;
  int _amountuser=0;
  String _receiveuser='';

  var temp;
  bool _showPassword = false;
  bool _showPassword1 = false;
  String _confirmpassword;

  //National Card params
  static String _idCard = null;
  static String _number = '';
  static DateTime _dateOfIssue;
  static DateTime _dateOfExpiration;
  static String _attachment;
  static DateTime _dateCreationCNI;
  static DateTime _dateModificationCNI;

  @override
  Widget build(BuildContext context) {
    void showAlertDialogParam(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    Center(child:Text('Changer La Langue !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn1()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.blue,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'FRANCAIS',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.greenAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'ANGLAIS',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              ),
            );
          });
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: <Widget>[
          ////////////////////////////
          /////////////////////////////////
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black, Colors.yellow]
                )
            ),
            width: double.infinity,
            height: double.infinity,
          ),
          Container(
            alignment: Alignment.topCenter,
            child: Image.asset(
                'images/smilepaylogo.png',
              width: 170.0,
              height: 150.0,
              )
          ),
          SizedBox(height: 5,),

          Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 170, 20, 10),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: Colors.white,
                ),
                child: Center(
                  child: Form(
                    key: _formKey,
                      child: ListView(
                        children: <Widget>[
                          //title
                          Text('Créer un Compte', textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)),


                        //  \|./////////////////////////////////////////////////////////////////////////////.|/
                          //username
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _username = value;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: 'Nom Utilisateur',
                                    icon: Icon(Icons.perm_identity, color: Colors.black,),
                                  ),
                                  validator: formfieldValidator,
                                ),
                              ),
                            ),
                          ),

                          //Code_Secret
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 5.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _codeSecret = value;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: 'codeSecret',
                                    icon: Icon(Icons.lock_outline, color: Colors.black,),
                                    suffixIcon: GestureDetector(
                                      onTap: (){
                                        setState(() {
                                          _showPassword = !_showPassword;
                                        });
                                      },
                                      child: Icon(
                                        _showPassword ? Icons.visibility : Icons.visibility_off,
                                      ),
                                    ),
                                  ),
                                  obscureText: !_showPassword,
                                  validator: codeSecretValidator,

                                ),
                              ),
                            ),
                          ),

                          //email
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                            child: Material(
                              borderRadius: BorderRadius.circular(40.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _email = value;
                                  },
                                  onSaved: (value){
                                    _email = value;
                                  },
                                  decoration: InputDecoration(
                                    border:InputBorder.none,
                                    icon: Icon(Icons.alternate_email, color: Colors.black,),
                                    labelText: "Email",
                                    fillColor: Colors.black,
                                  ),
                                  validator: emailValidator,
                                ),
                              ),
                            ),
                          ),

                          //password
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 5.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _password = value;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: 'Mot de Passe',
                                    icon: Icon(Icons.lock_outline, color: Colors.black,),
                                    suffixIcon: GestureDetector(
                                      onTap: (){
                                        setState(() {
                                          _showPassword = !_showPassword;
                                        });
                                      },
                                      child: Icon(
                                        _showPassword ? Icons.visibility : Icons.visibility_off,
                                      ),
                                    ),
                                  ),
                                  obscureText: !_showPassword,
                                  validator: passwordValidator,

                                ),
                              ),
                            ),
                          ),

                          //password strength
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
                            child: FlutterPasswordStrength(
                                password: _password,
                                strengthCallback: (strength){
                                  debugPrint(strength.toString());
                                }
                            ),
                          ),

                          //confirm password
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _confirmpassword = value;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: 'Confirmer le mot de Passe',
                                    icon: Icon(Icons.lock_outline, color: Colors.black,),
                                    suffixIcon: GestureDetector(
                                      onTap: (){
                                        setState(() {
                                          _showPassword1 = !_showPassword1;
                                        });
                                      },
                                      child: Icon(
                                        _showPassword1 ? Icons.visibility : Icons.visibility_off,
                                      ),
                                    ),
                                  ),
                                  obscureText: !_showPassword1,
                                  validator: passwordValidator,
                                ),
                              ),
                            ),
                          ),

                          //tel
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  cursorColor: Colors.black,
                                  onChanged: (value){
                                    _phone = value;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: "Telephone", fillColor: Colors.black,
                                    icon: Icon(Icons.phone, color: Colors.black,)
                                  ),
                                  validator: telephoneValidator,
                                ),
                              ),
                            ),
                          ),
                          //date of birth

                         ////////////////////////////////////////////////////////////////./
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                            child: Material(
                              borderRadius: BorderRadius.circular(25.0),
                              color: Colors.yellow.withOpacity(0.4),
                              elevation: 0.0,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 12.0),
                                child: Row(
                                  children: <Widget>[
                                    IconButton(
                                      highlightColor: Colors.blue,
                                      icon: Icon(Icons.calendar_today),
                                      onPressed: () {
                                        showCupertinoModalPopup<void>(
                                          context: context,
                                          builder: (context){
                                            return BottomPicker(
                                              child: CupertinoDatePicker(
                                                backgroundColor: Color(0xFFFFFDEF),
                                                mode: CupertinoDatePickerMode.date,
                                                initialDateTime: _birthday,
                                                onDateTimeChanged: (newDateTime){
                                                  setState(() {
                                                    return _birthday = newDateTime;
                                                  });
                                                },
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),

                                    Expanded(
                                      child: FlatButton(
                                        onPressed: (){
                                          showCupertinoModalPopup<void>(
                                            context: context,
                                            builder: (context){
                                              return BottomPicker(
                                                child: CupertinoDatePicker(
                                                  backgroundColor: Color(0xFFFFFDEF),
                                                  mode: CupertinoDatePickerMode.date,
                                                  initialDateTime: _birthday,
                                                  onDateTimeChanged: (newDateTime){
                                                    setState(() {
                                                      return _birthday = newDateTime;
                                                    });},
                                                ),
                                              );
                                              },
                                          );
                                          },
                                        child: Menu(children: [
                                          Text( _birthday == null? 'Année de Naissance' : 'Année de Naissance : ' + _birthday.toString().substring(0, 10),
                                            style: TextStyle(
                                              color: CupertinoColors.black,
                                            ),)
                                        ]),
                                      ),
                                    ),
                                  ],
                                ),
                               ),
                            ),
                          ),

                        //  ///////////////////////////////////////////////////////////////////////|./
                          SizedBox(height: 15,),
                          //forgot password
/*                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: InkWell(
                              onTap: (){
                                print('http://www.google.com');
                              },
                              child: Text(
                                "Google",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ),*/

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(width: 20,),
                              //sign up
                              Expanded(
                                child: Material(
                                    borderRadius: BorderRadius.circular(15.0),
                                    color: Colors.yellow,
                                    elevation: 0.0,
                                    child: MaterialButton(
                                      onPressed: () {
                                        if(_formKey.currentState.validate()){
                                          _formKey.currentState.save();
                                          if(_password != _confirmpassword){
                                            print('Le mot de passe ne match pas');
                                            Fluttertoast.showToast(msg: "Le mot de passe ne match pas",
                                                toastLength: Toast.LENGTH_LONG,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 5,
                                                backgroundColor: Colors.black,
                                                textColor: Colors.yellowAccent,
                                                fontSize: 15.0
                                            );
                                          }
                                          else{
                                            registration(UserCard( _name, _surname,
                                                _username, _password,_codeSecret, _email, _phone, _sexe,
                                                _address, _type, _birthday, null, _amountuser, _receiveuser)).then((response) async {
                                              if(response.statusCode == 200){
                                                print(response.statusCode);
                                                await Fluttertoast.showToast(msg: response.body.substring(9,response.body.length),
                                                    toastLength: Toast.LENGTH_LONG,
                                                    gravity: ToastGravity.CENTER,
                                                    timeInSecForIosWeb: 7,
                                                    backgroundColor: Colors.black,
                                                    textColor: Colors.yellow, fontSize: 15.0
                                                );
                                                Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn1()));
                                              }
                                              else {
                                                print(response.statusCode.toString());
                                                await Fluttertoast.showToast(msg: response.body.substring(9, response.body.length),
                                                    toastLength: Toast.LENGTH_LONG,
                                                    gravity: ToastGravity.CENTER,
                                                    timeInSecForIosWeb: 5,
                                                    backgroundColor: Colors.black,
                                                    textColor: Colors.yellowAccent,
                                                    fontSize: 15.0
                                                );
                                              }
                                            });
                                          }
                                        }


                                      },
                                      minWidth: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "Inscription",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20.0),
                                      ),
                                    )
                                ),
                              ),
                              SizedBox(width: 10,),
                              //sign in
                              Expanded(
                                child: Material(
                                    borderRadius: BorderRadius.circular(15.0),
                                    color: Colors.yellow[100],
                                    elevation: 0.0,
                                    child: MaterialButton(
                                      onPressed: () {
                                        Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn1()));
                                      },
                                      minWidth: MediaQuery.of(context).size.width,
                                      child: Text(
                                        "Connexion",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20.0),
                                      ),
                                    )
                                ),
                              ),
                              SizedBox(width: 10,),
                            ],
                          ),
                          SizedBox(height: 20,),
                          //Settings
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: InkWell(
                              onTap: () {
                                showAlertDialogParam(context);
                              },
                              child: Material(
                                shadowColor: Colors.grey,
                                elevation: 10,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                color: Colors.blue,
                                child: Container(
                                  alignment: Alignment.center,
                                  height: 45,
                                  width: 160,
                                  child: ListTile(
                                    title: Text('Paramètre', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: Colors.black87),),
                                    leading: Icon(Icons.settings, color: Colors.redAccent,),
                                  ),

                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
