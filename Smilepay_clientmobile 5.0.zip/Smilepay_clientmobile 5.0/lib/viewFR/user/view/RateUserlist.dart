import 'package:flutter/material.dart';
import 'package:smilepay/model/Rate.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/rate/RatelistServices.dart';


class RateUserlist1 extends StatefulWidget {
  RateUserlist1({Key key}) : super(key:key);
  @override
  _RateUserlistState createState() => _RateUserlistState();
}

class _RateUserlistState extends State<RateUserlist1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Listes Des Taux', style: TextStyle(color: Colors.yellow),),
        centerTitle: true,
      ),
      body: Container(
        color: Colors.yellow[100],
          padding: EdgeInsets.all(10),
          child:  FutureBuilder<String>(
              future: UserData.getToken(),
              builder: (context, token){
                if(token.hasData){
                  return  FutureBuilder<List<Rate>>(
                    future: fetchallrates(token.data),
                    builder: (context, snapshot){
                      if (snapshot.hasData){
                        return ListView.builder(
                            itemCount: snapshot.data.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Card(
                                elevation: 10,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 8),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text('Valeur : ' +
                                          snapshot.data[index].value.toString(),
                                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),

                                      ),
                                      SizedBox(height: 5,),
                                      Text('Montant Minimum : ' +
                                          snapshot.data[index].minimum.toString(),
                                        style: TextStyle(fontSize: 12),
                                      ),
                                      Text('Montant Maximum : ' +
                                          snapshot.data[index].maximum.toString(),
                                        style: TextStyle(fontSize: 12),
                                      )
                                    ],
                                  ),
                                ),
                              );

                            });
                      }else if(snapshot.hasError){
                        print(snapshot.error);
                      }
                      return  Center(child: CircularProgressIndicator());},
                  );
                }
                else{
                  return Center(child: CircularProgressIndicator());
                }
              }
          )
      ),
    );
  }
}
