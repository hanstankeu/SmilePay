import 'dart:io' as Io;
import 'package:flutter/rendering.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_password_strength/flutter_password_strength.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/services/authentication/ModifyPasswordServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/viewFR/user/components/myappbar.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:form_field_validator/form_field_validator.dart';


class ModifyPassword1 extends StatefulWidget {
  @override
  _ModifyPasswordState createState() => _ModifyPasswordState();
}

class _ModifyPasswordState extends State<ModifyPassword1> {

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'Ce Champ est requis'),
  ]);
  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password est requis'),
    MinLengthValidator(8, errorText: 'Password doit avoir au moins 8 charactères'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])', errorText: 'password doit contenir au moins un charactère special')
  ]);

  final _formKey = GlobalKey<FormState>();
  // params
  String _password = '';

  var temp;
  bool _showPassword = false;
  bool _showPassword1 = false;
  String _confirmpassword;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.yellow[100],
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Mise à Jour du mot de Passe', style: TextStyle(color: Colors.yellow),),
          centerTitle: true,
        ),
        body: Container(
          child: Center(
            child: Form(
                key: _formKey,
                child: ListView(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    //password
                     Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _password = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Mot de Passe',
                              icon: Icon(Icons.lock_outline, color: Colors.black,),
                              suffixIcon: GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _showPassword = !_showPassword;
                                  });
                                },
                                child: Icon(
                                  _showPassword ? Icons.visibility : Icons.visibility_off,
                                ),
                              ),
                            ),
                            obscureText: !_showPassword,
                            validator: passwordValidator
                          ),
                        ),
                      ),
                    ),
                    /**
                     * password strength
                     */
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
                      child: FlutterPasswordStrength(
                          password: _password,
                          strengthCallback: (strength){
                            debugPrint(strength.toString());
                          }
                      ),
                    ),
                    //confirm password
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _confirmpassword = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Confirmez votre Password',
                              icon: Icon(Icons.lock_outline, color: Colors.black,),
                              suffixIcon: GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _showPassword1 = !_showPassword1;
                                  });
                                },
                                child: Icon(
                                  _showPassword1 ? Icons.visibility : Icons.visibility_off,
                                ),
                              ),
                            ),
                            obscureText: !_showPassword1,
                            validator: passwordValidator,
                          ),
                        ),
                      ),
                    ),
                    //sign up
                    Padding(
                      padding:
                      const EdgeInsets.fromLTRB(50.0, 30.0, 50.0, 8.0),
                      child: Material(
                          borderRadius: BorderRadius.circular(20.0),
                          color: Colors.yellow,
                          elevation: 0.0,
                          child: MaterialButton(
                            onPressed: () async {
                              if(_formKey.currentState.validate()){
                                _formKey.currentState.save();
                                if(_password != _confirmpassword){
                                  await Fluttertoast.showToast(msg: "Les Passwords ne sont pas Similaire",
                                      toastLength: Toast.LENGTH_LONG,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 3,
                                      backgroundColor: Colors.black,
                                      textColor: Colors.yellowAccent,
                                      fontSize: 15.0);
                                }else{
                                  await HomePage1.storage.read(key: "token").then((token){
                                    UserData.getId().then((idPerson){
                                      modifypassword(idPerson, _password, token).then((response) async {
                                        if(response.statusCode == 200){
                                          print(response.statusCode);
                                          await Fluttertoast.showToast(msg: "Password modifié ! ",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 5,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                        else if(response.statusCode == 401){
                                          print(response.statusCode.toString());
                                        }
                                        else if(response.statusCode == 500){
                                          print(response.statusCode.toString());
                                          await Fluttertoast.showToast(msg: "Serveur instable",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 3,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                      });
                                    });
                                  });
                                }

                              }


                            },
                            minWidth: MediaQuery.of(context).size.width,
                            child: Text(
                              "Mise à jour",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20.0),
                            ),
                          )
                      ),
                    ),
                    //sign in
                  ],
                )
            ),
          ),
        )
    );
  }
}