import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Message.dart';
import 'package:smilepay/services/MessageServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/admin/src/commons/theme.dart';
import 'package:smilepay/view/admin/src/widget/user_details.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';

class ContactUs1 extends StatefulWidget {
  const ContactUs1({
    Key key,
    @required Size media,
  })  : _media = media,
        super(key: key);

  final Size _media;

  @override
  _ContactUsState createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs1> {
  final _formkey = GlobalKey<FormState>();
  String emailUser;
  /// Message variables
  String _name;
  String _idMessage;
  String _emailReceiver = 'hanstankeu@gmail.com';
  String _content;
  String _title;

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'Ce Champ est requis'),
  ]);


  @override
  Widget build(BuildContext context) {
    void _showDialog() {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          /**
           * return object of type Dialog
           */
          return AlertDialog(
            title: Text(
              'Correcte',
              style: TextStyle(
                color: Colors.yellow[500],
              ),
            ),
            content: Text('Votre Message a été envoyé.'),
            actions: <Widget>[
              // usually buttons at the bottom of the dialog
              FlatButton(
                child:  Text('Fermer'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }

    /*
    Interface content
     */
    return Scaffold(
      backgroundColor: Colors.yellow[100],
      appBar: AppBar(
        title: Text('Contactez-Nous', style: TextStyle(color: Colors.yellow),),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: Container(
        child: Center(
          child: Form(
              key: _formkey,
              child: ListView(
                children: <Widget>[
                  SizedBox(height: 20,),
                  //subject
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                    child: Material(
                      borderRadius: BorderRadius.circular(25.0),
                      color: Colors.yellow.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12.0),
                        child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _title = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Object',
                              icon: Icon(Icons.subject, color: Colors.black,),
                            ),
                            validator: formfieldValidator
                        ),
                      ),
                    ),
                  ),

                  //confirm password
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                    child: Material(
                      borderRadius: BorderRadius.circular(25.0),
                      color: Colors.yellow.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12.0),
                        child: TextFormField(
                          keyboardType: TextInputType.text,
                          maxLines: 6,
                          cursorColor: Colors.black,
                          onChanged: (value){
                            _content = value;
                          },
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            labelText: 'Ecrirez votre Message ici',
                            //icon: Icon(Icons.lock_outline, color: Colors.black,),
                          ),
                          validator: formfieldValidator,
                        ),
                      ),
                    ),
                  ),
                  //sign up
                  Padding(
                    padding:
                    const EdgeInsets.fromLTRB(50.0, 30.0, 50.0, 8.0),
                    child: Material(
                        borderRadius: BorderRadius.circular(20.0),
                        color: Colors.yellow,
                        elevation: 0.0,
                        child: MaterialButton(
                          onPressed: () async {
                            if(_formkey.currentState.validate()){
                              _formkey.currentState.save();
                              await HomePage1.storage.read(key: 'token').then((token) async {
                                // await UserData.getEmail().then((emailUser){});
                                sendmessage(Message(_idMessage, _emailReceiver, _content, _title), token).then((response)async{
                                  if(response.statusCode == 200){
                                    print(response.statusCode);
                                    _showDialog();
                                  }
                                  else if(response.statusCode == 401){
                                    print(response.statusCode.toString());
                                  }
                                  else if(response.statusCode == 409){
                                    print(response.statusCode.toString());
                                    await Fluttertoast.showToast(msg: "Ce message était déja envoyé à cet utilisateur.",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 5,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 15.0
                                    );
                                  }
                                  else if(response.statusCode == 500){
                                    print(response.statusCode.toString());
                                    await Fluttertoast.showToast(msg: "Serveur inavalide. Pardon Veillez Recommencer.",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 5,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 15.0
                                    );
                                  }
                                });
                              });
                            }
                          },
                          minWidth: MediaQuery.of(context).size.width,
                          child: Text(
                            "Envoyer",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20.0),
                          ),
                        )
                    ),
                  ),
                  //sign in
                ],
              )
          ),
        ),
      ),
    );
  }
}
