import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/services/authentication/LogOutServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/components/footer.dart';
import 'package:smilepay/viewFR/user/components/myappbar.dart';
import 'package:smilepay/viewFR/user/view/authentication/signin.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/view/profile/ContactUs.dart';
import 'package:smilepay/viewFR/user/view/profile/completeInformations.dart';
import 'package:smilepay/viewFR/user/view/profile/modifyPassword.dart';
import 'package:smilepay/viewFR/user/view/profile/updateprofile.dart';
import 'package:smilepay/viewFR/user/view/transaction/custom_alert_dialog.dart';

class Profile1 extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile1> {
  @override
  Widget build(BuildContext context) {
    void showAlertDialogParam(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    Center(child:Text('Changer de Langue !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage1()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.blue,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'FRANCAIS',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.greenAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'ANGLAIS',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                  ],
                ),

              ),
            );
          });
    }

    final _media = MediaQuery.of(context).size;
    print(_media);
    return Scaffold(
      backgroundColor: Colors.yellow[100],
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Profile', style: TextStyle(color: Colors.yellow),),
        centerTitle: true,
      ),
      body: Container(
        child: ListView(
          children: <Widget>[
            /**
             * Contact us
             */
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ContactUs1(media: _media,)));
              },
              child: ListTile(
                title: Text('Contact us'),
                leading: Icon(Icons.textsms, color: Colors.yellow[600],),
              ),
            ),

            /**
             * Personal informations
             */
            InkWell(
              onTap: (){},
              child: ListTile(
                title: Text('Informations Personels'),
                leading: Icon(Icons.person, color: Colors.yellow[600],),
              ),
            ),

            /**
             * Complete informations
             */
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => CompleteInfos1()));
              },
              child: ListTile(
                title: Text('Complete profile'),
                leading: Icon(Icons.info_outline, color: Colors.yellow[600],),
              ),
            ),

            /**
             * Update profile
             */
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => UpdateProfile1()));
              },
              child: ListTile(
                title: Text('Mise à Jour du Profile'),
                leading: Icon(Icons.account_circle, color: Colors.yellow[600],),
              ),
            ),

            /**
             * Change password
             */
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => ModifyPassword1()));
              },
              child: ListTile(
                title: Text('Mise à Jour du Password'),
                leading: Icon(Icons.lock_open, color: Colors.yellow[600],),
              ),
            ),

            //Settings
            InkWell(
              onTap: (){
                showAlertDialogParam(context);
              },
              child: ListTile(
                title: Text('Paramètre'),
                leading: Icon(Icons.settings, color: Colors.yellow,),
              ),
            ),


            /**
             * Log Out
             */
            InkWell(
              onTap: () async {
                await UserData.getId().then((idPerson) async {
                  await HomePage1.storage.read(key: 'token').then((token) async {
                    await logout(idPerson, token).then((response) async {
                      if(response.statusCode == 200){
                        print(response.statusCode);
                        await Fluttertoast.showToast(msg: "Désactiver !!! ",
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 5,
                            backgroundColor: Colors.black,
                            textColor: Colors.yellowAccent,
                            fontSize: 15.0);
                        //HomePage.storage.deleteAll();
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn1()));
                      }
                      if(response.statusCode == 401){
                        print(response.statusCode.toString());
                        await Fluttertoast.showToast(msg: "Pas Désactiver",
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 5,
                            backgroundColor: Colors.black,
                            textColor: Colors.yellowAccent,
                            fontSize: 15.0);
                      }
                    });
                  });
                });
              },
              child: ListTile(
                title: Text('Sortir'),
                leading: Icon(Icons.exit_to_app, color: Colors.yellow[600],),
              ),
            ),
          ],
        ),
      ),
      persistentFooterButtons: <Widget>[
        Footer1()
      ],
    );
  }
}
