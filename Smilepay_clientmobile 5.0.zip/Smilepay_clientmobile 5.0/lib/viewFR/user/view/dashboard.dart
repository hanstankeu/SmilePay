import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserTypeServices.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/viewFR/user/components/footer.dart';
import 'package:smilepay/viewFR/user/components/lowerblocks.dart';
import 'package:smilepay/viewFR/user/components/myappbar.dart';
import 'package:smilepay/viewFR/user/components/mydrawer.dart';
import 'package:smilepay/viewFR/user/components/upperblock.dart';

class HomePage1 extends StatefulWidget {
  static var storage = FlutterSecureStorage();
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage1> {
  var noms = UserData.getNomPrenom();
  var username = UserData.getUsername();
  var email = UserData.getEmail();
  var token = UserData.getToken();
  var balance = UserData.getBalance();

  refreshPage(){
    setState(() {
      noms = UserData.getNomPrenom();
      username = UserData.getUsername();
      email = UserData.getEmail();
      token = UserData.getToken();
      balance = UserData.getBalance();
    });
  }

  @override
  Widget build(BuildContext context) {
    Future<bool> _onWillPop() async {
      return (await showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          title: new Text('Etes Vous Sur?'),
          content: new Text('Voulez-Vous Quitter SmilePay ?'),
          actions: <Widget>[
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: new Text('NON'),
            ),
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: new Text('OUI'),
            ),
          ],
        ),
      )) ?? false;
    }
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: Colors.yellow[100],
        appBar: MyAppBar1(),
        drawer: MyDrawer1(),
        body: Container(
          margin: EdgeInsets.symmetric(vertical: 0, horizontal: 20),
          child: ListView(
            children: <Widget>[
              SizedBox(height: 20,),
              UpperBlock1(),
              SizedBox(height: 20,),
              LowerBlocks1(),

            ],
          ),
        ),
        persistentFooterButtons: <Widget>[
          Footer1()
        ],
      ),
    );
  }
}