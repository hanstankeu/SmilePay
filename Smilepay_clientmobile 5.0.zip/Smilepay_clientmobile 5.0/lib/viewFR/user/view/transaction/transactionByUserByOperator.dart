import 'package:flutter/material.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserByOperatorServices.dart';
import 'package:smilepay/viewFR/user/components/footer.dart';
import 'package:smilepay/viewFR/user/components/myappbar.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';

class TransactionByUserByOperator1 extends StatefulWidget {
  String idPersonne;
  String code;
  String token;

TransactionByUserByOperator1(this.idPersonne, this.code, this.token);

  @override
  _TransactionByUserByOperatorState createState() => _TransactionByUserByOperatorState();
}

class _TransactionByUserByOperatorState extends State<TransactionByUserByOperator1> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar1(),
      backgroundColor: Colors.yellow[100],
      body: Container(
          padding: EdgeInsets.all(10),
          child:  FutureBuilder<List<Transaction>>(
            future: fetchalltransactionsbyuserbyoperator(widget.idPersonne, widget.code, widget.token),
            builder: (context, snapshot){
              if (snapshot.hasData){
                return ListView.builder(
                    itemCount: snapshot.data.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Card(
                        elevation: 10,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('Montant : ' +
                                  snapshot.data[index].amount.toString(),
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),

                              ),
                              SizedBox(height: 5,),
                              /*Text('Sender : ' +
                                  snapshot.data[index].numberSender.toString(),
                                style: TextStyle(fontSize: 12),
                              ),*/
                              Text('Receveur : ' +
                                  snapshot.data[index].numberReceiver.toString(),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Type : ' +
                                  snapshot.data[index].type.toString(),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Jour : ' +
                                  snapshot.data[index].dateCreation.toString().substring(0,10),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Temps : ' +
                                  snapshot.data[index].dateCreation.toString().substring(10,19),
                                style: TextStyle(fontSize: 12),
                              )
                            ],
                          ),
                        ),
                      );

                    });
              }else if(snapshot.hasError){
                print(snapshot.error);
              }
              return  Center(child: Text('Pas de données'));},
          )
      ),
      persistentFooterButtons: <Widget>[
        Footer1()
      ],
    );
  }
}