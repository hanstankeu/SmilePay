import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/viewFR/user/components/myappbar.dart';
import 'package:smilepay/viewFR/user/view/transaction/transactionByUserByOperator.dart';



class TransactionByUserByOperatorPage1 extends StatefulWidget {
  static var storage = FlutterSecureStorage();

  @override
  _TransactionByUserByOperatorPageState createState() => _TransactionByUserByOperatorPageState();
}

class _TransactionByUserByOperatorPageState extends State<TransactionByUserByOperatorPage1> {
  var token = UserData.getToken();
  var type = UserData.getType();
  var balance = UserData.getBalance();
  var username = UserData.getUsername();
  var idPerson = UserData.getId().toString();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar1(),
      backgroundColor: Colors.yellow[100],
      body: Container(
        child: ListView(
          children: <Widget>[

            SizedBox(height: 30,),
            // Mobile Money
            IconButton(
              icon: Image.asset('images/MM.jpg'),
              iconSize: 250,
              onPressed: () async {
                await UserData.getToken().then((token) async {
                  await UserData.getId().then((idPerson){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByUserByOperator1(idPerson, 'MTN_CMR', token)));
                  });
                });
              },
            ),
            SizedBox(height: 30,),
            //Orange money
            IconButton(
              icon: Image.asset('images/OM.jpg'),
              iconSize: 250,
              onPressed: () async {
                await UserData.getToken().then((token) async {
                  await UserData.getId().then((idPerson){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByUserByOperator1(idPerson, 'ORANGE_CMR', token)));
                  });
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
