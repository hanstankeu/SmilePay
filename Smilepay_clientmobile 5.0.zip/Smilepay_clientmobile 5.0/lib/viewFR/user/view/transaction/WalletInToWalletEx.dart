import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/UserCard.dart';
import 'package:smilepay/services/authentication/CompletionServices.dart';
import 'package:smilepay/services/operator/OperatorByPhoneServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/viewFR/Functions.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/view/profile/completeInformations.dart';
import 'package:smilepay/viewFR/user/view/transaction/CodeSecretWIE.dart';


class SendWIWE1 extends StatefulWidget {
  String wallet;
  SendWIWE1({this.wallet});
  @override
  _SendWIWEState createState() => _SendWIWEState();
}

class _SendWIWEState extends State<SendWIWE1> {
  final _formKey = GlobalKey<FormState>();

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone est requis'),
    MinLengthValidator(9, errorText: 'Telephone doit avoir 9 charactères'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'Ce Champ est requis'),
  ]);


  int _amountTransaction;
  //UserCard params
  String _name ;
  String _surname ;
  String _username ;
  String _password ;
  String _codeSecret ;
  String _email ;
  String _phone ;
  String _address ;
  DateTime _birthday;
  String _sexe ;
  String _type ;
  String _id = '';
  DateTime _dateCreation;
  bool  _state;
  bool _status;
  String _role = '';
  int _amountuser;
  String _receiveuser;

  //National Card params
  static String _idCard = null;
  static String _number ;
  static DateTime _dateOfIssue;
  static DateTime _dateOfExpiration;
  static String _attachment;
  static DateTime _dateCreationCNI;
  static DateTime _dateModificationCNI;

  //UserAccount params
  static String _idUserAccount ;
  static String _nameUserAccount;
  static String _surnameUserAccount;
  static String _usernameUserAccount;
  static String _passwordUserAccount;
  static String _codeSecretUserAccount;
  static String _emailUserAccount;
  static String _phoneUserAccount;
  static String _sexeUserAccount ;
  static String _addressUserAccount;
  static String _typeUserAccount ;
  static DateTime _birthdayUserAccount;
  static DateTime _dateCreationUserAccount;
  static bool _stateUserAccount;
  static bool _statusUserAccount;
  static String _roleUserAccount;
  static int _amountuserUserAccount;
  static String _receiveuserUserAccount;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Envoie Argent', style: TextStyle(color: Colors.yellow),textAlign: TextAlign.center,),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          border: Border(),
          borderRadius: BorderRadius.circular(30),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: Colors.yellow.withOpacity(0.2),
              blurRadius: 0.0,
              spreadRadius: 0.0,
              offset: Offset(0, 6.0),
            ),
          ],
        ),
        child: Center(
          child: Form(
            key: _formKey,
            child: ListView(
              children: <Widget>[
                SizedBox(height: 30,),
                Text('Pour le Retrait', style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
                //button
                SizedBox(height: 30,),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: InkWell(
                    onTap: () {
                      Functions1().showUserWallettsWIWE1(context);
                    },
                    child: Material(
                      shadowColor: Colors.grey,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      color: Colors.yellow[500],
                      child: Container(
                        alignment: Alignment.center,
                        height: 40,
                        width: 150,
                        child: Text(
                          'Voir le Receveur',
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                //receiver's number

                SizedBox(height: 20,),
                //amount
                Padding(
                  padding: const EdgeInsets.fromLTRB(14.0, 10.0, 14.0, 10.0),
                  child: Material(
                    borderRadius: BorderRadius.circular(25.0),
                    color: Colors.white,
                    elevation: 0.0,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 12.0),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        cursorColor: Colors.black,
                        onChanged: (value){
                          setState(() {
                            _amountuser = int.parse(value);
                          });
                        },
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          icon: Icon(Icons.monetization_on, color: Colors.black,),
                          labelText: "Montant", fillColor: Colors.black,
                        ),
                        validator: formfieldValidator,
                      ),
                    ),
                  ),
                ),
                //send
                Padding(
                  padding:
                  const EdgeInsets.fromLTRB(100.0, 15.0, 100.0, 0),
                  child: Material(
                      borderRadius: BorderRadius.circular(20.0),
                      color: Colors.yellow,
                      elevation: 0.0,
                      child: MaterialButton(
                        onPressed: () async {

                          if(_formKey.currentState.validate()){
                            _formKey.currentState.save();
                            await HomePage1.storage.read(key: "token").then((snapshot){
                              UserData.getId().then((value){
                                _idUserAccount = value;
                                UserAccount _userAccount = UserAccount(_idUserAccount,
                                    _nameUserAccount, _surnameUserAccount, _usernameUserAccount,
                                    _passwordUserAccount, _codeSecretUserAccount, _emailUserAccount, _phoneUserAccount,
                                    _sexeUserAccount, _addressUserAccount, _typeUserAccount,
                                    _birthdayUserAccount, _dateCreationUserAccount, _stateUserAccount,
                                    _statusUserAccount, _roleUserAccount, _amountuserUserAccount, _receiveuserUserAccount);
                                NationalCard _nationalCard = NationalCard(
                                    _idCard, _number, _dateOfIssue,
                                    _dateOfExpiration, _attachment,
                                    _dateCreationCNI, _dateModificationCNI, _userAccount);
                                completusertrans(UserCard(_name, _surname, _username, _password, _codeSecret,
                                    _email, _phone, _sexe, _address, _type,
                                    _birthday, _nationalCard, _amountuser, _receiveuser),_idUserAccount,snapshot).then((response) async {
                                  if(response.statusCode == 200){
                                    print(response.statusCode);
                                    await Fluttertoast.showToast(msg: "Entrez Votre CodeSecret! ",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 2,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 20.0);
                                  } else {
                                    print(response.statusCode.toString());
                                    await Fluttertoast.showToast(msg: "Veillez Controler vos Champs SVP",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 3,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 15.0);
                                  }
                                });
                              });
                            });
                            Navigator.push(context, MaterialPageRoute(builder: (context) => CodeSecretWIE1()));
                          }
                        },
                        minWidth: MediaQuery.of(context).size.width,
                        child: Text(
                          "Suivant",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0),
                        ),
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
