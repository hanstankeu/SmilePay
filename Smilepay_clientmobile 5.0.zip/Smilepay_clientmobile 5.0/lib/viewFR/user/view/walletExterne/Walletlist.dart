import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/WalletExterne.dart';
import 'package:smilepay/services/WalletServices.dart';
import 'package:smilepay/services/operator/OperatorByPhoneServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/user/UserfindOneServices.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';
import 'package:smilepay/viewFR/user/view/walletExterne/Walletdetails.dart';

class WalletUserlist1 extends StatefulWidget {
  WalletUserlist1({Key key}) : super(key:key);
  @override
  _WalletUserlistState createState() => _WalletUserlistState();
}

class _WalletUserlistState extends State<WalletUserlist1> {
  final _formKey = GlobalKey<FormState>();

  //Wallet Externe
  String _idWalletExterne;
  String _phone;

  //user account
  /*String idUser ;
  String name;
  String surname;
  String username;
  String password;
  String email;
  String phone;*/

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone est requis'),
    MinLengthValidator(9, errorText: 'Telephone doit avoir 9 charactères'),
    MaxLengthValidator(9, errorText: 'Telephone doit avoir 9 charactères')
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'Ce champ est requis'),
  ]);

  @override
  Widget build(BuildContext context) {
    Future<bool> _onWillPop() async {
      return Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage1()));
    }
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          actions: <Widget>[
            IconButton(icon:  Icon(Icons.refresh, color: Colors.yellow,), onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => WalletUserlist1()));
            })
          ],
          backgroundColor: Colors.black,
          title: Text('Wallet Externe', style: TextStyle(color: Colors.yellow),),
          centerTitle: true,
        ),
        body: Container(
            color: Colors.yellow[100],
            padding: EdgeInsets.all(10),
            child:  FutureBuilder<String>(
                future: UserData.getToken(),
                builder: (context, token){
                  if(token.hasData){
                    return FutureBuilder(
                        future: UserData.getId(),
                        builder: (context, idPerson){
                          if(idPerson.hasData){
                            return FutureBuilder<List<WalletExterne>>(
                              future: fetchwalletExterne(idPerson.data, token.data),
                              builder: (context, snapshot){
                                if (snapshot.hasData){
                                  return ListView.builder(
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (BuildContext context, int index) {
                                        return GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(new MaterialPageRoute(
                                                builder: (context)=> new WalletExterneDetails1(walletExterne : snapshot.data[index])
                                            ));
                                          },
                                          child: Card(
                                            elevation: 10,
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  vertical: 10, horizontal: 8),
                                              child: Column(

                                                children: <Widget>[
                                                  Text(snapshot.data[index].phone == null? 'Telephone : ' : 'Telephone : ' +
                                                      snapshot.data[index].phone,
                                                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                                                  ),
                                                  Text(snapshot.data[index].phone == null? 'Operateur : ' : 'Operateur : ' +
                                                      snapshot.data[index].operator.label,
                                                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                                                  ),

                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      });
                                }else if(snapshot.hasError){
                                  print(snapshot.error);
                                }
                                return  Center(child: CircularProgressIndicator());},
                            );
                          }
                          else{
                            return Center(child: Text('Session expirée'),);
                          }
                        }
                    );
                  }
                  else{
                    return Center(child: Text('Session expirée. Pardon Connectez-Vous'));
                  }
                }
            )
        ),
        floatingActionButton: FloatingActionButton(
          splashColor: Colors.black,
          child: Icon(Icons.add, color: Colors.black,),
          onPressed: (){
            showDialog(context: context, builder: (context){
              return AlertDialog(
                backgroundColor: Colors.transparent,
                content: Container(
                  //color: Colors.yellow[100],
                  width: 500.0,
                  height: 300,
                  child: Container(
                    //color: Colors.yellow[100],
                    decoration: BoxDecoration(
                        color: Colors.yellow[100],
                        borderRadius: BorderRadius.circular(25),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromRGBO(143, 148, 251, .3),
                            blurRadius: 20.0,
                            offset: Offset(0,10),
                          ),
                        ]
                    ),
                    child: Column(
                      children: <Widget>[
                        //formfield's content
                        Padding(
                          padding: EdgeInsets.all(5.0),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                SizedBox(height: 10,),
                                Center(
                                  child: Text('Créer un Wallet Externe', style: TextStyle(fontSize: 14, color: Colors.black, fontWeight:  FontWeight.bold),),
                                ),
                                SizedBox(height: 10,),
                                //phone
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(5.0, 20.0, 5.0, 8.0),
                                  child: Material(
                                    borderRadius: BorderRadius.circular(20.0),
                                    color: Colors.yellow.withOpacity(0.4),
                                    elevation: 0.0,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 12.0),
                                      child: TextFormField(
                                        keyboardType: TextInputType.phone,
                                        cursorColor: Colors.black,
                                        onSaved: (value){
                                          _phone = value;
                                        },
                                        decoration: InputDecoration(
                                            labelText: 'TelePhone',
                                            border: InputBorder.none,
                                            icon: Icon(Icons.account_circle,color: Colors.black,)
                                        ),
                                        validator: telephoneValidator,
                                      ),
                                    ),
                                  ),
                                ),

                                //buttons
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: <Widget>[
                                    //delete
                                    FlatButton(
                                      child:  Material(
                                        shadowColor: Colors.grey,
                                        elevation: 10,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        color: Colors.green[200],
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: 30,
                                          width: 70,
                                          child: Text(
                                            'Enregistrer',
                                            style: TextStyle(
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                      ),
                                      onPressed: () {
                                        if(_formKey.currentState.validate()){
                                          _formKey.currentState.save();
                                          HomePage1.storage.read(key: 'token').then((token) async {
                                            UserData.getId().then((idPerson){
                                              fetchoneuser(idPerson, token).then((userAccount){
                                                //UserAccount _userAccount = new UserAccount(id, userAccount.name, userAccount.surname, userAccount.username, userAccount.password, userAccount.email, userAccount.phone, sex, address, type, birthday, dateCreation, state, status, role)
                                                fetchOperatorByPhone(_phone, token).then((operator){
                                                  createwalletExterne(WalletExterne(_idWalletExterne, _phone, operator, userAccount), token).then((response) async {
                                                    if(response.statusCode == 200){
                                                      print(response.statusCode);
                                                      print(_idWalletExterne);
                                                      print(userAccount.surname);
                                                      print(operator.code);
                                                      await Fluttertoast.showToast(msg: "Wallet Créer",
                                                          toastLength: Toast.LENGTH_LONG,
                                                          gravity: ToastGravity.CENTER,
                                                          timeInSecForIosWeb: 5,
                                                          backgroundColor: Colors.black,
                                                          textColor: Colors.yellowAccent,
                                                          fontSize: 15.0
                                                      );
                                                      Navigator.push(context, MaterialPageRoute(builder: (context) => WalletUserlist1()));
                                                    }
                                                    if(response.statusCode == 401){
                                                      print(response.statusCode.toString());
                                                      await Fluttertoast.showToast(msg: "Informations Invalide",
                                                          toastLength: Toast.LENGTH_LONG,
                                                          gravity: ToastGravity.CENTER,
                                                          timeInSecForIosWeb: 5,
                                                          backgroundColor: Colors.black,
                                                          textColor: Colors.yellowAccent,
                                                          fontSize: 15.0
                                                      );
                                                    }
                                                    else if (response.statusCode == 500){
                                                      await Fluttertoast.showToast(msg: response.statusCode.toString(),
                                                          toastLength: Toast.LENGTH_LONG,
                                                          gravity: ToastGravity.CENTER,
                                                          timeInSecForIosWeb: 5,
                                                          backgroundColor: Colors.black,
                                                          textColor: Colors.yellowAccent,
                                                          fontSize: 15.0
                                                      );
                                                    }
                                                  });
                                                });
                                              });
                                            });
                                          });
                                        }
                                      },
                                    ),

                                    //cancel
                                    FlatButton(
                                      child: Material(
                                        shadowColor: Colors.grey,
                                        elevation: 10,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        color: Colors.yellow[500],
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: 30,
                                          width: 70,
                                          child: Text(
                                            'Retour',
                                            style: TextStyle(
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    ),
                                  ],
                                )

                              ],
                            ),
                          ),
                        ),


                        SizedBox(height: 20.0,),

                      ],
                    ),
                  ),
                ),
              );
            });
          },
          backgroundColor: Colors.yellow,

        ),
      ),
    );
  }
}
