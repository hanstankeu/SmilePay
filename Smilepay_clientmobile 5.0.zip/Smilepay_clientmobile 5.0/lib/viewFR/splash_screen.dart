import 'package:flutter/material.dart';
import 'dart:async';
import 'package:shimmer/shimmer.dart';
import 'package:smilepay/viewFR/user/view/authentication/signin.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';

class SplashScreen1 extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen1> {

  @override
  void initState(){
    super.initState();

    _mockCheckForSession().then(
            (status) {
          if (status) {
            _navigateToHome();
          } else {
            _navigateToLogin();
          }
        }
    );
  }

  Future<bool> _mockCheckForSession() async {
    await Future.delayed(Duration(milliseconds: 6000), () {});
    return true;
  }

  Future<void> _navigateToHome() async {
    if(await HomePage1.storage.readAll() != null){
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) => LogIn1()
          )
      );
    }
    else{
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) => LogIn1()
          )
      );
    }

  }

  void _navigateToLogin(){
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(
            builder: (BuildContext context) => LogIn1()
        )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.black, Colors.yellow]
            )
        ),
        width: double.infinity,
        height: double.infinity,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Opacity(
                  opacity: 0.9,
                  child: Image.asset('images/smilepaylogo.png',
                    width: 280.0,
                    height: 240.0,
                  ),
              ),

              Shimmer.fromColors(
                period: Duration(milliseconds: 1500),
                baseColor: Colors.yellow,
                highlightColor: Colors.black,
                child: Container(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    "Faite Une Bonne Transaction Avec SmilePay",
                    style: TextStyle(
                        fontSize: 25.0,
                        fontFamily: 'FontAwesome',
                        shadows: <Shadow>[
                          Shadow(
                              blurRadius: 18.0,
                              color: Colors.black87,
                              offset: Offset.fromDirection(120, 12)
                          )
                        ]
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }


}