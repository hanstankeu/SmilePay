import 'package:smilepay/model/Rate.dart';
import 'package:smilepay/model/Wallet.dart';
import 'package:json_annotation/json_annotation.dart';

import 'Operator.dart';

part 'Transaction.g.dart';
@JsonSerializable(explicitToJson: true)
class Transaction {
  String idTransaction;
  DateTime dateCreation;
  int amount;
  String numberSender;
  String numberReceiver;
  String type;

  Operator operator;

  Rate rate;


  Transaction(this.idTransaction, this.dateCreation, this.amount, this.numberSender, this.numberReceiver, this.type, this.operator, );

  static Map<String, dynamic> toJson(Transaction transaction) =>
      _$TransactionToJson(transaction);

  static Transaction fromJson(Map<String, dynamic> map) =>
      _$TransactionFromJson(map);
}