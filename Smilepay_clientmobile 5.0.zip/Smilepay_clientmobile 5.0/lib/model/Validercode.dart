import 'package:json_annotation/json_annotation.dart';

part 'Validercode.g.dart';
@JsonSerializable(explicitToJson: true)
class Validercode{
  String username;
  String codeSecret;

  Validercode(this.username, this.codeSecret);

  static Map<String, dynamic> converttoJson(Validercode validercode) =>
      _$ValidercodeToJson(validercode);

  static Validercode convertfromJson(Map<String, dynamic> map) =>
      _$ValidercodeFromJson(map);


}