import 'package:json_annotation/json_annotation.dart';

part 'Operator.g.dart';
@JsonSerializable(explicitToJson: true)
class Operator {
  String idOperator;
  String code;
  String label;
  DateTime dateCreation;
  DateTime dateModification;
  String logo;

  Operator(this.idOperator, this.label, this.code, this.dateCreation, this.dateModification, this.logo);

  Map<String, dynamic> toJson() =>
      _$OperatorToJson(this);

  static Operator fromJson(Map<String, dynamic> map) =>
      _$OperatorFromJson(map);
}