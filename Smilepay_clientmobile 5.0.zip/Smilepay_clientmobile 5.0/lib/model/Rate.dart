import 'package:json_annotation/json_annotation.dart';

part 'Rate.g.dart';
@JsonSerializable(explicitToJson: true)
class Rate {
  String idRate;
  double minimum;
  double maximum;
  double value;
  DateTime dateCreation;
  DateTime dateModification;

  Rate(this.idRate, this.minimum, this.maximum, this.value, this.dateCreation,
      this.dateModification);

  Map<String, dynamic> toJson() =>
      _$RateToJson(this);

  static Rate fromJson(Map<String, dynamic> map) =>
      _$RateFromJson(map);
}