// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'UserAccount.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserAccount _$UserAccountFromJson(Map<String, dynamic> json) {
  return UserAccount(
    json['idPerson'] as String,
    json['name'] as String,
    json['surname'] as String,
    json['username'] as String,
    json['password'] as String,
    json['codeSecret'] as String,
    json['email'] as String,
    json['phone'] as String,
    json['sex'] as String,
    json['address'] as String,
    json['type'] as String,
    json['birthday'] == null
        ? null
        : DateTime.parse(json['birthday'] as String),
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['state'] as bool,
    json['status'] as bool,
    json['role'] as String,

    json['amountuser'] as int,
    json['receiveuser'] as String,

  );
}

Map<String, dynamic> _$UserAccountToJson(UserAccount instance) =>
    <String, dynamic>{
      'idPerson': instance.idPerson,
      'name': instance.name,
      'surname': instance.surname,
      'username': instance.username,
      'password': instance.password,
      'codeSecret': instance.codeSecret,
      'email': instance.email,
      'phone': instance.phone,
      'sex': instance.sex,
      'address': instance.address,
      'type': instance.type,
      'birthday': instance.birthday?.toIso8601String(),
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'state': instance.state,
      'status': instance.status,
      'role': instance.role,

      'amountuser': instance.amountuser,
      'receiveuser': instance.receiveuser,



    };
