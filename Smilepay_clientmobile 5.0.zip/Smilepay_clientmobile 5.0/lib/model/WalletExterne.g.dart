// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'WalletExterne.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

WalletExterne _$WalletExterneFromJson(Map<String, dynamic> json) {
  return WalletExterne(
    json['idWalletExterne'] as String,
    json['phone'] as String,
    json['operator'] == null
        ? null
        : Operator.fromJson(json['operator'] as Map<String, dynamic>),
    json['userAccount'] == null
        ? null
        : UserAccount.fromJson(json['userAccount'] as Map<String, dynamic>),
  );
}

Map<String, dynamic> _$WalletExterneToJson(WalletExterne instance) =>
    <String, dynamic>{
      'idWalletExterne': instance.idWalletExterne,
      'phone': instance.phone,
      'operator': instance.operator?.toJson(),
      'userAccount': instance.userAccount?.toJson(),
    };
