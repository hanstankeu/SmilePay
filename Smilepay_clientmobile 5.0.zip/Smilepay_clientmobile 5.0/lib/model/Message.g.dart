// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Message _$MessageFromJson(Map<String, dynamic> json) {
  return Message(
    json['idMessage'] as String,
    json['emailReceiver'] as String,
    json['content'] as String,
    json['title'] as String,
  );
}

Map<String, dynamic> _$MessageToJson(Message instance) => <String, dynamic>{
      'idMessage': instance.idMessage,
      'emailReceiver': instance.emailReceiver,
      'content': instance.content,
      'title': instance.title,
    };
