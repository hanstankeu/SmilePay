// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'JWTResponse.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

JWTResponse _$JWTResponseFromJson(Map<String, dynamic> json) {
  return JWTResponse(
    json['token'] as String,
    json['type'] as String,
    json['id'] as String,
    json['username'] as String,
    json['email'] as String,
    json['name'] as String,
    json['surname'] as String,
    (json['balance'] as num)?.toDouble(),
    (json['roles'] as List)?.map((e) => e as String)?.toList(),
    json['state'] as bool,
  )
    ..phone = json['phone'] as String
    ..status = json['status'] as bool;
}

Map<String, dynamic> _$JWTResponseToJson(JWTResponse instance) =>
    <String, dynamic>{
      'token': instance.token,
      'type': instance.type,
      'id': instance.id,
      'username': instance.username,
      'email': instance.email,
      'name': instance.name,
      'surname': instance.surname,
      'balance': instance.balance,
      'roles': instance.roles,
      'phone': instance.phone,
      'state': instance.state,
      'status': instance.status,
    };
