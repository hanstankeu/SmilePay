// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'UserCard.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserCard _$UserCardFromJson(Map<String, dynamic> json) {
  return UserCard(
    json['name'] as String,
    json['surname'] as String,
    json['username'] as String,
    json['password'] as String,
    json['codeSecret'] as String,
    json['email'] as String,
    json['phone'] as String,
    json['sex'] as String,
    json['address'] as String,
    json['type'] as String,
    json['birthday'] == null
        ? null
        : DateTime.parse(json['birthday'] as String),
    json['nationalCard'] == null
        ? null
        : NationalCard.fromJson(json['nationalCard'] as Map<String, dynamic>),
    json['amountuser'] as int,
    json['receiveuser'] as String,
  );
}

Map<String, dynamic> _$UserCardToJson(UserCard instance) => <String, dynamic>{
      'name': instance.name,
      'surname': instance.surname,
      'username': instance.username,
      'password': instance.password,
      'codeSecret': instance.codeSecret,
      'email': instance.email,
      'phone': instance.phone,
      'sex': instance.sex,
      'address': instance.address,
      'type': instance.type,
      'birthday': instance.birthday?.toIso8601String(),
      'nationalCard': instance.nationalCard?.toJson(),
      'amountuser': instance.amountuser,
      'receiveuser': instance.receiveuser,
    };
