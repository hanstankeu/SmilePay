// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Operator.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Operator _$OperatorFromJson(Map<String, dynamic> json) {
  return Operator(
    json['idOperator'] as String,
    json['label'] as String,
    json['code'] as String,
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['dateModification'] == null
        ? null
        : DateTime.parse(json['dateModification'] as String),
    json['logo'] as String,
  );
}

Map<String, dynamic> _$OperatorToJson(Operator instance) => <String, dynamic>{
      'idOperator': instance.idOperator,
      'code': instance.code,
      'label': instance.label,
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'dateModification': instance.dateModification?.toIso8601String(),
      'logo': instance.logo,
    };
