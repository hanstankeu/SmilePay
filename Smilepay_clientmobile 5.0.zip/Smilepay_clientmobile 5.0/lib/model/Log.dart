import 'package:json_annotation/json_annotation.dart';

part 'Log.g.dart';
@JsonSerializable(explicitToJson: true)
class Log {
  String idLog;
  DateTime dateCreation;

  Log(this.idLog, this.dateCreation);

  static Map<String, dynamic> converttoJson(Log log) =>
      _$LogToJson(log);

  static Log convertfromJson(Map<String, dynamic> map) =>
      _$LogFromJson(map);

}