import 'package:json_annotation/json_annotation.dart';

part 'MessageResponse.g.dart';
@JsonSerializable(explicitToJson: true)
class MessageResponse{
  String message;

  MessageResponse(this.message);

  Map<String, dynamic> toJson() =>
      _$MessageResponseToJson(this);

  static MessageResponse fromJson(Map<String, dynamic> map) =>
      _$MessageResponseFromJson(map);
}