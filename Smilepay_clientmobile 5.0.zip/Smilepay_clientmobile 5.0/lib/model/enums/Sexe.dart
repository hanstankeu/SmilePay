enum Sexe{
  MALE,
  FAMALE
}