enum Role {
  User,
  Admin
}