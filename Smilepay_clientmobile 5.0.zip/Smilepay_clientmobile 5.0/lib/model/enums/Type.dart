enum Type{
  Physical,
  Moral
}