import 'package:json_annotation/json_annotation.dart';

part 'JWTResponse.g.dart';
@JsonSerializable(explicitToJson: true)
class JWTResponse{
  String token;
  String type;
  String id;
  String username;
  String email;
  String name;
  String surname;
  double balance;
  List<String> roles;
  String phone;
  bool state;
  bool status;

  JWTResponse(this.token, this.type, this.id, this.username, this.email,
      this.name, this.surname, this.balance, this.roles, this.state);

  static Map<String, dynamic> converttoJson(JWTResponse jwtResponse) =>
      _$JWTResponseToJson(jwtResponse);

  static JWTResponse convertfromJson(Map<String, dynamic> map) =>
      _$JWTResponseFromJson(map);


}