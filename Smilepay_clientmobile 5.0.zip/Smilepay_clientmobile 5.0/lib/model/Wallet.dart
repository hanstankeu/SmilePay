import 'package:smilepay/model/UserAccount.dart';
import 'package:json_annotation/json_annotation.dart';

part 'Wallet.g.dart';
@JsonSerializable(explicitToJson: true)
class Wallet {
  String idWallet;
  DateTime dateCreation;
  DateTime dateModification;
  double balance;

  UserAccount userAccount;

  Wallet(this.idWallet, this.dateCreation,
      this.dateModification, this.balance, this.userAccount);

  static Map<String, dynamic> toJson(Wallet wallet) =>
      _$WalletToJson(wallet);

  static Wallet fromJson(Map<String, dynamic> map) =>
      _$WalletFromJson(map);
}