// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Transaction.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Transaction _$TransactionFromJson(Map<String, dynamic> json) {
  return Transaction(
    json['idTransaction'] as String,
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['amount'] as int,
    json['numberSender'] as String,
    json['numberReceiver'] as String,
    json['type'] as String,
    json['operator'] == null
        ? null
        : Operator.fromJson(json['operator'] as Map<String, dynamic>),
  )..rate = json['rate'] == null
      ? null
      : Rate.fromJson(json['rate'] as Map<String, dynamic>);
}

Map<String, dynamic> _$TransactionToJson(Transaction instance) =>
    <String, dynamic>{
      'idTransaction': instance.idTransaction,
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'amount': instance.amount,
      'numberSender': instance.numberSender,
      'numberReceiver': instance.numberReceiver,
      'type': instance.type,
      'operator': instance.operator?.toJson(),
      'rate': instance.rate?.toJson(),
    };
