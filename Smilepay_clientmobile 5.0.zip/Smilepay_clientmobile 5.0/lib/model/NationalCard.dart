import 'package:json_annotation/json_annotation.dart';
import 'package:smilepay/model/UserAccount.dart';

part 'NationalCard.g.dart';
@JsonSerializable(explicitToJson: true)
class NationalCard {
  String idCard;
  String number;
  DateTime dateOfIssue;
  DateTime dateExpiration;
  String attachment;
  DateTime dateCreation;
  DateTime dateModification;

  UserAccount userAccount;

  NationalCard(this.idCard, this.number, this.dateOfIssue,
      this.dateExpiration, this.attachment, this.dateCreation,
      this.dateModification, this.userAccount);

  Map<String, dynamic> toJson() =>
      _$NationalCardToJson(this);

  static NationalCard fromJson(Map<String, dynamic> map) =>
      _$NationalCardFromJson(map);
}