// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'MessageResponse.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MessageResponse _$MessageResponseFromJson(Map<String, dynamic> json) {
  return MessageResponse(
    json['message'] as String,
  );
}

Map<String, dynamic> _$MessageResponseToJson(MessageResponse instance) => <String, dynamic>{
  'message': instance.message,
};
