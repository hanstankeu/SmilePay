// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'NationalCard.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NationalCard _$NationalCardFromJson(Map<String, dynamic> json) {
  return NationalCard(
    json['idCard'] as String,
    json['number'] as String,
    json['dateOfIssue'] == null
        ? null
        : DateTime.parse(json['dateOfIssue'] as String),
    json['dateExpiration'] == null
        ? null
        : DateTime.parse(json['dateExpiration'] as String),
    json['attachment'] as String,
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['dateModification'] == null
        ? null
        : DateTime.parse(json['dateModification'] as String),
    json['userAccount'] == null
        ? null
        : UserAccount.fromJson(json['userAccount'] as Map<String, dynamic>),
  );
}

Map<String, dynamic> _$NationalCardToJson(NationalCard instance) =>
    <String, dynamic>{
      'idCard': instance.idCard,
      'number': instance.number,
      'dateOfIssue': instance.dateOfIssue?.toIso8601String(),
      'dateExpiration': instance.dateExpiration?.toIso8601String(),
      'attachment': instance.attachment,
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'dateModification': instance.dateModification?.toIso8601String(),
      'userAccount': instance.userAccount?.toJson(),
    };
