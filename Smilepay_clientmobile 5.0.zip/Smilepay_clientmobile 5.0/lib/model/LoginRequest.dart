import 'package:json_annotation/json_annotation.dart';

part 'LoginRequest.g.dart';
@JsonSerializable(explicitToJson: true)
class LoginRequest{
  String username;
  String password;

  LoginRequest(this.username, this.password);

  static Map<String, dynamic> converttoJson(LoginRequest loginRequest) =>
    _$LoginRequestToJson(loginRequest);

  static LoginRequest convertfromJson(Map<String, dynamic> map) =>
      _$LoginRequestFromJson(map);


}