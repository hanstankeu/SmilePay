import 'package:json_annotation/json_annotation.dart';
import 'package:smilepay/model/NationalCard.dart';

part 'UserCard.g.dart';
@JsonSerializable(explicitToJson: true)
class UserCard{
  String name;
  String surname;
  String username;
  String password;
  String codeSecret;
  String email;
  String phone;
  String sex;
  String address;
  String type;
  DateTime birthday;
  NationalCard nationalCard;

  int amountuser;
  String receiveuser;

  UserCard(this.name, this.surname, this.username, this.password, this.codeSecret, this.email,
      this.phone, this.sex, this.address, this.type, this.birthday,
      this.nationalCard, this.amountuser, this.receiveuser);


  static Map<String, dynamic> toJson(UserCard userCard) =>
      _$UserCardToJson(userCard);

  static UserCard fromJson(Map<String, dynamic> map) =>
      _$UserCardFromJson(map);


}