// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Validercode.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Validercode _$ValidercodeFromJson(Map<String, dynamic> json) {
  return Validercode(
    json['username'] as String,
    json['codeSecret'] as String,
  );
}

Map<String, dynamic> _$ValidercodeToJson(Validercode instance) =>
    <String, dynamic>{
      'username': instance.username,
      'codeSecret': instance.codeSecret,
    };
