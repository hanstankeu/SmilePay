// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Rate.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Rate _$RateFromJson(Map<String, dynamic> json) {
  return Rate(
    json['idRate'] as String,
    (json['minimum'] as num)?.toDouble(),
    (json['maximum'] as num)?.toDouble(),
    (json['value'] as num)?.toDouble(),
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['dateModification'] == null
        ? null
        : DateTime.parse(json['dateModification'] as String),
  );
}

Map<String, dynamic> _$RateToJson(Rate instance) => <String, dynamic>{
      'idRate': instance.idRate,
      'minimum': instance.minimum,
      'maximum': instance.maximum,
      'value': instance.value,
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'dateModification': instance.dateModification?.toIso8601String(),
    };
