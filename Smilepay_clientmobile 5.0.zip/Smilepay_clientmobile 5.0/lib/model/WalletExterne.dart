import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:json_annotation/json_annotation.dart';

part 'WalletExterne.g.dart';
@JsonSerializable(explicitToJson: true)
class WalletExterne {
  String idWalletExterne;
  String phone;

  Operator operator;

  UserAccount userAccount;

  WalletExterne(this.idWalletExterne, this.phone, this.operator,
      this.userAccount);


  Map<String, dynamic> toJson() =>
      _$WalletExterneToJson(this);

  static WalletExterne fromJson(Map<String, dynamic> map) =>
      _$WalletExterneFromJson(map);

}