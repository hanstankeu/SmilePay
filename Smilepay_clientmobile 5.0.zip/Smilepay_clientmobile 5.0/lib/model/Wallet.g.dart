// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Wallet.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Wallet _$WalletFromJson(Map<String, dynamic> json) {
  return Wallet(
    json['idWallet'] as String,
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
    json['dateModification'] == null
        ? null
        : DateTime.parse(json['dateModification'] as String),
    (json['balance'] as num)?.toDouble(),
    json['userAccount'] == null
        ? null
        : UserAccount.fromJson(json['userAccount'] as Map<String, dynamic>),
  );
}

Map<String, dynamic> _$WalletToJson(Wallet instance) => <String, dynamic>{
      'idWallet': instance.idWallet,
      'dateCreation': instance.dateCreation?.toIso8601String(),
      'dateModification': instance.dateModification?.toIso8601String(),
      'balance': instance.balance,
      'userAccount': instance.userAccount?.toJson(),
    };
