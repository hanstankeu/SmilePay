import 'package:json_annotation/json_annotation.dart';
part 'UserAccount.g.dart';

@JsonSerializable(explicitToJson: true)
class UserAccount{
  String idPerson;
  String name;
  String surname;
  String username;
  String password;
  String codeSecret;
  String email;
  String phone;
  String sex;
  String address;
  String type;
  DateTime birthday;
  DateTime dateCreation;
  bool state;
  bool status;
  String role;

  int amountuser;
  String receiveuser;

  UserAccount(this.idPerson, this.name, this.surname, this.username, this.password, this.codeSecret,
      this.email, this.phone, this.sex, this.address, this.type, this.birthday,
      this.dateCreation, this.state, this.status, this.role, this.amountuser, this.receiveuser);


  UserAccount.name(this.idPerson);

  Map<String, dynamic> toJson() =>
      _$UserAccountToJson(this);

  static UserAccount fromJson(Map<String, dynamic> map) =>
      _$UserAccountFromJson(map);

}