// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Log.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Log _$LogFromJson(Map<String, dynamic> json) {
  return Log(
    json['idLog'] as String,
    json['dateCreation'] == null
        ? null
        : DateTime.parse(json['dateCreation'] as String),
  );
}

Map<String, dynamic> _$LogToJson(Log instance) => <String, dynamic>{
      'idLog': instance.idLog,
      'dateCreation': instance.dateCreation?.toIso8601String(),
    };
