import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/admin/src/view/Rate.dart';
import 'package:smilepay/view/admin/src/view/Ratelist.dart';
import 'package:smilepay/view/admin/src/view/Transactionlist.dart';
import 'package:smilepay/view/admin/src/view/TransactionlistByOperator.dart';
import 'package:smilepay/view/admin/src/view/UserList.dart';
import 'package:smilepay/view/admin/src/widget/chart_card_tile.dart';
import 'package:smilepay/view/admin/src/widget/quick_contact.dart';
import 'package:smilepay/view/admin/src/widget/responsive_widget.dart';
import 'package:smilepay/view/admin/src/widget/sidebar_menu..dart';
import 'package:smilepay/view/admin/src/view/Operator.dart';

class MainPage extends StatefulWidget {
  static var storage = FlutterSecureStorage();

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  var token = AdminData.getAdminToken();
  var type = AdminData.getAdminType();
  var balance = AdminData.getAdminBalance();
  var username = AdminData.getAdminUsername();

  @override
  Widget build(BuildContext context) {
    //define interface size
    final _media = MediaQuery.of(context).size;
    print(_media);
    return Scaffold(
      //drawer menu
      drawer: SideBarMenu(),
      body: Container(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
              return Material(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    ResponsiveWidget.isSmallScreen(context)
                    //adaptation for screen size
                        ? SideBarMenu()
                        : Container(),
                    Flexible(
                      fit: FlexFit.loose,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            height: 70,
                            width: _media.width,
                            child: AppBar(
                              elevation: 4,
                              centerTitle: true,
                              title: Text(
                                'SmilePay Admin',
                                style: TextStyle(color: Colors.yellow),
                              ),
                              backgroundColor: Colors.black,
                            ),
                          ),
                          Expanded(
                            child: ListView(
                              padding: EdgeInsets.only(
                                  top: 20, left: 0, right: 0, bottom: 20),
                              children: <Widget>[
                               Container(
                                 padding: EdgeInsets.only(left: 20),
                                 child: Row(
                                   children: <Widget>[
                                     Text("Welcome  ", style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic),),
                                     FutureBuilder(
                                       future: username,
                                         builder: (context, snapshot){
                                         if(snapshot.hasData){
                                           return Text( snapshot.data, style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic, fontSize: 18));
                                         }else{
                                           return Text( 'username', style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic, fontSize: 18));
                                         }
                                       }),
                                   ],
                                 ),
                               ),
                                SizedBox(height: 10,),
                                //first row of buttons
                                IntrinsicHeight(
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: <Widget>[
                                      //user list
                                      MaterialButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => Userlist()));
                                        },
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('User list', style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontStyle: FontStyle.italic),),
                                          ],
                                        ),
                                      ),
                                      //transaction list
                                      MaterialButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => Tansactionlist()));
                                        },
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('Transactions', style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontStyle: FontStyle.italic,
                                            ),),
                                          ],
                                        ),
                                      ),
                                      //settings
                                      MaterialButton(
                                        onPressed: (){},
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('Setting', style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontStyle: FontStyle.italic),),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                //second row of buttons
                                IntrinsicHeight(
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.stretch,
                                    children: <Widget>[
                                      //create rate
                                      MaterialButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => RateAdmin()));
                                        },
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('Rate', style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontStyle: FontStyle.italic),),
                                          ],
                                        ),
                                      ),
                                      //operator
                                      MaterialButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => OperatorAdmin()));
                                        },
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('Operator', style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontStyle: FontStyle.italic,
                                            ),),
                                          ],
                                        ),
                                      ),
                                      //statistics
                                      MaterialButton(
                                        onPressed: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => ChartCardTile()));
                                        },
                                        textColor: Colors.grey,
                                        elevation: 4,
                                        color: Colors.yellow,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            Divider(
                                              thickness: 70,
                                            ),
                                            Text('Statistics', style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontStyle: FontStyle.italic),),
                                          ],
                                        ),
                                      ),

                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                //third row of buttons
                                IntrinsicHeight(
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.stretch,
                                    children: <Widget>[
                                      //Express union
/*                                      IconButton(
                                        icon: Image.asset('images/EU.png'),
                                        iconSize: 50,
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByOperator('EU_CMR')));
                                        },
                                      ),*/
                                      // Mobile Money
                                      IconButton(
                                        icon: Image.asset('images/MM.jpg'),
                                        iconSize: 50,
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByOperator('MTN_CMR')));
                                        },
                                      ),
                                      //Orange money
                                      IconButton(
                                        icon: Image.asset('images/OM.jpg'),
                                        iconSize: 50,
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByOperator('ORANGE_CMR')));
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 30),
                                QuickContact(media: _media),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
              },
        ),
      ),
    );
  }
}
