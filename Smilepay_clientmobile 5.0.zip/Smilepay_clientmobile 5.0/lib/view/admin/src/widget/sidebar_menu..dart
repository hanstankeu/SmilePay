import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/services/authentication/LogOutServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/admin/src/commons/theme.dart';
import 'package:smilepay/view/admin/src/model/menu.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/admin/src/widget/chart_card_tile.dart';
import 'package:smilepay/view/admin/src/widget/menu_item_tile.dart';
import 'package:smilepay/view/user/view/authentication/signin.dart';

class SideBarMenu extends StatefulWidget {
  static var storage = FlutterSecureStorage();
  @override
  _SideBarMenuState createState() => _SideBarMenuState();
}

class _SideBarMenuState extends State<SideBarMenu>
    with SingleTickerProviderStateMixin {
  double maxWidth = 100;
  double minWidth = 30;
  bool collapsed = false;
  int selectedIndex = 0;

  AnimationController _animationController;
  Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 100));

    _animation = Tween<double>(begin: maxWidth, end: minWidth)
        .animate(_animationController);
  }

  var noms = AdminData.getAdminNomPrenom();
  var email = AdminData.getAdminEmail();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: AnimatedBuilder(
        animation: _animation,
        builder: (BuildContext context, Widget child) {
          return Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(blurRadius: 10, color: Colors.black26, spreadRadius: 2)
              ],
              color: drawerBgColor,
            ),
            width: _animation.value,
            child:  Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  height: 200,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.black, Colors.yellow]
                      )
                  ),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    height: 100,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            CircleAvatar(
                              backgroundImage: AssetImage('images/admin.png'),
                              backgroundColor: Colors.white,
                              radius: _animation.value >= 70 ? 30 : 20,
                            ),
                            SizedBox(
                              width: _animation.value >= 70 ? 20 : 0,
                            ),
                            (_animation.value >= 250)
                                ? FutureBuilder(
                              future: noms,
                                builder: (context, snapshot){
                                if(snapshot.hasData){
                                  return Text(snapshot.data, style: menuListTileDefaultText);
                                }else{
                                  return Text('name', style: menuListTileDefaultText);
                                }

                              })
                                : Container(),
                          ],
                        ),
                        SizedBox(
                          height: _animation.value >= 70 ? 20 : 0,
                        ),
                        Spacer(),
                        (_animation.value >= 70)
                            ? FutureBuilder(
                          future: noms,
                            builder: (context, snapshot) {
                            if(snapshot.hasData){
                              return Text(snapshot.data, style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold,
                              ),
                              );
                            }else{
                              return Text('name', style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold,));
                            }
                          })
                            : Container(),
                        (_animation.value >= 70)
                            ? FutureBuilder(
                            future: email,
                            builder: (context, snapshot) {
                              if(snapshot.hasData){
                                return Text(snapshot.data, style: TextStyle(fontSize: 13, color: Colors.white, fontWeight: FontWeight.w400));
                              }else{
                              return Text('email', style: TextStyle(fontSize: 13, color: Colors.white, fontWeight: FontWeight.w400));
                              }})
                            : Container(),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Expanded(
                  child: ListView(
                    children: <Widget>[
                      MenuItemTile(
                        title: "Dashboard",
                        icon: Icons.dashboard,
                        animationController: _animationController,
                        //isSelected: ,
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MainPage()));
                        },
                      ),
                      MenuItemTile(
                        title: "Notifications",
                        icon: Icons.notification_important,
                        animationController: _animationController,
                        //isSelected: ,
                        onTap: (){},
                      ),
                      MenuItemTile(
                        title: "Charts",
                        icon: Icons.insert_chart,
                        animationController: _animationController,
                        //isSelected: ,
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => ChartCardTile()));
                        },
                      ),
                      MenuItemTile(
                        title: "Log out",
                        icon: Icons.exit_to_app,
                        animationController: _animationController,
                        //isSelected: ,
                        onTap: () async {
                          await MainPage.storage.read(key: 'token').then((idPerson) async {
                            await AdminData.getAdminToken().then((token) async{
                              logout(idPerson, token).then((response) async {
                                if(response.statusCode == 200){
                                  print(response.statusCode);
                                  await Fluttertoast.showToast(msg: "Logged out!!! ",
                                      toastLength: Toast.LENGTH_LONG,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 5,
                                      backgroundColor: Colors.black,
                                      textColor: Colors.yellowAccent,
                                      fontSize: 15.0);
                                  //HomePage.storage.deleteAll();
                                  MainPage.storage.deleteAll();
                                  MainPage.storage.delete(key: 'token');
                                  await Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn()));
                                }
                                else if(response.statusCode == 401){
                                  print(response.statusCode.toString());
                                  Fluttertoast.showToast(msg: "Cannot log out",
                                      toastLength: Toast.LENGTH_LONG,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 5,
                                      backgroundColor: Colors.black,
                                      textColor: Colors.yellowAccent,
                                      fontSize: 15.0);
                                }
                              });
                            });
                          });
                        },
                      ),
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      collapsed = !collapsed;
                      collapsed
                          ? _animationController.reverse()
                          : _animationController.forward();
                    });
                  },
                  child: AnimatedIcon(
                    icon: AnimatedIcons.close_menu,
                    progress: _animationController,
                    color: Colors.white,
                    size: 10,
                  ),
                ),
                SizedBox(
                  height: 5,
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
