import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/services/NationalCardfindOneServices.dart';
import 'package:smilepay/services/operator/OperatordeleteServices.dart';
import 'package:smilepay/services/operator/OperatorfindbycodeServices.dart';
import 'package:smilepay/services/operator/OperatorupdateServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/admin/src/view/Operator.dart';

class OperatorDetails extends StatefulWidget {
  Operator operator;
  OperatorDetails({this.operator});

  @override
  _OperatorDetailsState createState() => _OperatorDetailsState();
}

class _OperatorDetailsState extends State<OperatorDetails> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    //final Map user = ModalRoute.of(context).settings.arguments;

    final formfieldValidator = MultiValidator([
      RequiredValidator(errorText: 'This field is required'),
    ]);

    //Operator
    String _idOperator;
    String _label;
    String _code;
    DateTime _dateCreation = DateTime.now();
    DateTime _dateModification = DateTime.now();
    String _logo;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Operator details', style: TextStyle(color: Colors.yellow),),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: ListView(

            children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 20),
                alignment: Alignment.center,
                child: Text('Operator details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
              ),

              //label
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    cursorColor: Colors.black,
                    onChanged: (value){
                      _label = value;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: widget.operator.label,
                      icon: Icon(Icons.label, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),

              //code
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    cursorColor: Colors.black,
                    onChanged: (value){
                      _code = value;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: widget.operator.code,
                      icon: Icon(Icons.network_cell, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),

              //logo
              Container(
                child: FutureBuilder<String>(
                    future: AdminData.getAdminToken(),
                    builder: (context, token){
                      if(token.hasData){
                        return FutureBuilder<Operator>(
                            future: fetchoperatorbyoperatorcode(widget.operator.code, token.data),
                            builder: (context, snapshot){
                              if(snapshot.hasData){
                                return Image.memory(
                                  Base64Decoder().convert(snapshot.data.logo),
                                );
                              }
                              else{
                                return Center(child: CircularProgressIndicator(),);
                              }
                            }
                        );
                      }
                      else{
                        return Center(child: CircularProgressIndicator(),);
                      }
                    }
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  //update
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: () async {
                        if(_formKey.currentState.validate()){
                          _formKey.currentState.save();
                          await AdminData.getAdminToken().then((token) async {
                            print(token);
                            print(_label);
                            print(_code);
                            updateoperator(widget.operator.idOperator ,Operator(_idOperator, _label, _code, _dateCreation, _dateModification, _logo), token)
                                .then((response) async {
                              print(response.statusCode);
                              print(response.body);
                              if(response.statusCode == 200){
                                await Fluttertoast.showToast(msg: "Operator created !!! ",
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                                ///await Navigator.pop(context);
                              }
                              if(response.statusCode == 401){
                                print(response.statusCode.toString());
                                await Fluttertoast.showToast(msg: "Invalid informations",
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                              }
                            });
                          });
                        }
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.yellow[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Update',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  //delete
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: () async {
                          await AdminData.getAdminToken().then((token) async {
                            deleteoperator(widget.operator.idOperator, token)
                                .then((response) async {
                              print(response.statusCode);
                              print(response.body);
                              if(response.statusCode == 200){
                                await Fluttertoast.showToast(msg: "Operator deleted !!! ",
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                                await Navigator.push(context, MaterialPageRoute(builder: (context) => OperatorAdmin()));
                                ///await Navigator.pop(context);
                              }
                              if(response.statusCode == 500){
                                print(response.statusCode.toString());
                                await Fluttertoast.showToast(msg: "Server unavailable. Please try later",
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                              }
                            });
                          });
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.red[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Delete',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )

            ],
          ),
        ),
      ),
    );
  }
}
