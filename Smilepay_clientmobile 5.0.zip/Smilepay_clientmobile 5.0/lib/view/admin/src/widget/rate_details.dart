import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/Rate.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/services/NationalCardfindOneServices.dart';
import 'package:smilepay/services/operator/OperatordeleteServices.dart';
import 'package:smilepay/services/operator/OperatorupdateServices.dart';
import 'package:smilepay/services/rate/RatedeleteServices.dart';
import 'package:smilepay/services/rate/RateupdateServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/admin/src/view/Operator.dart';
import 'package:smilepay/view/admin/src/view/Ratelist.dart';

class RateDetails extends StatefulWidget {
  Rate rate;
  RateDetails({this.rate});

  @override
  _RateDetailsState createState() => _RateDetailsState();
}

class _RateDetailsState extends State<RateDetails> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    //final Map user = ModalRoute.of(context).settings.arguments;

    final formfieldValidator = MultiValidator([
      RequiredValidator(errorText: 'This field is required'),
    ]);

    //Operator
    String _idRate;
    double _minimum;
    double _maximum;
    double _value;
    DateTime _dateCreation = DateTime.now();
    DateTime _dateModification = DateTime.now();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Rate details', style: TextStyle(color: Colors.yellow),),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: ListView(

            children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 20),
                alignment: Alignment.center,
                child: Text('Rate details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
              ),

              //minimum
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    initialValue: widget.rate.minimum.toString(),
                    cursorColor: Colors.black,
                    onChanged: (value){
                      if(_minimum == 0.0 || _minimum == null){
                        _minimum = widget.rate.minimum;
                      }else{
                        _minimum = double.parse(value);
                      }
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: 'Minimum amount',
                      icon: Icon(Icons.label, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),

              //maximum
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    initialValue:  widget.rate.maximum.toString(),
                    cursorColor: Colors.black,
                    onChanged: (value){
                      if(_maximum == 0.0 || _maximum == null){
                        _maximum = widget.rate.maximum;
                      }else{
                        _maximum = double.parse(value);
                      }
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: 'Maximum amount',
                      icon: Icon(Icons.network_cell, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),

              //value
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    initialValue: widget.rate.value.toString(),
                    cursorColor: Colors.black,
                    onChanged: (value){
                      if(_value == 0.0 || _value == null){
                        _value = widget.rate.value;
                      }else{
                        _value = double.parse(value);
                      }
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: 'Value',
                      icon: Icon(Icons.network_cell, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  //update
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: (){
                        if(_formKey.currentState.validate()){
                          _formKey.currentState.save();
                          AdminData.getAdminToken().then((token){
                            print(token);
                            print(_minimum);
                            print(_maximum);
                            print(_value);
                            updaterate(widget.rate.idRate ,Rate(_idRate, _minimum, _maximum, _value, _dateCreation, _dateModification), token)
                                .then((response){
                              print(response.statusCode);
                              print(response.body);
                              Center(child: CircularProgressIndicator(),);
                              if(response.statusCode == 200){
                                Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Ratelist()));
                              }
                              else{
                                print(response.statusCode.toString());
                                Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                              }
                            });
                          });
                        }
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.yellow[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Update',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  //delete
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: () async {
                        AdminData.getAdminToken().then((token) async {
                          deleterate(widget.rate.idRate, token)
                                .then((response) async {
                              print(response.statusCode);
                              print(response.body);
                              Center(child: CircularProgressIndicator(),);
                              if(response.statusCode == 200){
                                Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Ratelist()));
                                ///await Navigator.pop(context);
                              }
                              else{
                                print(response.statusCode.toString());
                                await Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                              }
                            });
                          });
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.red[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Delete',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )

            ],
          ),
        ),
      ),
    );
  }
}
