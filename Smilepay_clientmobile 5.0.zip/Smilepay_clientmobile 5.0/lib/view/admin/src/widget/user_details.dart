import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter_svg/svg.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/services/NationalCardfindOneServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';

class User extends StatelessWidget {
  UserAccount userAccount;
  User({this.userAccount});

  @override
  Widget build(BuildContext context) {
    //final Map user = ModalRoute.of(context).settings.arguments;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('User details', style: TextStyle(color: Colors.yellow),),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: ListView(

          children: <Widget>[
            Container(
              padding: EdgeInsets.only(top: 20, bottom: 20),
              alignment: Alignment.center,
              child: Text(userAccount.email, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
            ),
            FlipCard(

              direction: FlipDirection.VERTICAL,
              flipOnTouch: true,
              front: SlimUserCard(title: 'Name'),
              back: SlimUserDetailCard(
                title: userAccount.name + " " + userAccount.surname,
                color: Colors.deepOrange,
              ),
            ),
            FlipCard(
              flipOnTouch: true,
              direction: FlipDirection.VERTICAL,
              front: SlimUserCard(title: 'Username'),
              back: SlimUserDetailCard(
                title: userAccount.username,
                color: Colors.deepPurple,
              ),
            ),

            FlipCard(
              direction: FlipDirection.VERTICAL,
              front: SlimUserCard(title: 'Telephone'),
              back: SlimUserDetailCard(
                title: userAccount.phone,
                color: Colors.blue,
              ),
            ),
            FlipCard(
              direction: FlipDirection.VERTICAL,
              front: SlimUserCard(title: 'Address',),
              back: SlimUserDetailCard(
                title: userAccount.address,
                color: Colors.yellow,
              ),
            ),
            /*FlipCard(
              direction: FlipDirection.VERTICAL,
              front: SlimUserCard(title: 'Identity card card'),
              back: GridTile(
                  child: Image.memory(
                    Base64Decoder().convert(userAccount.nationalCard.attachment),
                  )
              ),
            ),*/
            SizedBox(height: 20,),
            /*Container(
              height: 200,
              width: 50,
              child: FutureBuilder<String>(
                  future: AdminData.getAdminToken(),
                  builder: (context, token){
                    if(token.hasData){
                      return FutureBuilder<NationalCard>(
                          future: fetchnationalcardbymail(userAccount.email, token.data),
                          builder: (context, snapshot){
                            if(snapshot.hasData){
                              return Image.memory(
                                Base64Decoder().convert(snapshot.data.attachment),
                              );
                            }
                            else{
                              return Center(child: CircularProgressIndicator(),);
                            }
                          }
                      );
                    }
                    else{
                      return Center(child: CircularProgressIndicator(),);
                    }
                  }
              ),
            ),*/
          ],
        ),
      ),
    );
  }
}

class SlimUserDetailCard extends StatelessWidget {
  final String title;
  final MaterialColor color;
  SlimUserDetailCard({this.title, this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 10,
        child : Padding(padding: EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          child: Center(
              child: Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              )),
        ));
  }
}

class SlimUserCard extends StatelessWidget {
  final String title;
  const SlimUserCard({Key key, this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 10,
        child : Padding(padding: EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          child: Center(
              child: Text(title, style: TextStyle(fontSize: 20, ),
              )),
        ));
  }
}
