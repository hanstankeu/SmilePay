import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:intl/intl.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/operator/OperatorlistServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/admin/TransactionByOperatorServices.dart';
import 'package:smilepay/services/transaction/admin/TransactionlistServices.dart';
import 'package:smilepay/view/admin/src/widget/responsive_widget.dart';

class ChartCardTile extends StatefulWidget {
  final Widget child;

  ChartCardTile({Key key, this.child}) : super(key : key);

  @override
  _ChartCardTileState createState() => _ChartCardTileState();
}

class _ChartCardTileState extends State<ChartCardTile> {

  List<charts.Series<Polllution, String>> _seriesBarData;
  List<charts.Series<ByOperator, String>> _seriesPieData;
  List<charts.Series<Sales, int>> _seriesLineData;

  _generateData() async {
    var pieData = [];
    await AdminData.getAdminToken().then((token){
      fetchalltransactionsbyoperator('EU_CMR', token).then((snapshot){
        pieData.add(new ByOperator('EU_CMR', snapshot.length, Colors.blue));
      });
    });

    await AdminData.getAdminToken().then((token){
      fetchalltransactionsbyoperator('MTN_CMR', token).then((snapshot){
        pieData.add(new ByOperator('MTN_CMR', snapshot.length, Colors.yellow));
      });
    });

    await AdminData.getAdminToken().then((token){
      fetchalltransactionsbyoperator('ORANGE_CMR', token).then((snapshot){
        pieData.add(new ByOperator('ORANGE_CMR', snapshot.length, Colors.orange));
      });
    });

    var barData = [
      new Polllution('Express Union', 1940, 40),
      new Polllution('MTN', 1940, 200),
      new Polllution('Orange', 1940, 105),
    ];
    var barData1 = [
      new Polllution('Express Union', 1945, 10),
      new Polllution('MTN', 1940, 47),
      new Polllution('Orange', 1945, 85),
    ];
    var barData2 = [
      new Polllution('Express Union', 1945, 10),
      new Polllution('MTN', 1940, 47),
      new Polllution('Orange', 1945, 85),
    ];

    var lineData = [
      new Sales(0, 40),
      new Sales(1, 45),
      new Sales(2, 52),
      new Sales(3, 98),
      new Sales(4, 35),
      new Sales(5, 23),
    ];
    var lineData1 = [
      new Sales(0, 78),
      new Sales(1, 25),
      new Sales(2, 57),
      new Sales(3, 82),
      new Sales(4, 35),
      new Sales(5, 78),
    ];
    var lineData2 = [
      new Sales(0, 32),
      new Sales(1, 35),
      new Sales(2, 56),
      new Sales(3, 05),
      new Sales(4, 48),
      new Sales(5, 70),
    ];



    _seriesBarData.add(
      charts.Series(
        data: barData,
        domainFn: (Polllution pollution,_) => pollution.place,
        measureFn: (Polllution pollution,_) => pollution.quantity,
        id: '2018',
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Polllution pollution,_) => charts.ColorUtil.fromDartColor(Colors.blue),
      )
    );


    _seriesBarData.add(
        charts.Series(
          data: barData1,
          domainFn: (Polllution pollution,_) => pollution.place,
          measureFn: (Polllution pollution,_) => pollution.quantity,
          id: '2019',
          fillPatternFn: (_, __) => charts.FillPatternType.solid,
          fillColorFn: (Polllution pollution,_) => charts.ColorUtil.fromDartColor(Colors.yellowAccent),
        )
    );

    _seriesBarData.add(
        charts.Series(
          data: barData2,
          domainFn: (Polllution pollution,_) => pollution.place,
          measureFn: (Polllution pollution,_) => pollution.quantity,
          id: '2020',
          fillPatternFn: (_, __) => charts.FillPatternType.solid,
          fillColorFn: (Polllution pollution,_) => charts.ColorUtil.fromDartColor(Colors.orange),
        )
    );

    _seriesPieData.add(
        charts.Series(
            data: pieData,
            domainFn: (ByOperator byOperator,_) => byOperator.operator,
            measureFn: (ByOperator byOperator,_) => byOperator.total,
            colorFn: (ByOperator byOperator,_) => charts.ColorUtil.fromDartColor(byOperator.colorval),
            id: 'Total Transactions',
            labelAccessorFn: (ByOperator row,_) => '${row.total}'
        )
    );

    _seriesLineData.add(
      charts.Series(
        colorFn: (_, __) => charts.ColorUtil.fromDartColor(Colors.blue),
        id: 'Air Pollution',
        data: lineData,
        domainFn: (Sales sales, _) => sales.yearval,
        measureFn: (Sales sales, _) => sales.salesval,
      )
    );

    _seriesLineData.add(
        charts.Series(
          colorFn: (_, __) => charts.ColorUtil.fromDartColor(Colors.yellowAccent),
          id: 'Air Pollution',
          data: lineData1,
          domainFn: (Sales sales, _) => sales.yearval,
          measureFn: (Sales sales, _) => sales.salesval,
        )
    );

    _seriesLineData.add(
        charts.Series(
          colorFn: (_, __) => charts.ColorUtil.fromDartColor(Colors.orange),
          id: 'Air Pollution',
          data: lineData2,
          domainFn: (Sales sales, _) => sales.yearval,
          measureFn: (Sales sales, _) => sales.salesval,
        )
    );
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _seriesBarData = List<charts.Series<Polllution, String>>();
    _seriesPieData = List<charts.Series<ByOperator, String>>();
    _seriesLineData = List<charts.Series<Sales, int>>();
    _generateData();
  }

  @override
  Widget build(BuildContext context) {
    final _media = MediaQuery.of(context).size;
  return DefaultTabController(
    length: 3,
    child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        bottom: TabBar(
            tabs: [
              Tab(icon: Icon(FontAwesomeIcons.solidChartBar),),
              Tab(icon: Icon(FontAwesomeIcons.chartPie),),
              Tab(icon: Icon(FontAwesomeIcons.chartLine),),
        ]),
        title: Text('Statistics', style: TextStyle(color: Colors.yellow),textAlign: TextAlign.center,),
        centerTitle: true,
      ),
      body: TabBarView(
          children: [
            Padding(
              padding: EdgeInsets.all(0.0),
              child: Container(
                child: Center(
                  child: Column(
                    children: <Widget>[
                      Text('So2 missions, by world region (in million tonnes)', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),),
                      Expanded(child: charts.BarChart(
                        _seriesBarData,
                        animate: true,
                        barGroupingType: charts.BarGroupingType.grouped,
                        animationDuration: Duration(seconds: 5),
                      ))
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(0.0),
              child: Container(
                child: Center(
                  child: Column(
                    children: <Widget>[
                      Text('Number of transactions per operator', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontStyle: FontStyle.italic),),
                      SizedBox(height: 10,),
                      Expanded(child: charts.PieChart(
                        _seriesPieData,
                        animate: true,
                        animationDuration: Duration(seconds: 5),
                        behaviors: [
                          new charts.DatumLegend(
                            outsideJustification: charts.OutsideJustification.endDrawArea,
                            horizontalFirst: false,
                            desiredMaxRows: 2,
                            cellPadding: EdgeInsets.only(right: 4, bottom: 4),
                            entryTextStyle: charts.TextStyleSpec(
                              color: charts.MaterialPalette.blue.shadeDefault,
                              fontFamily: 'Georgia',
                              fontSize: 11
                            )
                          )
                        ],
                        defaultRenderer: new charts.ArcRendererConfig(
                          arcWidth: 100,
                          arcRendererDecorators: [
                            new charts.ArcLabelDecorator(
                              labelPosition: charts.ArcLabelPosition.inside
                            )
                          ]
                        ),
                      ))
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(0.0),
              child: Container(
                child: Center(
                  child: Column(
                    children: <Widget>[
                      Text('Sales for the first 5 years', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),),
                      Expanded(
                          child: charts.LineChart(
                            _seriesLineData,
                            defaultRenderer: new charts.LineRendererConfig(
                              includeArea: true, stacked: true),
                            animate: true,
                            animationDuration: Duration(seconds: 5),
                            behaviors: [
                              new charts.ChartTitle('Years',
                                behaviorPosition: charts.BehaviorPosition.bottom,
                                titleOutsideJustification: charts.OutsideJustification.middleDrawArea),
                              new charts.ChartTitle('Sales',
                                  behaviorPosition: charts.BehaviorPosition.start,
                                  titleOutsideJustification: charts.OutsideJustification.middleDrawArea),
                              new charts.ChartTitle('Departments',
                                  behaviorPosition: charts.BehaviorPosition.end,
                                  titleOutsideJustification: charts.OutsideJustification.middleDrawArea),
                            ],
                          ),
                      )
                    ],
                  ),
                ),
              ),
            )
          ]
      ),
    ),
  );
  }
}
//class for the bar chart
class Polllution{
  String place;
  int year;
  int quantity;

  Polllution(this.place, this.year, this.quantity);
}

//class for the pie chart
class ByOperator{
  String operator;
  int total;
  Color colorval;

  ByOperator(this.operator, this.total, this.colorval);
}
//class for the line chart
class Sales{
  int yearval ;
  int salesval;

  Sales(this.yearval, this.salesval);
}