import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/admin/TransactionlistServices.dart';
class Tansactionlist extends StatefulWidget {
  Tansactionlist({Key key}) : super(key:key);

  @override
  _TansactionlistState createState() => _TansactionlistState();
}

class _TansactionlistState extends State<Tansactionlist> {

  List<Transaction> transactions = List();
  List<Transaction> filteredTransacttions = List();
  bool isSearching = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    AdminData.getAdminToken().then((token){
      fetchalltransactions(token).then((snapshot){
        setState(() {
          transactions = filteredTransacttions = snapshot;
        });
      });
    });
  }

  void filterTransactions(value){
    setState(() {
      filteredTransacttions = transactions.
      where((user) => user.numberSender.toLowerCase().contains(value.toLowerCase())
          || user.numberReceiver.toLowerCase().contains(value.toLowerCase())).toList();
    });
  }


  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: !isSearching
            ? Text('All Transactions', style: TextStyle(color: Colors.yellow),)
            : TextField(
          onChanged: (value) {
            filterTransactions(value);
          },
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              hintText: "Search Transaction Here",
              hintStyle: TextStyle(color: Colors.white)),
        ),
        actions: <Widget>[
          isSearching
              ? IconButton(
            icon: Icon(Icons.cancel),
            onPressed: () {
              setState(() {
                this.isSearching = false;
                filteredTransacttions = transactions;
              });
            },
          )
              : IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              setState(() {
                this.isSearching = true;
              });
            },
          )
        ],
      ),
      body: Container(
          padding: EdgeInsets.all(10),
          child:  FutureBuilder<String>(
              future: AdminData.getAdminToken(),
              builder: (context, token){
                if(token.hasData){
                  return FutureBuilder<List<Transaction>>(
                    future: fetchalltransactions(token.data),
                    builder: (context, snapshot){
                      if (snapshot.hasData){
                        filteredTransacttions = snapshot.data;
                        return ListView.builder(
                            itemCount: filteredTransacttions.length,
                            itemBuilder: (BuildContext context, int index) {
                              return GestureDetector(
                                onTap: () {
                                  /*Navigator.of(context).pushNamed(Country.routeName,
                              arguments: filteredUsers[index]);*/
                                },
                                child: Card(
                                  elevation: 10,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10, horizontal: 8),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text('Sender : ' + filteredTransacttions[index].numberSender, style: TextStyle(fontSize: 15),),
                                        Text(snapshot.data[index].numberReceiver == null? 'Receiver : Me' : 'Receiver :' + snapshot.data[index].numberReceiver, style: TextStyle(fontSize: 15)),
                                        Text('Amount : ' + filteredTransacttions[index].amount.toString(), style: TextStyle(fontWeight: FontWeight.bold),),
                                        Text('Type : ' +
                                            snapshot.data[index].type.toString(),
                                          style: TextStyle(fontSize: 12),
                                        ),
                                        Text('Date : ' +
                                            snapshot.data[index].dateCreation.toString().substring(0,10),
                                          style: TextStyle(fontSize: 12),
                                        ),
                                        Text('Time : ' +
                                            snapshot.data[index].dateCreation.toString().substring(10,19),
                                          style: TextStyle(fontSize: 12),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            });
                      }else if(snapshot.hasError){
                        print(snapshot.error);
                      }else {
                        return SnackBar(content: Text('There is no transaction '));
                      }
                      return  Center(child: CircularProgressIndicator());},
                  );
                }
                else{
                  return CircularProgressIndicator();
                }
              }
          )
      ),
    );
  }
}
