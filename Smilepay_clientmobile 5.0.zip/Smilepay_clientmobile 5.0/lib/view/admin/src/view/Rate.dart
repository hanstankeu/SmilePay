import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Rate.dart';
import 'package:smilepay/services/rate/RatelistServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/rate/RatecreateServices.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/admin/src/view/Ratelist.dart';
import 'package:smilepay/view/admin/src/widget/rate_details.dart';

class RateAdmin extends StatefulWidget {
  Key key;
  @override
  _RateAdminState createState() => _RateAdminState();
}

class _RateAdminState extends State<RateAdmin> {
  final _formKey = GlobalKey<FormState>();
  String _idRate;
  double _minimum;
  double _maximum;
  double _value;
  DateTime _dateCreation;
  DateTime _dateModification;

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);


  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Rate', style: TextStyle(color: Colors.yellow),),
          centerTitle: true,
          bottom: TabBar(
            isScrollable: true,
            tabs: <Widget>[
              Text('Create rate'),
              Text('Rate list'),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            //create rate
            Container(
              color: Colors.white,
              child: ListView(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(left : 10, right : 10, top: 10, bottom: 10),
                    child: Container(
                      color: Colors.white,
                      child: Center(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              SizedBox(height: 10),
                              Container(
                                alignment: Alignment.center,
                                child: Text('Create operator', style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FontStyle.italic,
                                ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              SizedBox(height: 20),
                              /**
                               * minimum amount
                               */
                              Material(
                                elevation: 8.0,
                                shadowColor: Colors.grey,
                                borderRadius: BorderRadius.circular(4),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  onSaved: (value){
                                    _minimum = double.parse(value);
                                  },
                                  decoration: InputDecoration(
                                      icon: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Icon(Icons.remove, color: Colors.black),
                                      ),
                                      hintText: 'Minimum value',
                                      fillColor: Colors.white,
                                      //filled: true,
                                      contentPadding:
                                      EdgeInsets.fromLTRB(10.0, 10.0, 20.0, 15.0),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                          borderSide:
                                          BorderSide(color: Colors.white, width: 0.0))),
                                  validator: formfieldValidator,
                                ),
                              ),
                              SizedBox(height: 20),
                              /**
                               * maximum amount
                               */
                              Material(
                                elevation: 8.0,
                                shadowColor: Colors.grey,
                                borderRadius: BorderRadius.circular(4),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  onSaved: (value){
                                    _maximum = double.parse(value);
                                  },
                                  decoration: InputDecoration(
                                      icon: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Icon(Icons.add, color: Colors.black),
                                      ),
                                      hintText: 'Maximum value',
                                      fillColor: Colors.white,
                                      //filled: true,
                                      contentPadding:
                                      EdgeInsets.fromLTRB(10.0, 10.0, 20.0, 10.0),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                          borderSide:
                                          BorderSide(color: Colors.white, width: 0.0))),
                                  validator: formfieldValidator,
                                ),
                              ),
                              SizedBox(height: 20),
                              /**
                               * value in percentage
                               */
                              Material(
                                elevation: 8.0,
                                shadowColor: Colors.grey,
                                borderRadius: BorderRadius.circular(4),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  onSaved: (value){
                                    _value = double.parse(value);
                                  },
                                  decoration: InputDecoration(
                                      icon: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Icon(Icons.monetization_on, color: Colors.black),
                                      ),
                                      hintText: 'Enter Rate',
                                      fillColor: Colors.white,
                                      filled: true,
                                      contentPadding:
                                      EdgeInsets.fromLTRB(10.0, 10.0, 20.0, 10.0),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(5.0),
                                          borderSide:
                                          BorderSide(color: Colors.white, width: 0.0))),
                                  validator: formfieldValidator,
                                ),
                              ),
                              SizedBox(height: 20),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: InkWell(
                                  onTap: () async {
                                    if(_formKey.currentState.validate()){
                                      _formKey.currentState.save();
                                      await MainPage.storage.read(key: 'token').then((token){
                                        createrate(Rate(_idRate, _minimum, _maximum, _value, _dateCreation, _dateModification), token).then((response) async {
                                          if(response.statusCode == 200){
                                            print(response.statusCode);
                                            await Fluttertoast.showToast(msg: "Rate created",
                                                toastLength: Toast.LENGTH_LONG,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 5,
                                                backgroundColor: Colors.black,
                                                textColor: Colors.yellowAccent,
                                                fontSize: 15.0
                                            );
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => Ratelist()));
                                          }
                                          if(response.statusCode == 401){
                                            print(response.statusCode.toString());
                                            await Fluttertoast.showToast(msg: "Invalid informations",
                                                toastLength: Toast.LENGTH_LONG,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 5,
                                                backgroundColor: Colors.black,
                                                textColor: Colors.yellowAccent,
                                                fontSize: 15.0
                                            );
                                          }
                                          else if (response.statusCode == 500){
                                            await Fluttertoast.showToast(msg: "Server unvailable. Please try later",
                                                toastLength: Toast.LENGTH_LONG,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 5,
                                                backgroundColor: Colors.black,
                                                textColor: Colors.yellowAccent,
                                                fontSize: 15.0
                                            );
                                          }
                                        });
                                      });
                                    }
                                  },
                                  child: Material(
                                    shadowColor: Colors.grey,
                                    elevation: 10,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    color: Colors.yellow[500],
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: 30,
                                      width: 80,
                                      child: Text(
                                        'Save',
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            //rate list
            Container(
                padding: EdgeInsets.all(10),
                child:  FutureBuilder<String>(
                    future: AdminData.getAdminToken(),
                    builder: (context, token){
                      if(token.hasData){
                        return  FutureBuilder<List<Rate>>(
                          future: fetchallrates(token.data),
                          builder: (context, snapshot){
                            if (snapshot.hasData){
                              return ListView.builder(
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return GestureDetector(
                                      onTap: () {
                                        Navigator.of(context).push(new MaterialPageRoute(
                                            builder: (context)=> new RateDetails(rate : snapshot.data[index])
                                        ));
                                      },
                                      child: Card(
                                        elevation: 10,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 8),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Text('Value : ' +
                                                  snapshot.data[index].value.toString(),
                                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),

                                              ),
                                              SizedBox(height: 5,),
                                              Text('Minimum amount : ' +
                                                  snapshot.data[index].minimum.toString(),
                                                style: TextStyle(fontSize: 12),
                                              ),
                                              Text('Maximum amount : ' +
                                                  snapshot.data[index].maximum.toString(),
                                                style: TextStyle(fontSize: 12),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    );

                                  });
                            }else if(snapshot.hasError){
                              print(snapshot.error);
                            }
                            return  Center(child: CircularProgressIndicator());},
                        );
                      }
                      else{
                        return Center(child: CircularProgressIndicator());
                      }
                    }
                )
            ),
          ],
        )
      ),
    );
  }
}
