import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/operator/OperatorcreateServices.dart';
import 'package:smilepay/services/operator/OperatorlistServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/view/admin/src/widget/operator_details.dart';
import 'package:smilepay/view/user/view/profile/completeInformations.dart';

import '../../../user/view/dashboard.dart';

class OperatorAdmin extends StatefulWidget {
  @override
  _OperatorAdminState createState() => _OperatorAdminState();
}

class _OperatorAdminState extends State<OperatorAdmin> {
  final _formKey = GlobalKey<FormState>();

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone number is required'),
    MinLengthValidator(9, errorText: 'Telephone number should be atleast 9 characters'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  //Operator
  String _idOperator;
  String _label;
  String _code;
  DateTime _dateCreation = DateTime.now();
  DateTime _dateModification = DateTime.now();
  String _logo;

  List<DropdownMenuItem> operators = [
    DropdownMenuItem(child: Text('EXPRESSE UNION'), value: 'EU_CMR',),
    DropdownMenuItem(child: Text('MTN'), value: 'MTN_CMR',),
    DropdownMenuItem(child: Text('ORANGE'), value: 'ORANGE_CMR',),
  ];

  final _picker = ImagePicker();
  File image;

  String lol;
  dynamic _pickImageError;
  //logo gallery open


  Future openGalley(BuildContext context) async {
    try{
      var picture = await _picker.getImage(source: ImageSource.gallery);
      setState(() {
        image = File(picture.path);
        image.readAsBytes().then((bytes){
          _logo = Base64Encoder().convert(bytes);});

      });
    }catch (e) {
      setState(() {
        _pickImageError = e;
        print(e);
      });
    }
    Navigator.of(context).pop;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Operator', style: TextStyle(color: Colors.blue),textAlign: TextAlign.center,),
          centerTitle: true,
          bottom: TabBar(
              isScrollable: true,
              tabs: <Widget>[
                Text('Create operator'),
                Text('Operator list'),
              ]),
        ),
        body: TabBarView(
          children: <Widget>[

            //CREATE OPERATOR
            Container(
              padding: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                border: Border(),
                borderRadius: BorderRadius.circular(10),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                    offset: Offset(0, 6.0),
                  ),
                ],
              ),
              child: Center(
                child: Form(
                  key: _formKey,
                  child: ListView(
                    children: <Widget>[
                      SizedBox(height: 10,),
                      Text('Create operator', style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                      ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 20),
                      //label
                      Material(
                        elevation: 8.0,
                        shadowColor: Colors.grey,
                        borderRadius: BorderRadius.circular(4),
                        child: TextFormField(
                          onSaved: (value){
                            _label = value;
                          },
                          decoration: InputDecoration(
                              icon: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Icon(Icons.label, color: Colors.black),
                              ),
                              hintText: 'label',
                              fillColor: Colors.white,
                              //filled: true,
                              contentPadding:
                              EdgeInsets.fromLTRB(10.0, 10.0, 20.0, 15.0),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5.0),
                                  borderSide:
                                  BorderSide(color: Colors.white, width: 0.0))),
                          validator: formfieldValidator,
                        ),
                      ),
                      SizedBox(height: 20),
                      // operator
                      Material(
                        elevation: 8.0,
                        shadowColor: Colors.grey,
                        borderRadius: BorderRadius.circular(4),
                        child: TextFormField(
                          onSaved: (value){
                            _code = value;
                          },
                          decoration: InputDecoration(
                              icon: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Icon(Icons.network_cell, color: Colors.black),
                              ),
                              hintText: 'Code',
                              fillColor: Colors.white,
                              //filled: true,
                              contentPadding:
                              EdgeInsets.fromLTRB(10.0, 10.0, 20.0, 15.0),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5.0),
                                  borderSide:
                                  BorderSide(color: Colors.white, width: 0.0))),
                          validator: formfieldValidator,
                        ),
                      ),
                      SizedBox(height: 20),
                      //logo
                      Material(
                        elevation: 8.0,
                        shadowColor: Colors.grey,
                        borderRadius: BorderRadius.circular(4),
                        child: Row(
                          children: <Widget>[
                            IconButton(
                              icon: Icon(Icons.attach_file),
                              onPressed: (){
                                openGalley(context);
                              },
                            ),
                            Expanded(
                              child: FlatButton(
                                  onPressed: (){
                                    openGalley(context);
                                  },
                                  child: Text(_logo == null? 'Choose a file' : 'Image selected')
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 20),

                      /*Container(
                        child: FutureBuilder(
                            builder: (context, snapshot){
                              if(_logo != null){
                                return Image.memory(
                                  Base64Decoder().convert(_logo),
                                  height: 100,
                                  width: 100,
                                );
                              }
                              else{
                                return Center(child: CircularProgressIndicator(),);
                              }
                            }
                        ),
                      ),*/

                      SizedBox(height: 20,),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: InkWell(
                          onTap: () async {
                            if(_formKey.currentState.validate()){
                              _formKey.currentState.save();
                              await AdminData.getAdminToken().then((token) async {
                                print(token);
                                print(_label);
                                print(_code);
                                createoperator(Operator(_idOperator, _label, _code, _dateCreation, _dateModification, _logo), token)
                                    .then((response) {
                                  print(response.statusCode);
                                  print(response.body);
                                  Center(child: CircularProgressIndicator(),);
                                  if(response.statusCode == 200){
                                    Fluttertoast.showToast(msg: "Operator created !!! ",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 5,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 15.0);
                                    Navigator.pop(context);
                                  }
                                  if(response.statusCode == 401){
                                    print(response.statusCode.toString());
                                    Fluttertoast.showToast(msg: "Invalid informations",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 5,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.yellowAccent,
                                        fontSize: 15.0);
                                  }
                                });
                              });
                            }
                          },
                          child: Material(
                            shadowColor: Colors.grey,
                            elevation: 10,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            color: Colors.yellow[500],
                            child: Container(
                              alignment: Alignment.center,
                              height: 30,
                              width: 80,
                              child: Text(
                                'Save',
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10,),
                    ],
                  ),
                ),
              ),
            ),

            //operator list
            Container(
                padding: EdgeInsets.all(10),
                child:  FutureBuilder<String>(
                  //get token
                    future: UserData.getToken(),
                    builder: (context, token){
                      if(token.hasData){
                        return  FutureBuilder<List<Operator>>(
                          future: fetchalloperators(token.data),
                          builder: (context, snapshot){
                            if (snapshot.hasData){
                              //build operator list
                              return ListView.builder(
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return GestureDetector(
                                      onTap: () {
                                        Navigator.of(context).push(new MaterialPageRoute(
                                            builder: (context)=> new OperatorDetails(operator : snapshot.data[index])
                                        ));
                                      },
                                      child: Card(
                                        elevation: 10,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 8),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Text('Name : ' +
                                                  snapshot.data[index].label.toString(),
                                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),

                                              ),
                                              SizedBox(height: 5,),
                                              Text('Code : ' +
                                                  snapshot.data[index].code.toString(),
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );

                                  });
                            }else if(snapshot.hasError){
                              print(snapshot.error);
                            }
                            return  Center(child: CircularProgressIndicator());},
                        );
                      }
                      else{
                        return Center(child: CircularProgressIndicator());
                      }
                    }
                )
            ),

          ],
        )
      ),
    );
  }
}
