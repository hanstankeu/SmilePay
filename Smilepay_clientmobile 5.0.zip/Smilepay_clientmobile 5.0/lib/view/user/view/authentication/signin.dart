import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/JWTResponse.dart';
import 'package:smilepay/model/LoginRequest.dart';
import 'package:smilepay/model/UserCard.dart';
import 'package:smilepay/services/authentication/AuthenticationServices.dart';
import 'package:flutter/rendering.dart';
import 'package:smilepay/view/admin/src/pages/main_page.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:smilepay/view/user/view/authentication/signup.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/view/user/view/transaction/custom_alert_dialog.dart';
import 'package:smilepay/viewFR/user/view/authentication/signin.dart';

class LogIn extends StatefulWidget {
  @override
  _LogInState createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  final _formKey = GlobalKey<FormState>();

  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password is required'),
    MinLengthValidator(8, errorText: 'Password should contain atleast 8 characters'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])', errorText: 'passwords must have at least one special character')
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  static String _username = '';
  static String _password = '';
  bool _showPassword = false;

  @override
  Widget build(BuildContext context) {
    void showAlertDialogParam(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    Center(child:Text('Change The Language !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn1()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.blue,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'FRENCH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.greenAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'ENGLISH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                  ],
                ),

              ),
            );
          });
    }

    Future<bool> _onWillPop() async {
      return (await showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          title: new Text('Are you sure?'),
          content: new Text('Do you want to exit SmilePay ?'),
          actions: <Widget>[
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: new Text('No'),
            ),
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: new Text('Yes'),
            ),
          ],
        ),
      )) ?? false;
    }
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        //backgroundColor: Colors.black,
        body: Stack(
          children: <Widget>[
            /*Image.asset(
              'images/back.jpeg',
              fit: BoxFit.fill,
              width: double.infinity,
              height: double.infinity,
            ),*/
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black, Colors.yellow]
                )
              ),
              //color: Colors.black.withOpacity(0.8),
              width: double.infinity,
              height: double.infinity,
            ),
            FlutterLogo(),
            Container(
                alignment: Alignment.topCenter,
                child: Image.asset(
                  'images/smilepaylogo.png',
                  width: 230.0,
                  height: 210.0,
                )
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 220, 20, 16),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Colors.white,
                  ),
                  child: Center(
                    child: Form(
                      key: _formKey,
                        child: ListView(
                          children: <Widget>[
                            //title
                            Text('Sign in', textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 25),),
                            //username
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(25.0),
                                color: Colors.yellow,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: TextFormField(
                                    cursorColor: Colors.black,
                                    onChanged: (value){
                                      setState(() {
                                        _username = value;
                                      });
                                   },
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      labelText: "Username",
                                      icon: Icon(Icons.perm_identity,color: Colors.black,),
                                    ),
                                    validator: formfieldValidator,
                                  ),
                                ),
                              ),
                            ),
                            //password
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(25.0),
                                color: Colors.yellow,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: TextFormField(
                                    cursorColor: Colors.black,
                                   onChanged: (value){
                                     setState(() {
                                       _password = value;
                                     });
                                   },
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      labelText: 'Password',
                                      icon: Icon(Icons.lock_outline, color: Colors.black,),
                                      suffixIcon: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            _showPassword = !_showPassword;
                                          });
                                        },
                                        child: Icon(
                                          _showPassword ? Icons.visibility : Icons.visibility_off,
                                        ),
                                      ),
                                    ),
                                    obscureText: !_showPassword,
                                    validator: formfieldValidator,
                                  ),
                                ),
                              ),
                            ),
                            //password forgotten
/*                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: InkWell(
                                onTap: (){
                                  print('password forgotten');
                                },
                                child: Text(
                                  "password forgotten",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),*/
                            SizedBox(height: 20,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                //sign in
                                SizedBox(width: 20,),
                                Expanded(
                                  child: Material(
                                      borderRadius: BorderRadius.circular(20.0),
                                      color: Colors.yellow,
                                      elevation: 0.0,
                                      child: MaterialButton(
                                        onPressed: () {
                                          if(_formKey.currentState.validate()){
                                            _formKey.currentState.save();
                                            authentication(LoginRequest(_username, _password)).then((response) async{
                                              print(response.statusCode);
                                              if(response.statusCode == 200){
                                                JWTResponse jwtResponse = JWTResponse.convertfromJson(json.decode(response.body));
                                                for(String r in jwtResponse.roles){
                                                  if(r == "ROLE_ADMIN"){
                                                    // if it's an admin
                                                    await MainPage.storage.write(key : "token", value : jwtResponse.token);
                                                    await MainPage.storage.write(key: "id", value: jwtResponse.id);
                                                    await MainPage.storage.write(key: "phone", value: jwtResponse.phone);
                                                    if(jwtResponse.name != null && jwtResponse.surname != null){
                                                      await MainPage.storage.write(key : "noms", value : jwtResponse.surname + " " + jwtResponse.name);
                                                    }else{
                                                      await MainPage.storage.write(key : "noms", value : " ");
                                                    }
                                                    await MainPage.storage.write(key: "email", value: jwtResponse.email);
                                                    await MainPage.storage.write(key : "username", value : jwtResponse.username);
                                                    //await MainPage.storage.write(key: "type", value: jwtResponse.type);
                                                    await MainPage.storage.write(key: 'phone', value: jwtResponse.phone);
                                                    await MainPage.storage.write(key: "balance", value: jwtResponse.balance.toString());
                                                    await Navigator.push(context, MaterialPageRoute(builder: (context) => MainPage()));
                                                  }else if(r == "ROLE_USER"){
                                                    //if it's a user
                                                    if(!jwtResponse.state){
                                                      print(response.statusCode.toString());
                                                      await Fluttertoast.showToast(msg: response.body,
                                                          toastLength: Toast.LENGTH_LONG,
                                                          gravity: ToastGravity.CENTER,
                                                          timeInSecForIosWeb: 3,
                                                          backgroundColor: Colors.black,
                                                          textColor: Colors.yellowAccent,
                                                          fontSize: 15.0
                                                      );
                                                    }else if(jwtResponse.state){
                                                      await HomePage.storage.write(key : "token", value : jwtResponse.token);
                                                      if(jwtResponse.name != null && jwtResponse.surname != null){
                                                        await HomePage.storage.write(key : "noms", value : jwtResponse.surname + " " + jwtResponse.name);
                                                      }else{
                                                        await HomePage.storage.write(key : "noms", value : " ");
                                                      }
                                                      await HomePage.storage.write(key: "id", value: jwtResponse.id);
                                                      await HomePage.storage.write(key: "phone", value: jwtResponse.phone);
                                                      await HomePage.storage.write(key: "email", value: jwtResponse.email);
                                                      await HomePage.storage.write(key : "username", value : jwtResponse.username);
                                                      await HomePage.storage.write(key: 'phone', value: jwtResponse.phone);
                                                      //await HomePage.storage.write(key: 'surname', value: jwtResponse.surname);
                                                      //await HomePage.storage.write(key: "type", value: jwtResponse.type);
                                                      await HomePage.storage.write(key: "balance", value: jwtResponse.balance.toString());
                                                      await Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                                    }
                                                  }
                                                }
                                              }
                                              else{
                                                print("Username or Password is incorrect");
                                                print(response.statusCode.toString());
                                                await Fluttertoast.showToast(msg: response.body,
                                                    toastLength: Toast.LENGTH_LONG,
                                                    gravity: ToastGravity.CENTER,
                                                    timeInSecForIosWeb: 3,
                                                    backgroundColor: Colors.black,
                                                    textColor: Colors.yellowAccent,
                                                    fontSize: 15.0
                                                );

                                              }
                                            });
                                          }

                                        },
                                        minWidth: MediaQuery.of(context).size.width,
                                        child: Text(
                                          "Sign In",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20.0),
                                        ),
                                      )
                                  ),
                                ),
                                SizedBox(width: 10,),
                                //sign up
                                Expanded(
                                  child: Material(
                                      borderRadius: BorderRadius.circular(20.0),
                                      color: Colors.yellow[100],
                                      elevation: 0.0,
                                      child: MaterialButton(
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp()));
                                        },
                                        minWidth: MediaQuery.of(context).size.width,
                                        child: Text(
                                          "Sign Up",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20.0),
                                        ),
                                      )
                                  ),
                                ),
                                SizedBox(width: 20,),
                              ],
                            ),
                            SizedBox(height: 10,),
                            //Settings
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: InkWell(
                                onTap: () {
                                  showAlertDialogParam(context);
                                },
                                child: Material(
                                  shadowColor: Colors.grey,
                                  elevation: 10,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  color: Colors.blue,
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: 45,
                                    width: 160,
                                    child: ListTile(
                                      title: Text('Settings', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: Colors.black87),),
                                      leading: Icon(Icons.settings, color: Colors.redAccent,),
                                    ),

                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                    ),
                  ),
                ),
              ),
            ),
            /*Visibility(
             // visible: loading ?? true,
              child: Center(
                child: Container(
                  alignment: Alignment.center,
                  color: Colors.white.withOpacity(0.9),
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                  ),
                ),
              ),
            )*/
          ],
        ),
      ),
    );  
  }
}
