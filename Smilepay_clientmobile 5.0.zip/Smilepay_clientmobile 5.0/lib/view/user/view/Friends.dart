import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:http/http.dart' as http;
import 'package:smilepay/services/user/FriendsServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/user/UserUnactivateServices.dart';
import 'package:smilepay/services/user/UserlistServices.dart';
import 'package:smilepay/view/admin/src/widget/user_details.dart';
import 'package:smilepay/view/user/view/dashboard.dart';

class Friends extends StatefulWidget {
  Friends({Key key}) : super(key:key);

  @override
  _FriendsState createState() => _FriendsState();
}

class _FriendsState extends State<Friends> {

  List<UserAccount> users = List();
  List<UserAccount> filteredUsers = List();
  bool isSearching = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    HomePage.storage.read(key: 'token').then((token){
      fetchalluser(token).then((snapshot){
        setState(() {
          users = filteredUsers = snapshot;
        });
      });
    });
  }

  void filterUsers(value){
    setState(() {
      filteredUsers = users.where((user) => user.email.toLowerCase().contains(value.toLowerCase())).toList();
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black,
        title: !isSearching
            ? Text('Friend list', style: TextStyle(color: Colors.yellow),)
            : TextField(
          onChanged: (value) {
            filterUsers(value);
          },

          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              hintText: "Search User Here",
              hintStyle: TextStyle(color: Colors.white)),
        ),
        actions: <Widget>[
          isSearching
              ? IconButton(
            icon: Icon(Icons.cancel),
            onPressed: () {
              setState(() {
                this.isSearching = false;
                filteredUsers = users;
              });
            },
          )
              : IconButton(
            icon: Icon(Icons.search, color: Colors.yellowAccent,),
            onPressed: () {
              setState(() {
                this.isSearching = true;
              });
            },
          )
        ],
      ),
      body: Container(
          color: Colors.yellow[100],
          padding: EdgeInsets.all(10),
          child:  FutureBuilder<String>(
              future: UserData.getToken(),
              builder: (context, token){
                if(token.hasData){
                  return FutureBuilder(
                      future: UserData.getId(),
                      builder: (context, idPerson){
                        if(idPerson.hasData){
                          return FutureBuilder<List<UserAccount>>(
                              future: fetchallfriends(token.data, idPerson.data),
                              builder: (context, snapshot){
                                if (snapshot.hasData){
                                  return ListView.builder(
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (BuildContext context, int index) {
                                        return GestureDetector(
                                          onTap: () {

                                          },
                                          child: Card(
                                            elevation: 10,
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  vertical: 10, horizontal: 8),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    snapshot.data[index].email,
                                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                  ),
                                                  SizedBox(height: 5,),
                                                  Row(
                                                    children: <Widget>[
                                                      Text(
                                                        snapshot.data[index].name == null? '':
                                                        snapshot.data[index].name,
                                                        style: TextStyle(fontSize: 12),
                                                      ),
                                                      Text( snapshot.data[index].surname == null? '':
                                                      ' ' +
                                                          snapshot.data[index].surname,
                                                        style: TextStyle(fontSize: 12),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      });
                                }else{
                                  return Center(child: Text('There is no user'));
                                }
                              }
                          );}
                        else{
                          return Center(child: CircularProgressIndicator(),);
                        }
                      });
                }
                else{
                  return Center(child: CircularProgressIndicator());
                }
              }
          )
      ),
    );
  }
}
