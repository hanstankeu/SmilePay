import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/services/operator/OperatorByPhoneServices.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/services/user/UserfindOneServices.dart';
import 'package:smilepay/view/Functions.dart';
import 'package:smilepay/view/user/view/contacts/maine.dart';

import '../profile/completeInformations.dart';
import '../dashboard.dart';
import 'WalletInToWalletIn.dart';
import 'custom_alert_dialog.dart';

class ConfirmTransWEWI extends StatefulWidget {
  String number;
  int amount;
  ConfirmTransWEWI({this.number,this.amount});
  @override
  _ConfirmTransState createState() => _ConfirmTransState();
}

class _ConfirmTransState extends State<ConfirmTransWEWI> {
  final _formKey = GlobalKey<FormState>();

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone number is required'),
    MinLengthValidator(9, errorText: 'Telephone number should be atleast 9 characters'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  static String _password = '';
  bool _showPassword = false;

  String _idTransaction = null;
  DateTime _dateCreationTransaction = null;
  int _amountTransaction ;
  String _numberSender ;
  String _type;

  List<DropdownMenuItem> operators = [
    DropdownMenuItem(child: Text('MTN'), value: 'MTN_CMR',),
    DropdownMenuItem(child: Text('ORANGE'), value: 'ORANGE_CMR',),
  ];

  @override
  Widget build(BuildContext context) {

    final mq = MediaQuery.of(context);

    void showAlertDialog(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 40,),
                    Center(child: Icon(Icons.data_usage, color: Colors.lightBlue[900],size: 40,),),
                    SizedBox(height: 30,),
                    Center(child:Text('Please Wait !!!', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 10,),
                    Center(child:Text('Transaction en cours...', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 10,),

                  ],
                ),
              ),
            );
          });
    }


    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(10),
        key: _formKey,
        child: Center(
          child: Form(
              key: _formKey,
              child: FutureBuilder<String>(
                  future: UserData.getToken(),
                  builder: (context, token){
                    if(token.hasData){
                      return FutureBuilder<String>(
                          future: UserData.getId(),
                          builder: (context, idPerson){
                            if(idPerson.hasData){
                              return FutureBuilder<UserAccount>(
                                future: fetchoneuser(idPerson.data, token.data),
                                builder: (context, snapshot){
                                  if (snapshot.hasData){
                                    double tot=0.0;
                                    int mon=snapshot.data.amountuser;
                                    tot=mon+(mon*0.02);
                                    return ListView.builder(
                                        itemCount: 1,
                                        itemBuilder: (BuildContext context, int index) {
                                          return Card(
                                            elevation: 10,
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  vertical: 10, horizontal: 8),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  SizedBox(height: 5,),
                                                  Center(child:Text('Confirm The Transaction', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Colors.black87),textAlign: TextAlign.center,)),
                                                  SizedBox(height: 30,),
                                                  //Nom
                                                  ListView.builder(
                                                    itemBuilder: (context, index){
                                                      return Container(
                                                        margin: EdgeInsets.symmetric(horizontal: 15),
                                                        padding: EdgeInsets.all(10),
                                                        decoration: BoxDecoration(
                                                            color: Colors.yellow,
                                                            borderRadius: BorderRadius.all(Radius.circular(20))
                                                        ),
                                                        child: Row(
                                                          children: <Widget>[
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.grey[100],
                                                                  borderRadius: BorderRadius.all(Radius.circular(18))
                                                              ),
                                                              child: Icon(Icons.account_circle, color: Colors.lightBlue[900],size: 12,),
                                                              padding: EdgeInsets.all(12),
                                                            ),

                                                            SizedBox(width: 2,),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Text("Nom: ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                                                                ],
                                                              ),
                                                            ),

                                                            SizedBox(width: 10,),
                                                            Column(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              children: <Widget>[
                                                                Text('${snapshot.data.username.toString()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                    shrinkWrap: true,
                                                    itemCount: 1,
                                                    padding: EdgeInsets.all(0),
                                                    controller: ScrollController(keepScrollOffset: true),
                                                  ),
                                                  SizedBox(height: 1,),
                                                  //Sender
                                                  ListView.builder(
                                                    itemBuilder: (context, index){
                                                      return Container(
                                                        margin: EdgeInsets.symmetric(horizontal: 15),
                                                        padding: EdgeInsets.all(10),
                                                        decoration: BoxDecoration(
                                                            color: Colors.yellow,
                                                            borderRadius: BorderRadius.all(Radius.circular(20))
                                                        ),
                                                        child: Row(
                                                          children: <Widget>[
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.grey[100],
                                                                  borderRadius: BorderRadius.all(Radius.circular(18))
                                                              ),
                                                              child: Icon(Icons.person_outline, color: Colors.lightBlue[900],size: 12,),
                                                              padding: EdgeInsets.all(12),
                                                            ),

                                                            SizedBox(width: 2,),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Text("Number Sender: ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                                                                ],
                                                              ),
                                                            ),

                                                            SizedBox(width: 10,),
                                                            Column(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              children: <Widget>[
                                                                Text('${snapshot.data.phone.toString()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                    shrinkWrap: true,
                                                    itemCount: 1,
                                                    padding: EdgeInsets.all(0),
                                                    controller: ScrollController(keepScrollOffset: true),
                                                  ),
                                                  SizedBox(height: 1,),
                                                  //Amount
                                                  ListView.builder(
                                                    itemBuilder: (context, index){
                                                      return Container(
                                                        margin: EdgeInsets.symmetric(horizontal: 15),
                                                        padding: EdgeInsets.all(10),
                                                        decoration: BoxDecoration(
                                                            color: Colors.yellow,
                                                            borderRadius: BorderRadius.all(Radius.circular(20))
                                                        ),
                                                        child: Row(
                                                          children: <Widget>[
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.grey[100],
                                                                  borderRadius: BorderRadius.all(Radius.circular(18))
                                                              ),
                                                              child: Icon(Icons.attach_money, color: Colors.lightBlue[900],size: 12,),
                                                              padding: EdgeInsets.all(12),
                                                            ),

                                                            SizedBox(width: 2,),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Text("Amount: ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                                                                ],
                                                              ),
                                                            ),

                                                            SizedBox(width: 10,),
                                                            Column(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              children: <Widget>[
                                                                Text('${snapshot.data.amountuser.toString()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                    shrinkWrap: true,
                                                    itemCount: 1,
                                                    padding: EdgeInsets.all(0),
                                                    controller: ScrollController(keepScrollOffset: true),
                                                  ),
                                                  SizedBox(height: 1,),
                                                  //Rate
                                                  ListView.builder(
                                                    itemBuilder: (context, index){
                                                      return Container(
                                                        margin: EdgeInsets.symmetric(horizontal: 15),
                                                        padding: EdgeInsets.all(10),
                                                        decoration: BoxDecoration(
                                                            color: Colors.yellow,
                                                            borderRadius: BorderRadius.all(Radius.circular(20))
                                                        ),
                                                        child: Row(
                                                          children: <Widget>[
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.grey[100],
                                                                  borderRadius: BorderRadius.all(Radius.circular(18))
                                                              ),
                                                              child: Icon(Icons.pie_chart, color: Colors.lightBlue[900],size: 12,),
                                                              padding: EdgeInsets.all(12),
                                                            ),

                                                            SizedBox(width: 2,),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Text("Rate: ", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                                                                ],
                                                              ),
                                                            ),

                                                            SizedBox(width: 10,),
                                                            Column(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              children: <Widget>[
                                                                Text("2%", style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                    shrinkWrap: true,
                                                    itemCount: 1,
                                                    padding: EdgeInsets.all(0),
                                                    controller: ScrollController(keepScrollOffset: true),
                                                  ),
                                                  SizedBox(height: 1,),
                                                  //Total
                                                  ListView.builder(
                                                    itemBuilder: (context, index){
                                                      return Container(
                                                        margin: EdgeInsets.symmetric(horizontal: 15),
                                                        padding: EdgeInsets.all(16),
                                                        decoration: BoxDecoration(
                                                            color: Colors.black12,
                                                            borderRadius: BorderRadius.all(Radius.circular(20))
                                                        ),
                                                        child: Row(
                                                          children: <Widget>[
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.grey[100],
                                                                  borderRadius: BorderRadius.all(Radius.circular(18))
                                                              ),
                                                              child: Icon(Icons.attach_money, color: Colors.lightBlue[900],size: 18,),
                                                              padding: EdgeInsets.all(12),
                                                            ),

                                                            SizedBox(width: 2,),

                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Text("TOTAL:", style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                                                                ],
                                                              ),
                                                            ),

                                                            SizedBox(width: 10,),
                                                            Column(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              children: <Widget>[
                                                                Text('${tot}', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.orange),),
                                                                Text(' FCFA', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.orange),),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                    shrinkWrap: true,
                                                    itemCount: 1,
                                                    padding: EdgeInsets.all(0),
                                                    controller: ScrollController(keepScrollOffset: true),
                                                  ),

                                                  SizedBox(height: 35,),
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                    //  alignment: Alignment.bottomLeft,
                                                    children:<Widget>[

                                                      //select receiver from user list
                                                      Column(
                                                        children: <Widget>[
                                                          InkWell(
                                                            onTap: () {
                                                              Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                                            },
                                                            child: Material(
                                                              shadowColor: Colors.grey,
                                                              elevation: 10,
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(20),
                                                              ),
                                                              color: Colors.redAccent,
                                                              child: Container(
                                                                alignment: Alignment.center,
                                                                height: 50,
                                                                width: 150,
                                                                child: Text(
                                                                  'Cancel',
                                                                  style: TextStyle(
                                                                    color: Colors.grey,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                      //select receiver from Contact phone
                                                      Column(
                                                        children: <Widget>[
                                                          InkWell(
                                                            onTap: () async {

                                                              _amountTransaction=snapshot.data.amountuser;
                                                              _numberSender=snapshot.data.phone;
                                                              if(_formKey.currentState.validate()){
                                                                _formKey.currentState.save();
                                                                await UserData.getSurname().then((surname) async {
                                                                  await HomePage.storage.read(key: 'token').then((token) async {
                                                                    await HomePage.storage.read(key: 'phone').then((phoneReceiver) async {
                                                                      await HomePage.storage.read(key: 'id').then((idPerson) async {
                                                                        fetchOperatorByPhone(_numberSender, token).then((operator) async {
                                                                          print(token);
                                                                          print(surname);
                                                                          print(_numberSender);
                                                                          print(_amountTransaction);

                                                                          transactionWEWI(Transaction(_idTransaction, _dateCreationTransaction,
                                                                              _amountTransaction, _numberSender, phoneReceiver, _type, operator), idPerson, token)
                                                                              .then((response) async {
                                                                            print(response.statusCode);
                                                                            print(response.body);
                                                                            Center(child: CircularProgressIndicator(),);
                                                                            if(response.statusCode == 200){
                                                                              await Fluttertoast.showToast(msg: response.body,
                                                                                  toastLength: Toast.LENGTH_LONG,
                                                                                  gravity: ToastGravity.CENTER,
                                                                                  timeInSecForIosWeb: 5,
                                                                                  backgroundColor: Colors.black,
                                                                                  textColor: Colors.yellowAccent,
                                                                                  fontSize: 15.0);
                                                                              Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                                                            }
                                                                            else {
                                                                              print(response.statusCode.toString());
                                                                              await Fluttertoast.showToast(msg: response.body,
                                                                                  toastLength: Toast.LENGTH_LONG,
                                                                                  gravity: ToastGravity.CENTER,
                                                                                  timeInSecForIosWeb: 5,
                                                                                  backgroundColor: Colors.black,
                                                                                  textColor: Colors.yellowAccent,
                                                                                  fontSize: 15.0);
                                                                              Navigator.push(context, MaterialPageRoute(builder: (context) => ConfirmTransWEWI()));
                                                                            }
                                                                          });//}
                                                                        });
                                                                      });
                                                                    });
                                                                  });
                                                                });
                                                              }
                                                              showAlertDialog(context);
                                                            },
                                                            child: Material(
                                                              shadowColor: Colors.grey,
                                                              elevation: 10,
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(20),
                                                              ),
                                                              color: Color(0xff8c52ff),
                                                              child: Container(
                                                                alignment: Alignment.center,
                                                                height: 50,
                                                                width: 150,
                                                                child: Text(
                                                                  'Confirm',
                                                                  style: TextStyle(
                                                                    color: Colors.grey,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );

                                        });
                                  }else if(snapshot.hasError){
                                    print(snapshot.error);
                                  }
                                  return  Center(child: Text('Loading...'));},
                              );
                            }
                            else{
                              return Center(child: CircularProgressIndicator(),);
                            }
                          });
                    }
                    else{
                      return (Center(child: Text('Session expire. Please log in'),));
                    }
                  })

          ),
        ),

      ),

    );


  }
}

