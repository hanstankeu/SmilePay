import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/view/Functions.dart';
import 'package:smilepay/view/user/view/contacts/maine.dart';

import '../profile/completeInformations.dart';
import '../dashboard.dart';
import 'WalletInToWalletIn.dart';
import 'custom_alert_dialog.dart';

class Confirmation extends StatefulWidget {
  String number;
  int amount;
  Confirmation({this.number,this.amount});
  @override
  _ConfirmationState createState() => _ConfirmationState();
}

class _ConfirmationState extends State<Confirmation> {
  final _formKey = GlobalKey<FormState>();

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone number is required'),
    MinLengthValidator(9, errorText: 'Telephone number should be atleast 9 characters'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  static String _password = '';
  bool _showPassword = false;

  String _idTransaction = null;
  DateTime _dateCreationTransaction = null;
  int _amountTransaction ;
  String _numberReceiver ;
  String _type;

  List<DropdownMenuItem> operators = [
    DropdownMenuItem(child: Text('MTN'), value: 'MTN_CMR',),
    DropdownMenuItem(child: Text('ORANGE'), value: 'ORANGE_CMR',),
  ];

  @override
  Widget build(BuildContext context) {

    final mq = MediaQuery.of(context);
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              height: 80,
              decoration: BoxDecoration(color: Colors.grey[300]),

              child: Stack(
                alignment: Alignment.topCenter,
                children: <Widget>[
                  Center(child:Text('Confirm The Transaction', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Colors.black87),textAlign: TextAlign.center,)),
                  Align(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: IconButton(

                        icon: Icon(Icons.arrow_back),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    alignment: Alignment.topLeft,
                  ),

                ],
              ),
            ),

    Expanded(
    child: ListView(shrinkWrap: true, children: <Widget>[

      Column(
        children: <Widget>[

          SizedBox(height: 25,),

          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.account_circle, color: Colors.lightBlue[900],size: 12,),
                      padding: EdgeInsets.all(12),
                    ),

                    SizedBox(width: 2,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("Nom: ", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),
                    SizedBox(width: 10,),

                    /* InkWell(
                                              onTap: () async {

                                                if(_formKey.currentState.validate()){
                                                  _formKey.currentState.save();
                                                  await UserData.getNomPrenom().then((noms) async {
                                                    await HomePage.storage.read(key: 'token').then((snapshot) async {
                                                      await HomePage.storage.read(key: 'phone').then((phoneSender) async {

                                                        Column(
                                                          crossAxisAlignment: CrossAxisAlignment.end,
                                                          children: <Widget>[
                                                            Text('${noms}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                          ],
                                                        );
                                                      });

                                                    });
                                                  });
                                                }
                                              },
                                            )*/
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: false),
          ),

          SizedBox(height: 1,),

          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.person, color: Colors.lightBlue[900],size: 12,),
                      padding: EdgeInsets.all(8),
                    ),

                    SizedBox(width: 2,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("Number receiver: ", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),

                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text('${_numberReceiver}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                      ],
                    ),
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: true),
          ),

          SizedBox(height: 1,),

          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.person_outline, color: Colors.lightBlue[900],size: 12,),
                      padding: EdgeInsets.all(12),
                    ),

                    SizedBox(width: 2,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("Number Sender: ", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),
                    SizedBox(width: 10,),

                    /*  InkWell(
                                              onTap: () async {

                                                if(_formKey.currentState.validate()){
                                                  _formKey.currentState.save();
                                                  await UserData.getNomPrenom().then((noms) async {
                                                    await HomePage.storage.read(key: 'token').then((snapshot) async {
                                                      await HomePage.storage.read(key: 'phone').then((phoneSender) async {

                                                        Column(
                                                          crossAxisAlignment: CrossAxisAlignment.end,
                                                          children: <Widget>[
                                                            Text('${phoneSender}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                                                          ],
                                                        );
                                                      });

                                                    });
                                                  });
                                                }
                                              },
                                            )*/
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: true),
          ),

          SizedBox(height: 1,),

          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.attach_money, color: Colors.lightBlue[900],size: 12,),
                      padding: EdgeInsets.all(12),
                    ),

                    SizedBox(width: 2,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("Amount: ", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),

                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text('${_amountTransaction}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.lightGreen),),
                      ],
                    ),
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: true),
          ),

          //now expense
          SizedBox(height: 1,),
//Rate
          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.yellow,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.account_balance_wallet, color: Colors.lightBlue[900],size: 12,),
                      padding: EdgeInsets.all(12),
                    ),

                    SizedBox(width: 2,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("Rate:", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),

                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text('${_numberReceiver}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.orange),),
                      ],
                    ),
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: true),
          ),

          //now expense
          SizedBox(height: 1,),

          ListView.builder(
            itemBuilder: (context, index){
              return Container(
                margin: EdgeInsets.symmetric(horizontal: 32),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: Colors.black12,
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.all(Radius.circular(18))
                      ),
                      child: Icon(Icons.attach_money, color: Colors.lightBlue[900],size: 18,),
                      padding: EdgeInsets.all(12),
                    ),

                    SizedBox(width: 2,),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text("TOTAL", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.grey[900]),),
                        ],
                      ),
                    ),

                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text('${_numberReceiver}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.orange),),
                      ],
                    ),
                  ],
                ),
              );
            },
            shrinkWrap: true,
            itemCount: 1,
            padding: EdgeInsets.all(0),
            controller: ScrollController(keepScrollOffset: true),
          ),

          //now expense

          SizedBox(height: 25,),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //  alignment: Alignment.bottomLeft,
            children:<Widget>[

              //select receiver from user list
              Column(
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                    },
                    child: Material(
                      shadowColor: Colors.grey,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      color: Colors.redAccent,
                      child: Container(
                        alignment: Alignment.center,
                        height: 40,
                        width: 150,
                        child: Text(
                          'Cancel',
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              //select receiver from Contact phone
              Column(
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      //Navigator.push(context, MaterialPageRoute(builder: (context) => Contactes()));
                    },
                    child: Material(
                      shadowColor: Colors.grey,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      color: Color(0xff8c52ff),
                      child: Container(
                        alignment: Alignment.center,
                        height: 40,
                        width: 150,
                        child: Text(
                          'Confirm',
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],

        ),

    ]),)


          ],
        ),
      ),
    );


  }
}

