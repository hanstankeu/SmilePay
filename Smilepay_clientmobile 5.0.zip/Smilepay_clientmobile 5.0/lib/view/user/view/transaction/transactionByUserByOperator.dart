import 'package:flutter/material.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserByOperatorServices.dart';
import 'package:smilepay/view/user/components/footer.dart';
import 'package:smilepay/view/user/components/myappbar.dart';
import 'package:smilepay/view/user/view/dashboard.dart';

class TransactionByUserByOperator extends StatefulWidget {
  String idPersonne;
  String code;
  String token;

  TransactionByUserByOperator(this.idPersonne, this.code, this.token);

  @override
  _TransactionByUserByOperatorState createState() => _TransactionByUserByOperatorState();
}

class _TransactionByUserByOperatorState extends State<TransactionByUserByOperator> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(),
      backgroundColor: Colors.yellow[100],
      body: Container(
          padding: EdgeInsets.all(10),
          child:  FutureBuilder<List<Transaction>>(
            future: fetchalltransactionsbyuserbyoperator(widget.idPersonne, widget.code, widget.token),
            builder: (context, snapshot){
              if (snapshot.hasData){
                return ListView.builder(
                    itemCount: snapshot.data.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Card(
                        elevation: 10,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('Amount : ' +
                                  snapshot.data[index].amount.toString(),
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),

                              ),
                              SizedBox(height: 5,),
                              /*Text('Sender : ' +
                                  snapshot.data[index].numberSender.toString(),
                                style: TextStyle(fontSize: 12),
                              ),*/
                              Text('Receiver : ' +
                                  snapshot.data[index].numberReceiver.toString(),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Type : ' +
                                  snapshot.data[index].type.toString(),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Date : ' +
                                  snapshot.data[index].dateCreation.toString().substring(0,10),
                                style: TextStyle(fontSize: 12),
                              ),
                              Text('Time : ' +
                                  snapshot.data[index].dateCreation.toString().substring(10,19),
                                style: TextStyle(fontSize: 12),
                              )
                            ],
                          ),
                        ),
                      );

                    });
              }else if(snapshot.hasError){
                print(snapshot.error);
              }
              return  Center(child: Text('No data'));},
          )
      ),
      persistentFooterButtons: <Widget>[
        Footer()
      ],
    );
  }
}