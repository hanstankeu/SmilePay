import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/JWTResponse.dart';
import 'package:smilepay/model/Transaction.dart';
import 'package:smilepay/model/Validercode.dart';
import 'package:smilepay/services/authentication/AuthenticationServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/view/Functions.dart';
import 'package:smilepay/view/user/view/contacts/maine.dart';

import '../profile/completeInformations.dart';
import '../dashboard.dart';
import 'ConfirmTransWEWE.dart';
import 'Confirmation.dart';
import 'WalletInToWalletIn.dart';
import 'confirmTrans.dart';
import 'custom_alert_dialog.dart';

class CodeSecretWEWE extends StatefulWidget {
  String number;
  int amount;
  CodeSecretWEWE({this.number, this.amount});
  @override
  _CodeSecretState createState() => _CodeSecretState();
}

class _CodeSecretState extends State<CodeSecretWEWE> {
  final _formKey = GlobalKey<FormState>();

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone number is required'),
    MinLengthValidator(9, errorText: 'Telephone number should be atleast 9 characters'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  static String _username = '';
  static String _codeSecret = '';
  bool _showPassword = false;


  List<DropdownMenuItem> operators = [
    DropdownMenuItem(child: Text('MTN'), value: 'MTN_CMR',),
    DropdownMenuItem(child: Text('ORANGE'), value: 'ORANGE_CMR',),
  ];

  @override
  Widget build(BuildContext context) {


/*   final mq = MediaQuery.of(context);

    void showAlertDialog(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width * 2,
                height: MediaQuery.of(context).size.height / 1,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Text("Confirm Your Transfert"),
                    SizedBox(height: 26,),



                  ],
                ),
              ),
            );
          });
    }*/


    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Enter Your Secret Code', style: TextStyle(color: Colors.yellow),textAlign: TextAlign.center,),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          border: Border(),
          borderRadius: BorderRadius.circular(30),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: Colors.yellow.withOpacity(0.2),
              blurRadius: 0.0,
              spreadRadius: 0.0,
              offset: Offset(0, 6.0),
            ),
          ],
        ),
        child: Center(
          child: Form(
            key: _formKey,
            child: ListView(
              children: <Widget>[
                SizedBox(height: 30,),
                Text('From External Transfert to External Transfert', style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 50,),


                //CodeSecret
                Padding(
                  padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                  child: Material(
                    borderRadius: BorderRadius.circular(25.0),
                    color: Colors.yellow,
                    elevation: 0.0,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 12.0),
                      child: TextFormField(
                        cursorColor: Colors.black,
                        onChanged: (value){
                          setState(() {
                            _codeSecret = value;
                          });
                        },
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          labelText: 'CodeSecret',
                          icon: Icon(Icons.lock_outline, color: Colors.black,),
                          suffixIcon: GestureDetector(
                            onTap: (){
                              setState(() {
                                _showPassword = !_showPassword;
                              });
                            },
                            child: Icon(
                              _showPassword ? Icons.visibility : Icons.visibility_off,
                            ),
                          ),
                        ),
                        obscureText: !_showPassword,
                        validator: formfieldValidator,
                      ),
                    ),
                  ),
                ),



                Padding(
                  padding:
                  const EdgeInsets.fromLTRB(100.0, 15.0, 100.0, 0),
                  child: Material(
                      borderRadius: BorderRadius.circular(20.0),
                      color: Colors.yellow,
                      elevation: 0.0,
                      child: MaterialButton(
                        onPressed: () async {
                          //showAlertDialog(context); ConfirmTrans()
                          //  Navigator.push(context, MaterialPageRoute(builder: (context) => Confirmation()));

                          if(_formKey.currentState.validate()){
                            _formKey.currentState.save();
                            await UserData.getNomPrenom().then((noms) async {
                              await HomePage.storage.read(key: 'token').then((token) async {
                                await HomePage.storage.read(key: 'username').then((username) async {
                                  print(noms);
                                  print(token);
                                  print(username);
                                  print(_codeSecret);

                                  validercodeUser(Validercode(username, _codeSecret)).then((response) async{
                                    print(response.statusCode);
                                    if(response.statusCode == 200){
                                      JWTResponse jwtResponse = JWTResponse.convertfromJson(json.decode(response.body));
                                      await Navigator.push(context, MaterialPageRoute(builder: (context) => ConfirmTransWEWE()));

                                    } else{
                                      print("Username or Password is incorrect");
                                      print(response.statusCode.toString());
                                      await Fluttertoast.showToast(msg: response.body,
                                          toastLength: Toast.LENGTH_LONG,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 3,
                                          backgroundColor: Colors.black,
                                          textColor: Colors.yellowAccent,
                                          fontSize: 15.0
                                      );

                                    }
                                  });
                                }); }); });

                          }
                        },
                        minWidth: MediaQuery.of(context).size.width,
                        child: Text(
                          "Valid",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0),
                        ),
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );


  }
}
