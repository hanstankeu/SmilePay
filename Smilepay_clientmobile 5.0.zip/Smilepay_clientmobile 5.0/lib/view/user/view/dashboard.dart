import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:smilepay/services/transaction/user/TransactionByUserTypeServices.dart';
import 'package:smilepay/services/transaction/user/TransactioncreateServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/user/components/footer.dart';
import 'package:smilepay/view/user/components/lowerblocks.dart';
import 'package:smilepay/view/user/components/myappbar.dart';
import 'package:smilepay/view/user/components/mydrawer.dart';
import 'package:smilepay/view/user/components/upperblock.dart';

class HomePage extends StatefulWidget {
  static var storage = FlutterSecureStorage();
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var noms = UserData.getNomPrenom();
  var username = UserData.getUsername();
  var email = UserData.getEmail();
  var token = UserData.getToken();
  var balance = UserData.getBalance();

  refreshPage(){
    setState(() {
      noms = UserData.getNomPrenom();
      username = UserData.getUsername();
      email = UserData.getEmail();
      token = UserData.getToken();
      balance = UserData.getBalance();
    });
  }

  @override
  Widget build(BuildContext context) {
    Future<bool> _onWillPop() async {
      return (await showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          title: new Text('Are you sure?'),
          content: new Text('Do you want to exit SmilePay ?'),
          actions: <Widget>[
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: new Text('No'),
            ),
            new FlatButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: new Text('Yes'),
            ),
          ],
        ),
      )) ?? false;
    }
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: Colors.yellow[100],
        appBar: MyAppBar(),
        drawer: MyDrawer(),
        body: Container(
          margin: EdgeInsets.symmetric(vertical: 0, horizontal: 20),
          child: ListView(
            children: <Widget>[
              SizedBox(height: 20,),
              UpperBlock(),
              SizedBox(height: 20,),
              LowerBlocks(),
/*              Container(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                        child: Text('Transactions', style: TextStyle(fontWeight: FontWeight.bold),)
                    ),
                    Container(
                      child: GestureDetector(
                          child: Text('Voir plus', style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.yellow[800])), onTap: () {}
                      ),
                    ),
                  ],
                ),
              ),*/
            ],
          ),
        ),
        persistentFooterButtons: <Widget>[
          Footer()
        ],
      ),
    );
  }
}