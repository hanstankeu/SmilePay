import 'dart:io' as Io;
import 'package:flutter/rendering.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_password_strength/flutter_password_strength.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/services/authentication/ModifyPasswordServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/user/components/myappbar.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:form_field_validator/form_field_validator.dart';
import '../dashboard.dart';

class ModifyPassword extends StatefulWidget {
  @override
  _ModifyPasswordState createState() => _ModifyPasswordState();
}

class _ModifyPasswordState extends State<ModifyPassword> {

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);
  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password is required'),
    MinLengthValidator(8, errorText: 'Password should contain atleast 8 characters'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])', errorText: 'passwords must have at least one special character')
  ]);

  final _formKey = GlobalKey<FormState>();
  // params
  String _password = '';

  var temp;
  bool _showPassword = false;
  bool _showPassword1 = false;
  String _confirmpassword;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.yellow[100],
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Update password', style: TextStyle(color: Colors.yellow),),
          centerTitle: true,
        ),
        body: Container(
          child: Center(
            child: Form(
                key: _formKey,
                child: ListView(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    //password
                     Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _password = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Password',
                              icon: Icon(Icons.lock_outline, color: Colors.black,),
                              suffixIcon: GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _showPassword = !_showPassword;
                                  });
                                },
                                child: Icon(
                                  _showPassword ? Icons.visibility : Icons.visibility_off,
                                ),
                              ),
                            ),
                            obscureText: !_showPassword,
                            validator: passwordValidator
                          ),
                        ),
                      ),
                    ),
                    /**
                     * password strength
                     */
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
                      child: FlutterPasswordStrength(
                          password: _password,
                          strengthCallback: (strength){
                            debugPrint(strength.toString());
                          }
                      ),
                    ),
                    //confirm password
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _confirmpassword = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Confirm password',
                              icon: Icon(Icons.lock_outline, color: Colors.black,),
                              suffixIcon: GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _showPassword1 = !_showPassword1;
                                  });
                                },
                                child: Icon(
                                  _showPassword1 ? Icons.visibility : Icons.visibility_off,
                                ),
                              ),
                            ),
                            obscureText: !_showPassword1,
                            validator: passwordValidator,
                          ),
                        ),
                      ),
                    ),
                    //sign up
                    Padding(
                      padding:
                      const EdgeInsets.fromLTRB(50.0, 30.0, 50.0, 8.0),
                      child: Material(
                          borderRadius: BorderRadius.circular(20.0),
                          color: Colors.yellow,
                          elevation: 0.0,
                          child: MaterialButton(
                            onPressed: () async {
                              if(_formKey.currentState.validate()){
                                _formKey.currentState.save();
                                if(_password != _confirmpassword){
                                  await Fluttertoast.showToast(msg: "Password and confirmation do not match",
                                      toastLength: Toast.LENGTH_LONG,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 3,
                                      backgroundColor: Colors.black,
                                      textColor: Colors.yellowAccent,
                                      fontSize: 15.0);
                                }else{
                                  await HomePage.storage.read(key: "token").then((token){
                                    UserData.getId().then((idPerson){
                                      modifypassword(idPerson, _password, token).then((response) async {
                                        if(response.statusCode == 200){
                                          print(response.statusCode);
                                          await Fluttertoast.showToast(msg: "Password modified ! ",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 5,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                        else if(response.statusCode == 401){
                                          print(response.statusCode.toString());
                                        }
                                        else if(response.statusCode == 500){
                                          print(response.statusCode.toString());
                                          await Fluttertoast.showToast(msg: "Server unstable",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 3,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                      });
                                    });
                                  });
                                }

                              }


                            },
                            minWidth: MediaQuery.of(context).size.width,
                            child: Text(
                              "Update",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20.0),
                            ),
                          )
                      ),
                    ),
                    //sign in
                  ],
                )
            ),
          ),
        )
    );
  }
}