import 'dart:convert';
import 'dart:io' as Io;
import 'dart:io';
import 'package:flutter/rendering.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/UserCard.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/authentication/CompletionServices.dart';
import 'package:smilepay/model/NationalCard.dart';
import 'package:gender_picker/source/gender_picker.dart';
import 'package:gender_picker/source/enums.dart';
import 'package:smilepay/view/user/components/myappbar.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:image_picker/image_picker.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/view/user/view/profile/updateprofile.dart';
import '../dashboard.dart';

class BottomPicker extends StatelessWidget {
  const BottomPicker({
    Key key,
    @required this.child,
  }): assert(child != null),
        super(key: key);

  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 216,
      padding: const EdgeInsets.only(top: 6),
      color: Color(0xFFFFFDEF),
      child: DefaultTextStyle(
          style: TextStyle(
            color: CupertinoColors.label.resolveFrom(context),
            fontSize: 22,
          ),
          child: GestureDetector(
            onTap: (){},
            child: SafeArea(
              top: false,
              child: child,
            ),
          )
      ),
    );
  }
}
//date picker menu
class Menu extends StatelessWidget {
  const Menu({
    Key key,
    @required this.children,
  }) : assert(children != null),
        super(key : key);

  final List<Widget> children;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: const Border(
          top: BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
          bottom: BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
      ),
      height: 44,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: children,
      ),
    );
  }
}

class CompleteInfos extends StatefulWidget {
  @override
  _CompleteInfosState createState() => _CompleteInfosState();
}

class _CompleteInfosState extends State<CompleteInfos> {

  DateTime date = DateTime.now();
  final _picker = ImagePicker();
  File image;

  dynamic _pickImageError;
  //attachment gallery open
  Future openGalley(BuildContext context) async {
    try{
      var picture = await _picker.getImage(source: ImageSource.gallery);
      setState(() {
        image = File(picture.path);
        image.readAsBytes().then((bytes){
          _attachment = Base64Encoder().convert(bytes);});

      });
    }catch (e) {
      setState(() {
        _pickImageError = e;
        print(e);
      });
    }
    Navigator.of(context).pop;
  }
  //attachment camera open
  Future openCamera(BuildContext context) async {
    var picture = await _picker.getImage(source: ImageSource.camera);
    setState((){
      image = File(picture.path);
      image.readAsBytes().then((bytes){
        _attachment = Base64Encoder().convert(bytes);});

    });
    Navigator.of(context).pop;
  }

  //image picker dialog box
  Future<void> showChoiceDialog(BuildContext context){
    return showDialog(context: context, builder: (BuildContext context){
      return CupertinoAlertDialog(
        title: Text('Make a choice'),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Padding(padding: EdgeInsets.all(8)),
              GestureDetector(
                child: Text('Gallery'),
                onTap: (){
                  openGalley(context);
                },
              ),
              Padding(padding: EdgeInsets.all(6)),
              GestureDetector(
                child: Text('Camera'),
                onTap: (){
                  openCamera(context);
                },
              )
            ],
          ),
        ),
      );
    });
  }

  List<DropdownMenuItem> types = [
    DropdownMenuItem(child: Text('Moral'), value: 'MORAL_PERSON',),
    DropdownMenuItem(child: Text('Physical'), value: 'PHYSICAL_PERSON',),
  ];

  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password is required'),
    MinLengthValidator(8, errorText: 'Password should contain atleast 8 characters'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])', errorText: 'passwords must have at least one special character')
  ]);

  final emailValidator = MultiValidator([
    RequiredValidator(errorText: 'Email is required'),
    EmailValidator(errorText: 'Enter a valid email')
  ]);

  final telephoneValidator = MultiValidator([
    RequiredValidator(errorText: 'Telephone number is required'),
    MinLengthValidator(9, errorText: 'Telephone number should be atleast 9 characters'),
  ]);

  final formfieldValidator = MultiValidator([
    RequiredValidator(errorText: 'This field is required'),
  ]);

  final _formKey = GlobalKey<FormState>();
  //UserCard params
  String _name = '';
  String _surname = '';
  String _username = '';
  String _password = '';
  String _codeSecret ='';
  String _email = '';
  String _phone = '';
  String _address = '';
  DateTime _birthday;
  String _sexe = null;
  String _type = null;
  String _id = '';
  DateTime _dateCreation;
  bool  _state;
  bool _status;
  String _role = '';
  int _amountuser;
  String _receiveuser;

  var temp;
  bool _showPassword = false;
  String _confirmpassword;

  //National Card params
  static String _idCard = null;
  static String _number = '';
  static DateTime _dateOfIssue;
  static DateTime _dateOfExpiration;
  static String _attachment;
  static DateTime _dateCreationCNI;
  static DateTime _dateModificationCNI;

  //UserAccount params
  static String _idUserAccount ;
  static String _nameUserAccount;
  static String _surnameUserAccount;
  static String _usernameUserAccount;
  static String _passwordUserAccount;
  static String _codeSecretUserAccount;
  static String _emailUserAccount;
  static String _phoneUserAccount;
  static String _sexeUserAccount = null;
  static String _addressUserAccount;
  static String _typeUserAccount = null;
  static DateTime _birthdayUserAccount;
  static DateTime _dateCreationUserAccount;
  static bool _stateUserAccount;
  static bool _statusUserAccount;
  static String _roleUserAccount;
  static int _amountuserUserAccount;
  static String _receiveuserUserAccount;

  @override
  Widget build(BuildContext context) {
    //if(UserData.getNomPrenom() == null){
      return Scaffold(
          backgroundColor: Colors.yellow[100],
          appBar: AppBar(
            backgroundColor: Colors.black,
            title: Text('Complete profile', style: TextStyle(color: Colors.yellow),),
            centerTitle: true,
          ),
          body: Container(
            child: Center(
              child: Form(
                  key: _formKey,
                  child: ListView(
                    children: <Widget>[
                      //title
                      Text('Complete registration', textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 20),),
                      SizedBox(height: 20,),
                      //name
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(25.0),
                          color: Colors.yellow.withOpacity(0.4),
                          elevation: 0.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: TextFormField(
                              cursorColor: Colors.black,
                              onChanged: (value){
                                _name = value;
                              },
                              decoration: InputDecoration(
                                  labelText: 'Name',
                                  border: InputBorder.none,
                                  icon: Icon(Icons.account_circle,color: Colors.black,)
                              ),
                              validator: formfieldValidator,
                            ),
                          ),
                        ),
                      ),
                      //surname
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(25.0),
                          color: Colors.yellow.withOpacity(0.4),
                          elevation: 0.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: TextFormField(
                              cursorColor: Colors.black,
                              onChanged: (value){
                                _surname = value;
                              },
                              decoration: InputDecoration(
                                labelText: 'Surname',
                                border: InputBorder.none,
                                icon: Icon(Icons.account_circle, color: Colors.black,),
                              ),
                              validator: formfieldValidator,
                            ),
                          ),
                        ),
                      ),
                      //username
                      /*Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _username = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Username',
                              icon: Icon(Icons.perm_identity, color: Colors.black,),
                            ),
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Please enter a username';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ),*/
                      //password
                      /* Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _password = value;
                            },
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              labelText: 'Password',
                              icon: Icon(Icons.lock_outline, color: Colors.black,),
                              suffixIcon: GestureDetector(
                                onTap: (){
                                  setState(() {
                                    _showPassword = !_showPassword;
                                  });
                                },
                                child: Icon(
                                  _showPassword ? Icons.visibility : Icons.visibility_off,
                                ),
                              ),
                            ),
                            obscureText: !_showPassword,
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Please make sure your password is valid';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ),*/
                      //email
                      /* Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(40.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _email = value;
                            },
                            decoration: InputDecoration(
                              border:InputBorder.none,
                              icon: Icon(Icons.alternate_email, color: Colors.black,),
                              labelText: "Email",
                              fillColor: Colors.black,
                            ),
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Please make sure your email address is valid';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ),*/
                      //tel
                      /*Padding(
                      padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(25.0),
                        color: Colors.yellow.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12.0),
                          child: TextFormField(
                            cursorColor: Colors.black,
                            onChanged: (value){
                              _phone = value;
                            },
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                labelText: "Telephone  number", fillColor: Colors.black,
                                icon: Icon(Icons.phone, color: Colors.black,)

                            ),
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Please make sure your email address is valid';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ),*/
                      //date of birth
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(25.0),
                          color: Colors.yellow.withOpacity(0.4),
                          elevation: 0.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: Row(
                              children: <Widget>[
                                IconButton(
                                  highlightColor: Colors.blue,
                                  icon: Icon(Icons.calendar_today),
                                  onPressed: () {
                                    showCupertinoModalPopup<void>(
                                      context: context,
                                      builder: (context){
                                        return BottomPicker(
                                          child: CupertinoDatePicker(
                                            backgroundColor: Color(0xFFFFFDEF),
                                            mode: CupertinoDatePickerMode.date,
                                            initialDateTime: _birthday,
                                            onDateTimeChanged: (newDateTime){
                                              setState(() {
                                                return _birthday = newDateTime;
                                              });
                                            },
                                          ),
                                        );
                                      },
                                    );
                                  },
                                ),
                                Expanded(
                                  child: FlatButton(
                                    onPressed: (){
                                      showCupertinoModalPopup<void>(
                                        context: context,
                                        builder: (context){
                                          return BottomPicker(
                                            child: CupertinoDatePicker(
                                              backgroundColor: Color(0xFFFFFDEF),
                                              mode: CupertinoDatePickerMode.date,
                                              initialDateTime: _birthday,
                                              onDateTimeChanged: (newDateTime){
                                                setState(() {
                                                  return _birthday = newDateTime;
                                                });},
                                            ),
                                          );
                                        },
                                      );
                                    },
                                    child: Menu(children: [
                                      Text( _birthday == null? 'Birthday' : 'Birthday : ' + _birthday.toString().substring(0, 10),
                                        style: TextStyle(
                                          color: CupertinoColors.black,
                                        ),)
                                    ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      //address
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(25.0),
                          color: Colors.yellow.withOpacity(0.4),
                          elevation: 0.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: TextFormField(
                              cursorColor: Colors.black,
                              onChanged: (value){
                                _address = value;
                              },
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                icon: Icon(Icons.home, color: Colors.black,),
                                labelText: "Address", fillColor: Colors.black,

                              ),
                              validator: formfieldValidator,
                            ),
                          ),
                        ),
                      ),
                      //sex
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(25.0),
                          color: Colors.yellow.withOpacity(0.4),
                          elevation: 0.0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 0.0),
                            child: GenderPickerWithImage(
                              selectedGender: Gender.Male,
                              selectedGenderTextStyle: TextStyle(
                                  color: Colors.black, fontWeight: FontWeight.bold),
                              unSelectedGenderTextStyle: TextStyle(
                                  color: Colors.grey, fontWeight: FontWeight.normal),
                              size: 40,
                              onChanged: (Gender gender){
                                if(gender == Gender.Male){
                                  _sexe = 'MALE';
                                }
                                else{
                                  _sexe = 'FEMALE';
                                }
                              },
                            ),
                          ),
                        ),
                      ),
                      //type
                      Padding(
                          padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                          child: Material(
                            borderRadius: BorderRadius.circular(30.0),
                            color: Colors.yellow.withOpacity(0.4),
                            elevation: 0.0,
                            child: Row(
                              children: <Widget>[
                                SizedBox(width: 20,),
                                Icon(Icons.accessibility),
                                SizedBox(width: 10,),
                                Expanded(
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton(
                                      //value: _type,
                                      items: types,
                                      hint: Text( _type == null ? 'Choose a type' : _type ),
                                      onChanged: (lol) {
                                        setState(() {
                                          _type = lol;
                                        });
                                      },
                                      //value: _type,
                                      icon: Icon(Icons.arrow_drop_down),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                      ),

                      //cni informations
                      Container(
                        margin: EdgeInsets.only(top: 10),
                        decoration: BoxDecoration(
                          border: Border(),
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.yellow.withOpacity(0.2),
                              blurRadius: 0.0,
                              spreadRadius: 0.0,
                              offset: Offset(0, 6.0),
                            ),
                          ],
                        ),
                        child: Column(
                          children: <Widget>[
                            Divider(thickness: 2, color: Colors.transparent,),
                            Text('National Identity Card informations', style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.italic),
                              textAlign: TextAlign.center,
                            ),
                            //id number
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(25.0),
                                color: Colors.white,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: TextFormField(
                                    cursorColor: Colors.black,
                                    onChanged: (value){
                                      _number = value;
                                    },
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      icon: Icon(Icons.credit_card, color: Colors.black,),
                                      labelText: "National ID number", fillColor: Colors.black,
                                    ),
                                    validator: formfieldValidator,
                                  ),
                                ),
                              ),
                            ),
                            //date of issue
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(30.0),
                                color: Colors.white,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: Row(
                                    children: <Widget>[
                                      IconButton(
                                        highlightColor: Colors.blue,
                                        icon: Icon(Icons.calendar_today),
                                        onPressed: () {
                                          showCupertinoModalPopup<void>(
                                            context: context,
                                            builder: (context){
                                              return BottomPicker(
                                                child: CupertinoDatePicker(
                                                  backgroundColor: Color(0xFFFFFDEF),
                                                  mode: CupertinoDatePickerMode.date,
                                                  initialDateTime: _dateOfIssue,
                                                  onDateTimeChanged: (newDateTime){
                                                    setState(() {
                                                      return _dateOfIssue = newDateTime;
                                                    });
                                                  },
                                                ),
                                              );
                                            },
                                          );
                                        },),
                                      Expanded(
                                        child: FlatButton(
                                          onPressed: (){
                                            showCupertinoModalPopup<void>(
                                              context: context,
                                              builder: (context){
                                                return BottomPicker(
                                                  child: CupertinoDatePicker(
                                                    backgroundColor: Color(0xFFFFFDEF),
                                                    mode: CupertinoDatePickerMode.date,
                                                    initialDateTime: _dateOfIssue,
                                                    onDateTimeChanged: (newDateTime){
                                                      setState(() {
                                                        return _dateOfIssue = newDateTime;
                                                      });
                                                    },
                                                  ),
                                                );
                                              },
                                            );
                                          },
                                          child: Menu(children: [
                                            Text( _dateOfIssue == null? 'Issue date' : 'Issue date : ' + _dateOfIssue.toString().substring(0, 10),
                                              style: TextStyle(
                                                color: CupertinoColors.black,
                                              ),)
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            //date of expiration
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(30.0),
                                color: Colors.white,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: Row(
                                    children: <Widget>[
                                      IconButton(
                                        highlightColor: Colors.blue,
                                        icon: Icon(Icons.calendar_today),
                                        onPressed: () {
                                          showCupertinoModalPopup<void>(
                                            context: context,
                                            builder: (context){
                                              return BottomPicker(
                                                child: CupertinoDatePicker(
                                                  backgroundColor: Color(0xFFFFFDEF),
                                                  mode: CupertinoDatePickerMode.date,
                                                  initialDateTime: _dateOfExpiration,
                                                  onDateTimeChanged: (newDateTime){
                                                    setState(() {
                                                      return _dateOfExpiration = newDateTime;
                                                    });
                                                  },
                                                ),
                                              );
                                            },
                                          );
                                        },),
                                      Expanded(
                                        child: FlatButton(
                                          onPressed: (){
                                            showCupertinoModalPopup<void>(
                                              context: context,
                                              builder: (context){
                                                return BottomPicker(
                                                  child: CupertinoDatePicker(
                                                    backgroundColor:Color(0xFFFFFDEF),
                                                    mode: CupertinoDatePickerMode.date,
                                                    initialDateTime: _dateOfExpiration,
                                                    onDateTimeChanged: (newDateTime){
                                                      setState(() {
                                                        return _dateOfExpiration = newDateTime;
                                                      });
                                                    },
                                                  ),
                                                );
                                              },
                                            );
                                          },
                                          child: Menu(children: [
                                            Text( _dateOfExpiration == null? 'Expiration date' : 'Expiration date : ' + _dateOfExpiration.toString().substring(0, 10),
                                              style: TextStyle(
                                                color: CupertinoColors.black,
                                              ),)
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            //attachment
                            Padding(
                              padding: const EdgeInsets.fromLTRB(14.0, 20.0, 14.0, 8.0),
                              child: Material(
                                borderRadius: BorderRadius.circular(25.0),
                                color: Colors.white,
                                elevation: 0.0,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: Row(
                                    children: <Widget>[
                                      IconButton(
                                        icon: Icon(Icons.attach_file),
                                        onPressed: (){
                                          showChoiceDialog(context);
                                        },
                                      ),
                                      Expanded(
                                        child: FlatButton(
                                            onPressed: (){
                                              showChoiceDialog(context);
                                            },
                                            child: Text(_attachment == null? 'Choose a file' : 'Image selected')
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        child: FutureBuilder(
                            builder: (context, snapshot){
                              if(_attachment != null){
                                return Image.memory(
                                  Base64Decoder().convert(_attachment),
                                  height: 300,
                                  width:
                                  300,
                                );
                              }
                              else{
                                return Center(child: CircularProgressIndicator(),);
                              }
                            }
                        ),
                      ),
                      //sign up
                      Padding(
                        padding:
                        const EdgeInsets.fromLTRB(50.0, 30.0, 50.0, 8.0),
                        child: Material(
                            borderRadius: BorderRadius.circular(20.0),
                            color: Colors.yellow,
                            elevation: 0.0,
                            child: MaterialButton(
                              onPressed: () async {
                                if(_formKey.currentState.validate()){
                                  _formKey.currentState.save();
                                  await HomePage.storage.read(key: "token").then((snapshot){
                                    UserData.getId().then((value){
                                      _idUserAccount = value;
                                      UserAccount _userAccount = UserAccount(_idUserAccount,
                                          _nameUserAccount, _surnameUserAccount, _usernameUserAccount,
                                          _passwordUserAccount, _codeSecretUserAccount, _emailUserAccount, _phoneUserAccount,
                                          _sexeUserAccount, _addressUserAccount, _typeUserAccount,
                                          _birthdayUserAccount, _dateCreationUserAccount, _stateUserAccount,
                                          _statusUserAccount, _roleUserAccount, _amountuserUserAccount, _receiveuserUserAccount);
                                      NationalCard _nationalCard = NationalCard(
                                          _idCard, _number, _dateOfIssue,
                                          _dateOfExpiration, _attachment,
                                          _dateCreationCNI, _dateModificationCNI, _userAccount);
                                      complete(UserCard(_name, _surname, _username, _password, _codeSecret,
                                          _email, _phone, _sexe, _address, _type,
                                          _birthday, _nationalCard, _amountuser, _receiveuser),_idUserAccount,snapshot).then((response) async {
                                        if(response.statusCode == 200){
                                          print(response.statusCode);
                                          await Fluttertoast.showToast(msg: "Done!!! ",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 5,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                        else if(response.statusCode == 401){
                                          print(response.statusCode.toString());
                                        }
                                        else if(response.statusCode == 409){
                                          print(response.statusCode.toString());
                                          await Fluttertoast.showToast(msg: "Server unstable",
                                              toastLength: Toast.LENGTH_LONG,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 3,
                                              backgroundColor: Colors.black,
                                              textColor: Colors.yellowAccent,
                                              fontSize: 15.0);
                                        }
                                      });
                                    });
                                  });
                                }


                              },
                              minWidth: MediaQuery.of(context).size.width,
                              child: Text(
                                "Complete Registration",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20.0),
                              ),
                            )
                        ),
                      ),
                      //sign in
                    ],
                  )
              ),
            ),
          )
      );
    //}
    /*else{
      return Scaffold(
        backgroundColor: Colors.yellow[100],
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Complete profile', style: TextStyle(color: Colors.yellow),),
          centerTitle: true,
        ),
        body: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Profile complete." , style: TextStyle(fontWeight: FontWeight.bold),),
                Text("You can update in the 'Update Profile page' !" , style: TextStyle(fontWeight: FontWeight.bold),),
                SizedBox(height: 20,),
                InkWell(

                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => UpdateProfile()));
                  },
                  child: Text('Update your profile here',
                    style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic, fontFamily: 'FontAwesome', fontSize: 20,),),
                ),
              ],
            ),),
        ),
      );
    }*/

  }
}