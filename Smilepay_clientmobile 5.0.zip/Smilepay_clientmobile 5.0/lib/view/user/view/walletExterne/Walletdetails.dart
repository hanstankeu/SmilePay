import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:smilepay/model/Operator.dart';
import 'package:smilepay/model/WalletExterne.dart';
import 'package:smilepay/services/WalletServices.dart';
import 'package:smilepay/services/operator/OperatorfindbycodeServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/view/user/view/walletExterne/Walletlist.dart';


class WalletExterneDetails extends StatefulWidget {
  WalletExterne  walletExterne;
  WalletExterneDetails({this.walletExterne});

  @override
  _WalletExterneDetailsState createState() => _WalletExterneDetailsState();
}

class _WalletExterneDetailsState extends State<WalletExterneDetails> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    //final Map user = ModalRoute.of(context).settings.arguments;

    final formfieldValidator = MultiValidator([
      RequiredValidator(errorText: 'This field is required'),
    ]);

    String _phone;

    //Operator
    String _idOperator;
    String _label;
    String _code;
    DateTime _dateCreation = DateTime.now();
    DateTime _dateModification = DateTime.now();
    String _logo;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Operator details', style: TextStyle(color: Colors.yellow),),
      ),
      body: Container(
        color: Colors.yellow[100],
        padding: EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: ListView(

            children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 10, bottom: 20),
                alignment: Alignment.center,
                child: Text('External wallet details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
              ),

              //phone
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    initialValue: widget.walletExterne.phone,
                    cursorColor: Colors.black,
                    onSaved: (value){
                        if(_phone == null){
                          _phone = widget.walletExterne.phone;
                        }else {
                          _phone = value;
                        }
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: 'Phone number',
                      icon: Icon(Icons.label, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),
              SizedBox(height: 10,),
              //code
              Card(
                elevation: 10,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 8),
                  child: TextFormField(
                    initialValue: widget.walletExterne.operator.code,
                    cursorColor: Colors.black,
                    onChanged: (value){
                        if(_code == null){
                          _code = widget.walletExterne.operator.code;
                        }else {
                          _code = value;
                        }
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      labelText: "Operator's code",
                      icon: Icon(Icons.network_cell, color: Colors.black,),
                    ),
                    validator: formfieldValidator,
                  ),
                ),
              ),
              SizedBox(height: 15,),
              //logo
              Container(
                child: FutureBuilder<String>(
                    future: AdminData.getAdminToken(),
                    builder: (context, token){
                      if(token.hasData){
                        return FutureBuilder<Operator>(
                            future: fetchoperatorbyoperatorcode(widget.walletExterne.operator.code, token.data),
                            builder: (context, snapshot){
                              if(snapshot.hasData){
                                return Image.memory(
                                  Base64Decoder().convert(snapshot.data.logo),
                                );
                              }
                              else{
                                return Center(child: CircularProgressIndicator(),);
                              }
                            }
                        );
                      }
                      else{
                        return Center(child: CircularProgressIndicator(),);
                      }
                    }
                ),
              ),
              SizedBox(height: 15,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  //update
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: () {
                        if(_formKey.currentState.validate()){
                          _formKey.currentState.save();
                          UserData.getToken().then((token) async {
                            print(token);
                            print(widget.walletExterne.idWalletExterne);
                            print(_code);
                            print(widget.walletExterne.phone);
                            updatewalletEXterne(widget.walletExterne.idWalletExterne, widget.walletExterne, token)
                                .then((response){
                              print(response.statusCode);
                              print(response.body);
                              Center(child: CircularProgressIndicator(),);
                              if(response.statusCode == 200){
                                Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                                Navigator.push(context, MaterialPageRoute(builder: (context) => WalletUserlist()));
                                ///await Navigator.pop(context);
                              }
                              else{
                                print(response.statusCode.toString());
                                Fluttertoast.showToast(msg: response.body,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER,
                                    timeInSecForIosWeb: 5,
                                    backgroundColor: Colors.black,
                                    textColor: Colors.yellowAccent,
                                    fontSize: 15.0);
                              }
                            });
                          });
                        }
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.yellow[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Update',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  //delete
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: InkWell(
                      onTap: () {
                        UserData.getToken().then((token) {
                          deletewalletExterne(widget.walletExterne.idWalletExterne, token)
                              .then((response) {
                            print(response.statusCode);
                            print(response.body);
                            Center(child: CircularProgressIndicator(),);
                            if(response.statusCode == 200){
                              Fluttertoast.showToast(msg: response.body,
                                  toastLength: Toast.LENGTH_LONG,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 5,
                                  backgroundColor: Colors.black,
                                  textColor: Colors.yellowAccent,
                                  fontSize: 15.0);
                              Navigator.pop(context);
                            }
                            else {
                              print(response.statusCode.toString());
                              Fluttertoast.showToast(msg: response.body,
                                  toastLength: Toast.LENGTH_LONG,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 5,
                                  backgroundColor: Colors.black,
                                  textColor: Colors.yellowAccent,
                                  fontSize: 15.0);
                              Navigator.push(context, MaterialPageRoute(builder: (context) => WalletExterneDetails()));
                            }
                          });
                        });
                      },
                      child: Material(
                        shadowColor: Colors.grey,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        color: Colors.red[500],
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 80,
                          child: Text(
                            'Delete',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )

            ],
          ),
        ),
      ),
    );
  }
}
