import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';

class AppContact {
  final Color color;
  Contact info;

  AppContact({Key key, this.color, this.info});
}