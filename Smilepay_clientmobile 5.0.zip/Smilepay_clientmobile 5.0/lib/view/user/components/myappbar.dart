import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:smilepay/view/user/view/profile/profile.dart';
import 'package:smilepay/view/user/view/transaction/custom_alert_dialog.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';

import 'Calculator.dart';


class MyAppBar extends StatelessWidget implements PreferredSizeWidget{
  @override
  Widget build(BuildContext context) {

    void showAlertDialogParam(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    Center(child:Text('Change The Language !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage1()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.blue,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'FRENCH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.greenAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'ENGLISH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              ),
            );
          });
    }

    return AppBar(
      elevation: 0.1,
      backgroundColor: Colors.black,
      title:Text('SmilePay',style: TextStyle(color: Colors.yellow),),
      centerTitle: true,
      actions: <Widget>[
        IconButton(icon: Icon(Icons.settings, color: Colors.yellow,), onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => Calcul()));
        }),

        IconButton(icon: Icon(Icons.gradient, color: Colors.yellow,), onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => Calcul()));
        }),

        IconButton(
            icon: Icon(Icons.account_circle, 
              color: Colors.yellow,), 
            onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => Profile()));
            }),
      ],
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(56);
  }
