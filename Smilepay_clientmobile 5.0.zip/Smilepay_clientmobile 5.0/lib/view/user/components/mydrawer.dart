import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/authentication/LogOutServices.dart';
import 'package:smilepay/view/user/view/RateUserlist.dart';
import 'package:smilepay/view/user/view/transaction/TransactionByUserByOperatorPage.dart';
import 'package:smilepay/view/user/view/dashboard.dart';
import 'package:smilepay/view/user/view/authentication/signin.dart';
import 'package:smilepay/view/user/view/transaction/custom_alert_dialog.dart';
import 'package:smilepay/viewFR/user/view/authentication/signin.dart';
import 'package:smilepay/viewFR/user/view/dashboard.dart';

import 'Calculator.dart';

class MyDrawer extends StatefulWidget {
  static var storage = FlutterSecureStorage();
  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  var noms = UserData.getNomPrenom();
  var email = UserData.getEmail();

  @override
  Widget build(BuildContext context) {
    void showAlertDialogAbout(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 10,),
                    Center(child:Text('😊 SMILEPAY 😊 !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.yellow),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Center(child:Text('SmilePay is a Plateforme Safe Money Transfert Platform !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 10,),
                    Center(child:Text('This application was designed by young computer engineer, very skilled', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 20,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.redAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 70,
                            child: Text(
                              'OK',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              ),
            );
          });
    }

    void showAlertDialogParam(BuildContext context) {
      showDialog(
          context: context,
          builder: (BuildContext context) {

            return CustomAlertDialog(
              content: Container(
                width: MediaQuery.of(context).size.width /1,
                height: MediaQuery.of(context).size.height /2.2,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 20,),
                    Center(child:Text('Change The Language !', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.black87),textAlign: TextAlign.center,)),
                    SizedBox(height: 40,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage1()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.blue,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'FRENCH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                        },
                        child: Material(
                          shadowColor: Colors.grey,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: Colors.greenAccent,
                          child: Container(
                            alignment: Alignment.center,
                            height: 40,
                            width: 150,
                            child: Text(
                              'ENGLISH',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              ),
            );
          });
    }

    return Container(
      decoration: BoxDecoration(color: Colors.black),
      child: Drawer(
        child: ListView(
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: FutureBuilder<String>(
                  future: noms,
                  builder: (context, snapshot){
                    if(snapshot.hasData){
                      return Text(snapshot.data, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),);
                    }else{
                      return Text('', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20));
                    }
                  },
              ),
              accountEmail: FutureBuilder<String>(
                future: email,
                builder: (context, snapshot){
                  if(snapshot.hasData){
                    return  Text(snapshot.data, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),);
                  }else{
                    return  Text('', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),);
                  }
                },
              ),
              currentAccountPicture: GestureDetector(
                /**
                 * header
                 */
                child: CircleAvatar(
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.person,color: Colors.white,) ,
                ),
              ),
              decoration: BoxDecoration(
                  color: Colors.yellow
              ),
            ),
            /**
             * body
             */
            Container(
                padding: EdgeInsets.only(left: 20),
                child: Text('Menu', textAlign: TextAlign.justify,)
            ),
            InkWell(
              onTap: (){},
              child: ListTile(
                title: Text('Home'),
                leading: Icon(Icons.home, color: Colors.yellow,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                },
              ),
            ),
            InkWell(
              onTap: () async{
                await UserData.getId().then((idPerson) async {
                  await UserData.getToken().then((token) async {
                    await Navigator.push(context, MaterialPageRoute(builder: (context) => TransactionByUserByOperatorPage()));
                  });
                });
              },
              child: ListTile(
                title: Text('Transactions'),
                leading: Icon(Icons.compare_arrows, color: Colors.yellow,),
              ),
            ),

            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => RateUserlist()));
              },
              child: ListTile(
                title: Text('Rate list'),
                leading: Icon(Icons.account_balance_wallet, color: Colors.yellow,),
              ),
            ),
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => Calcul()));
              },
              child: ListTile(
                title: Text('Calculator'),
                leading: Icon(Icons.gradient, color: Colors.yellow,),
              ),
            ),

            Divider(),

            Container(
                padding: EdgeInsets.only(left: 20),
                child: Text('Others', textAlign: TextAlign.justify,)
            ),

            //Settings
            InkWell(
              onTap: (){
                showAlertDialogParam(context);
              },
              child: ListTile(
                title: Text('Settings'),
                leading: Icon(Icons.settings, color: Colors.yellow,),
              ),
            ),

            //Logout
            InkWell(
              onTap: () async {
                await UserData.getId().then((idPerson) async {
                  await HomePage.storage.read(key: 'token').then((token) async {
                    await logout(idPerson, token).then((response) async {
                      if(response.statusCode == 200){
                        print(response.statusCode);
                        await Fluttertoast.showToast(msg: "Logged out!!! ",
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 5,
                            backgroundColor: Colors.black,
                            textColor: Colors.yellowAccent,
                            fontSize: 15.0);
                        //HomePage.storage.deleteAll();
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LogIn()));
                      }
                      if(response.statusCode == 401){
                        print(response.statusCode.toString());
                        await Fluttertoast.showToast(msg: "Cannot log out",
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 5,
                            backgroundColor: Colors.black,
                            textColor: Colors.yellowAccent,
                            fontSize: 15.0);
                      }
                    });
                  });
                });
              },
              child: ListTile(
                title: Text('Log out'),
                leading: Icon(Icons.exit_to_app, color: Colors.yellow,),
              ),
            ),

            //About us
            InkWell(
              onTap: (){
                showAlertDialogAbout(context);
              },
              child: ListTile(
                title: Text('About us'),
                leading: Icon(Icons.help, color: Colors.yellow,),
              ),
            )
          ],
        ),
      ),
    );
  }
}
