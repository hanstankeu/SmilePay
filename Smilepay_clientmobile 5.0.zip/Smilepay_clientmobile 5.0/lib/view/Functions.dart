import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rounded_modal/rounded_modal.dart';
import 'package:smilepay/model/UserAccount.dart';
import 'package:smilepay/model/WalletExterne.dart';
import 'package:smilepay/services/WalletServices.dart';
import 'package:smilepay/services/user/UserDataService.dart';
import 'package:smilepay/services/user/UserlistServices.dart';
import 'package:smilepay/view/user/view/transaction/WalletExToWalletEX.dart';
import 'package:smilepay/view/user/view/transaction/WalletExToWalletIn.dart';
import 'package:smilepay/view/user/view/transaction/WalletInToWalletEx.dart';
import 'package:smilepay/view/user/view/transaction/WalletInToWalletIn.dart';

class Functions{
  Functions();
  // for WEWE
  void showUserlistWEWE(BuildContext context){
    showRoundedModalBottomSheet(context: context,
        builder: (builder){
          return Scaffold(
            backgroundColor: Colors.yellow[100],
            bottomSheet: Text('Select a contact to make a transaction with it.',
              style: TextStyle(fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
            body: FutureBuilder<String>(
                future: UserData.getToken(),
                builder: (context, token){
                  if(token.hasData){
                    return FutureBuilder<List<UserAccount>>(
                      future: fetchalluser(token.data),
                      builder: (context, snapshot){
                        if (snapshot.hasData){
                          return ListView.builder(
                              itemCount: snapshot.data.length,
                              itemBuilder: (BuildContext context, int index) {
                                return GestureDetector(
                                  onTap: () {
                                    //String number = snapshot.data[index].phone;
                                    Navigator.of(context).push(new MaterialPageRoute(
                                                builder: (context)=> new SendWEWE(number : snapshot.data[index].phone)
                                            ));

                                  },

                                  child: Card(
                                    elevation: 10,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10, horizontal: 8),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            snapshot.data[index].email == null ? '' : snapshot.data[index].email,
                                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                          ),
                                          SizedBox(height: 5,),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                snapshot.data[index].name == null ? '' :'Name : ' +  snapshot.data[index].name + ' ',
                                                style: TextStyle(fontSize: 12),
                                              ),
                                              Text(snapshot.data[index].surname == null ? '' : snapshot.data[index].surname,
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 5,),
                                          Text( snapshot.data[index].phone == null ? '' : 'Phone number : ' +snapshot.data[index].phone + ' ',
                                            style: TextStyle(fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              });
                        }else {
                          return Center(child: Text('No user'),);
                        }
                      },
                    );
                  }
                  else{
                    return Center(child: Text('Session expired. Please log in'));
                  }
                }
            ),
          );
        });
  }

  //for WEWI
  void showUserlistWEWI(BuildContext context){
    showRoundedModalBottomSheet(context: context,
        builder: (builder){
          return Scaffold(
            backgroundColor: Colors.yellow[100],
            bottomSheet: Text('Select a contact to make a transaction with it.',
              style: TextStyle(fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
            body: FutureBuilder<String>(
                future: UserData.getToken(),
                builder: (context, token){
                  if(token.hasData) {
                    return FutureBuilder(
                        future: UserData.getId(),
                        builder: (context, idPerson) {
                          if (idPerson.hasData) {
                            return FutureBuilder<UserAccount>(
                              future: fetchOneuser(idPerson.data, token.data),
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  return ListView.builder(
                                      itemCount: 1,
                                      itemBuilder: (BuildContext context,
                                          int index) {
                                        return GestureDetector(
                                          onTap: () {
                                            //String number = snapshot.data[index].phone;
                                            Navigator.of(context).push(
                                                new MaterialPageRoute(
                                                    builder: (
                                                        context) => new SendWEWI(
                                                        number: snapshot.data.phone)
                                                ));
                                          },

                                          child: Card(
                                            elevation: 10,
                                            child: Padding(
                                              padding: const EdgeInsets
                                                  .symmetric(
                                                  vertical: 10, horizontal: 8),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment
                                                    .start,
                                                children: <Widget>[
                                                  Text(
                                                    snapshot.data
                                                        .email == null
                                                        ? ''
                                                        : snapshot.data
                                                        .email,
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight: FontWeight
                                                            .bold),
                                                  ),
                                                  SizedBox(height: 5,),
                                                  Row(
                                                    children: <Widget>[
                                                      Text(
                                                        snapshot.data
                                                            .name == null
                                                            ? ''
                                                            : 'Name : ' +
                                                            snapshot.data
                                                                .name + ' ',
                                                        style: TextStyle(
                                                            fontSize: 12),
                                                      ),
                                                      Text(snapshot.data
                                                          .surname == null
                                                          ? ''
                                                          : snapshot.data
                                                          .surname,
                                                        style: TextStyle(
                                                            fontSize: 12),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(height: 5,),
                                                  Text(snapshot.data
                                                      .phone == null
                                                      ? ''
                                                      : 'Phone number : ' +
                                                      snapshot.data
                                                          .phone + ' ',
                                                    style: TextStyle(
                                                        fontSize: 12),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      });
                                } else {
                                  return Center(child: Text('No user'),);
                                }
                              },

                            );
                          }
                        }
                    );
                  }
                  else{
                    return Center(child: Text('Session expired. Please log in'));
                  }
                }
            ),

          );
        });
  }

  //for WEWE
  void showUserWallettsWEWE(BuildContext context){
    showRoundedModalBottomSheet(context: context,
        builder: (builder){
          return Scaffold(
            backgroundColor: Colors.yellow[100],
            bottomSheet: Text('Select a contact to make a transaction with it.',
              style: TextStyle(fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
            body: FutureBuilder<String>(
                future: UserData.getToken(),
                builder: (context, token){
                  if(token.hasData){
                    return FutureBuilder(
                        future: UserData.getId(),
                        builder: (context, idPerson){
                          if(idPerson.hasData){
                            return FutureBuilder<List<WalletExterne>>(
                              future: fetchwalletExterne(idPerson.data, token.data),
                              builder: (context, snapshot){
                                if (snapshot.hasData){
                                  return ListView.builder(
                                      itemCount: snapshot.data.length,
                                      itemBuilder: (BuildContext context, int index) {
                                        return GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(new MaterialPageRoute(
                                                builder: (context)=> SendWEWE(wallet : snapshot.data[index].phone)
                                            ));
                                          },
                                          child: Card(
                                            elevation: 10,
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  vertical: 10, horizontal: 8),
                                              child: Column(
                                                children: <Widget>[
                                                  Text(snapshot.data[index].phone == null? 'Phone number : ' : 'Phone number : ' +
                                                      snapshot.data[index].phone,
                                                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                                                  ),
                                                  Text(snapshot.data[index].operator.label == null ? 'Operator : undefined' : 'Operator : ' +
                                                  snapshot.data[index].operator.label),
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      });
                                }else if(snapshot.hasError){
                                  print(snapshot.error);
                                }
                                return  Center(child: CircularProgressIndicator());},
                            );
                          }
                          else{
                            return Center(child: Text('Session expired'),);
                          }
                        }
                    );
                  }
                  else{
                    return Center(child: Text('Session expired. Please log in again'));
                  }
                }
            )
          );
        });
  }

  //for WIWE
  void showUserWallettsWIWE(BuildContext context){
    showRoundedModalBottomSheet(context: context,
        builder: (builder){
          return Scaffold(
              backgroundColor: Colors.yellow[100],
              bottomSheet: Text('Select a contact to make a transaction with it.',
                style: TextStyle(fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
              body: FutureBuilder<String>(
                  future: UserData.getToken(),
                  builder: (context, token){
                    if(token.hasData){
                      return FutureBuilder(
                          future: UserData.getId(),
                          builder: (context, idPerson){
                            if(idPerson.hasData){
                              return FutureBuilder<List<WalletExterne>>(
                                future: fetchwalletExterne(idPerson.data, token.data),
                                builder: (context, snapshot){
                                  if (snapshot.hasData){
                                    return ListView.builder(
                                        itemCount: snapshot.data.length,
                                        itemBuilder: (BuildContext context, int index) {
                                          return GestureDetector(
                                            onTap: () {
                                              Navigator.of(context).push(new MaterialPageRoute(
                                                  builder: (context)=> SendWIWE(wallet : snapshot.data[index].phone)
                                              ));
                                            },
                                            child: Card(
                                              elevation: 10,
                                              child: Padding(
                                                padding: const EdgeInsets.symmetric(
                                                    vertical: 10, horizontal: 8),
                                                child: Column(
                                                  children: <Widget>[
                                                    Text(snapshot.data[index].phone == null? 'Phone number : ' : 'Phone number : ' +
                                                        snapshot.data[index].phone,
                                                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                                                    ),
                                                    Text(snapshot.data[index].operator.label == null ? 'Operator : undefined' : 'Operator : ' +
                                                        snapshot.data[index].operator.label),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          );
                                        });
                                  }else if(snapshot.hasError){
                                    print(snapshot.error);
                                  }
                                  return  Center(child: CircularProgressIndicator());},
                              );
                            }
                            else{
                              return Center(child: Text('Session expired'),);
                            }
                          }
                      );
                    }
                    else{
                      return Center(child: Text('Session expired. Please log in again'));
                    }
                  }
              )
          );
        });
  }

  //for WIWI
  void showUserlistWIWI(BuildContext context){
    showRoundedModalBottomSheet(context: context,
        builder: (builder){
          return Scaffold(
            backgroundColor: Colors.yellow[100],
            bottomSheet: Text('Select a contact to make a transaction with it.',
              style: TextStyle(fontWeight: FontWeight.bold,),textAlign: TextAlign.center,),
            body: FutureBuilder<String>(
                future: UserData.getToken(),
                builder: (context, token){
                  if(token.hasData){
                    return FutureBuilder<List<UserAccount>>(
                      future: fetchalluser(token.data),
                      builder: (context, snapshot){
                        if (snapshot.hasData){
                          return ListView.builder(
                              itemCount: snapshot.data.length,
                              itemBuilder: (BuildContext context, int index) {

                                    return GestureDetector(
                                    onTap: () {
                                  //String number = snapshot.data[index].phone;
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (context)=> new SendWIWI(number : snapshot.data[index].phone)
                                  ));

                                },
                                  child: Card(
                                    elevation: 10,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10, horizontal: 8),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            snapshot.data[index].email == null ? '' : snapshot.data[index].email,
                                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                          ),
                                          SizedBox(height: 5,),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                snapshot.data[index].name == null ? '' :'Name : ' +  snapshot.data[index].name + ' ',
                                                style: TextStyle(fontSize: 12),
                                              ),
                                              Text(snapshot.data[index].surname == null ? '' : snapshot.data[index].surname,
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 5,),
                                          Text( snapshot.data[index].phone == null ? '' : 'Phone number : ' +snapshot.data[index].phone + ' ',
                                            style: TextStyle(fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              });
                        }else {
                          return Center(child: Text('No user'),);
                        }
                      },
                    );
                  }
                  else{
                    return Center(child: Text('Session expired. Please log in'));
                  }
                }
            ),
          );
        });
  }
}